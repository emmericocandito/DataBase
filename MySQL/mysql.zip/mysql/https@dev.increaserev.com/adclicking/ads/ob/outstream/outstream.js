var vast='../https@pubads.g.doubleclick.net/gampad/ads@iu=_2F21775744923_2Fexternal_2Fsingle_ad_samples&sz=640x480&cust_params=sample_ct%3Dlinear&ciu_szs=300x250,012C20BD46';
var vast=document.getElementById("ir_vast_code").value;
var sticky='';
var autoPlay_='true';
var Maxwidth='640';
var pages='';

function IR_main_Ad_Scripts($mainDivID="",domain__){
   var $vastag = vast;
    var domain_=domain__;
        var script5 = document.createElement('script');
        script5.type = 'text/javascript';
        script5.src = "../https@imasdk.googleapis.com/js/sdkloader/ima3.js";
        var parent5 = document.getElementsByTagName('script')[1];
        parent5.parentNode.insertBefore(script5, parent5);

        script5.onload = function() {
        var script1 = document.createElement('script');
        script1.type = 'text/javascript';
        script1.src = domain_+'videoplayer.js';
        var parent1 = document.getElementsByTagName('script')[0];
        parent1.parentNode.insertBefore(script1, parent1);

        script1.onload=function(){
            var script2 = document.createElement('script');

            script2.type = 'text/javascript';
            script2.src = domain_+"ads.js";

            var parent2 = document.getElementsByTagName('script')[1];
            parent2.parentNode.insertBefore(script2, parent2);


            script2.onload=function(){
                var script3 = document.createElement('script');
                script3.type="text/javascript";
                script3.src=domain_+"application.js";

                var parent3 = document.getElementsByTagName("script")[2];
                parent3.parentNode.insertBefore(script3,parent3);

                script3.onload=function(){
                    var script4 = document.createElement('script');
                    script4.id="playerJs";
                    script4.type="text/javascript";
                    script4.src=domain_+"playerJs.js";

                    var parent4 = document.getElementsByTagName("script")[3];
                    parent4.parentNode.insertBefore(script4,parent4);

                    script4.onload=function(){
                    document.getElementById('IR_video').autoplay = true;
                    document.getElementById('IR_video').src=null;
                    document.getElementById('IR_video').type="video/mp4";
                    document.getElementById('IR_video').muted = true;
                    document.getElementById("IR_playpausebtn").click();
                    IR_player_script_load($mainDivID,$vastag,sticky,autoPlay_,Maxwidth,pages);
                    }
                }
            }
        }
        }
     }
function IR_ad_Player_Generator($mainDivID=""){
var domain__="../https@increaserev.com/ads/ob/outstream/default.htm";
var styleScript = document.createElement("link");
styleScript.href=domain__+"style.css";
styleScript.setAttribute("rel","stylesheet");
document.head.appendChild(styleScript)[0];
styleScript.onload=function(){


    var IR_adDiv = `
<div class="video-wrap" id="sticky-container">
    <div class="player1 player-container" id="player-container">
        <div class="closeSticky" id="closeSticky">X</div>
        <div class="player" id="IR_player">
            <div class="playerDiv" id="playerDiv">
                <video id="IR_video" type="video/mp4" playsinline="true" loop="true"></video>
                <div class="BottomSide" id="BottomSide">
                    <div class="controls">
                        <div class="Main-Controls">
                            <div class="PlayBtnDiv">
                                <div class="play-btn playing" id="IR_playpausebtn">
                                    <svg
                                        version="1.1"
                                        id="btnpause"
                                        xmlns="http://www.w3.org/2000/svg"
                                        xmlns:xlink="http://www.w3.org/1999/xlink"
                                        x="0px"
                                        y="0px"
                                        width="163.861px"
                                        height="163.861px"
                                        viewBox="0 0 163.861 163.861"
                                        xml:space="preserve"
                                    >
                                        <path d="M34.857,3.613C20.084-4.861,8.107,2.081,8.107,19.106v125.637c0,17.042,11.977,23.975,26.75,15.509L144.67,97.275c14.778-8.477,14.778-22.211,0-30.686L34.857,3.613z" />
                                    </svg>
                                    <svg id="btnplay" viewBox="-45 0 327 327" xmlns="http://www.w3.org/2000/svg">
                                        <path d="m158 0h71c4.417969 0 8 3.582031 8 8v311c0 4.417969-3.582031 8-8 8h-71c-4.417969 0-8-3.582031-8-8v-311c0-4.417969 3.582031-8 8-8zm0 0" />
                                        <path d="m8 0h71c4.417969 0 8 3.582031 8 8v311c0 4.417969-3.582031 8-8 8h-71c-4.417969 0-8-3.582031-8-8v-311c0-4.417969 3.582031-8 8-8zm0 0" />
                                    </svg>
                                </div>
                            </div>
                            <div class="VolumeDiv">
                                <div class="volume">
                                    <div class="volume-btn muted" id="IR_volume-btn">
                                        <svg viewBox="0 0 26 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M6.75497 17.6928H2C0.89543 17.6928 0 16.7973 0 15.6928V8.30611C0 7.20152 0.895431 6.30611 2 6.30611H07C84BFA16"
                                                transform="translate(0 0.000518799)"
                                            />
                                            <path
                                                id="volume-low"
                                                d="M0 9.87787C2.87188 9.87787 5.2 7.66663 5.2 4.93893C5.2 2.21124 2.87188 0 0 0V2C1.86563 2 3.2 3.41162 3.2 4.93893C3.2 6.46625 1.86563 7.87787 0 7.87787V9.87787Z"
                                                transform="translate(17.3333 7.44955)"
                                            />
                                            <path
                                                id="volume-high"
                                                d="M0 16.4631C4.78647 16.4631 8.66667 12.7777 8.66667 8.23157C8.66667 3.68539 4.78647 0 0 0V2C3.78022 208C08C2AC8"
                                                transform="translate(17.3333 4.15689)"
                                            />
                                            <path
                                                id="volume-off"
                                                d="M1.22565 0L0 1.16412L3.06413 4.0744L0 6.98471L1.22565 8.14883L4.28978 5.23853L7.35391 8.14883L8.57956 6.98471L5.51544 4.0744L8.57956 1.16412L7.35391 0L4.28978 2.91031L1.22565 0Z"
                                                transform="translate(17.3769 8.31403)"
                                            />
                                        </svg>
                                    </div>
                                </div>
                            </div>
                            <div class="TimeDiv">
                                <div class="time"><span class="time-current"></span> <span class="time-total"> </span></div>
                            </div>

                            <div class="fullscreen">
                                <svg version="1.1" id="IR_fullscreen" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 317.215 317.215" xml:space="preserve">
                                    <g>
                                        <path
                                            d="M309.715,1.108h-71.223c-4.142,0-7.5,3.358-7.5,7.5v20c0,4.142,3.358,7.5,7.5,7.5h18.973l-57.128,57.1270CC4B01A8F"
                                        />
                                        <path
                                            d="M102.734,199.233c-1.407-1.406-3.314-2.197-5.304-2.197c-1.989,0-3.897,0.79-5.303,2.197L35,256.36v-18.0AEC301A59"
                                        />
                                    </g>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="adcontainer"></div>
            <div id="customClick">
                <div id="customClickTextWrapper">
                   <!-- Click here for more info on your ad.-->
                </div>
            </div>
            <div id="companionDiv"></div>
        </div>
    </div>
</div>

`;
      if($mainDivID!=""){
        var parNum = pages;
        if(parNum==""){
            
            // IF PARRAGHRAPH IS EMPTY
            var IR_adContainer = document.getElementById($mainDivID);
            var adContainer = document.createElement("div");
            adContainer.id="IR_adContainer";
            adContainer.setAttribute("style", "box-shadow: 1px 1px 6px rgb(0 0 0 / 70%);");
            IR_adContainer.appendChild(adContainer);
            adContainer.innerHTML=IR_adDiv;
            IR_main_Ad_Scripts($mainDivID,domain__);

        }else if(parNum.match(/^\d+$/gm)){
            // IF ONLY NUMBER
            var adLocation = document.querySelectorAll("p")[parNum];
            var adContainer = document.createElement("div");
            adContainer.id="IR_adContainer";
            adContainer.setAttribute("style", "box-shadow: 1px 1px 6px rgb(0 0 0 / 70%);");
            adLocation.before(adContainer);
            adContainer.innerHTML=IR_adDiv;
            IR_main_Ad_Scripts($mainDivID,domain__);
        }
        else{
            var adContainer = document.createElement("div");
            adContainer.id="IR_adContainer";
            adContainer.setAttribute("style", "box-shadow: 1px 1px 6px rgb(0 0 0 / 70%);");
            var attrValue = parNum.split(" ");
            var attr_val_0 = attrValue[0];
            var attr_val_1 = attrValue[1].split("_");
            var attr_C_0 = attr_val_1[0];
            var attr_C_1 = attr_val_1[1];
            var check = attr_val_1;
            var append = document.querySelectorAll(attr_val_0)[0].querySelectorAll(attr_C_0)[attr_C_1];
           append.before(adContainer);
            adContainer.innerHTML=IR_adDiv;
            IR_main_Ad_Scripts($mainDivID,domain__);
        }
       }
       }
}