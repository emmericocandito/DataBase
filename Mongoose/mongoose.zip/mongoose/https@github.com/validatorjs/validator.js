






<!DOCTYPE html>
<html lang="en" data-color-mode="auto" data-light-theme="light" data-dark-theme="dark" data-a11y-animated-images="system">
  <head>
    <meta charset="utf-8">
  <link rel="dns-prefetch" href="https://github.githubassets.com">
  <link rel="dns-prefetch" href="https://avatars.githubusercontent.com">
  <link rel="dns-prefetch" href="https://github-cloud.s3.amazonaws.com">
  <link rel="dns-prefetch" href="https://user-images.githubusercontent.com/">
  <link rel="preconnect" href="https://github.githubassets.com" crossorigin>
  <link rel="preconnect" href="https://avatars.githubusercontent.com">



  <link crossorigin="anonymous" media="all" integrity="sha512-ksfTgQOOnE+FFXf+yNfVjKSlEckJAdufFIYGK7ZjRhWcZgzAGcmZqqArTgMLpu90FwthqcCX4ldDgKXbmVMeuQ==" rel="stylesheet" href="https://github.githubassets.com/assets/light-92c7d381038e.css" /><link crossorigin="anonymous" media="all" integrity="sha512-1KkMNn8M/al/dtzBLupRwkIOgnA9MWkm8oxS+solP87jByEvY/g4BmoxLihRogKcX1obPnf4Yp7dI0ZTWO+ljg==" rel="stylesheet" href="https://github.githubassets.com/assets/dark-d4a90c367f0c.css" /><link data-color-theme="dark_dimmed" crossorigin="anonymous" media="all" integrity="sha512-cZa7DZqvMBwD236uzEunO/G1dvw8/QftyT2UtLWKQFEy0z0eq0R5WPwqVME+3NSZG1YaLJAaIqtU+m0zWf/6SQ==" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_dimmed-7196bb0d9aaf.css" /><link data-color-theme="dark_high_contrast" crossorigin="anonymous" media="all" integrity="sha512-WVoKqJ4y1nLsdNH4RkRT5qrM9+n9RFe1RHSiTnQkBf5TSZkJEc9GpLpTIS7T15EQaUQBJ8BwmKvwFPVqfpTEIQ==" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_high_contrast-595a0aa89e32.css" /><link data-color-theme="dark_colorblind" crossorigin="anonymous" media="all" integrity="sha512-XpAMBMSRZ6RTXgepS8LjKiOeNK3BilRbv8qEiA/M3m+Q4GoqxtHedOI5BAZRikCzfBL4KWYvVzYZSZ8Gp/UnUg==" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_colorblind-5e900c04c491.css" /><link data-color-theme="light_colorblind" crossorigin="anonymous" media="all" integrity="sha512-3HF2HZ4LgEIQm77yOzoeR20CX1n2cUQlcywscqF4s+5iplolajiHV7E5ranBwkX65jN9TNciHEVSYebQ+8xxEw==" rel="stylesheet" data-href="https://github.githubassets.com/assets/light_colorblind-dc71761d9e0b.css" /><link data-color-theme="light_high_contrast" crossorigin="anonymous" media="all" integrity="sha512-+J8j3T0kbK9/sL3zbkCfPtgYcRD4qQfRbT6xnfOrOTjvz4zhr0M7AXPuE642PpaxGhHs1t77cTtieW9hI2K6Gw==" rel="stylesheet" data-href="https://github.githubassets.com/assets/light_high_contrast-f89f23dd3d24.css" /><link data-color-theme="light_tritanopia" crossorigin="anonymous" media="all" integrity="sha512-AQeAx5wHQAXNf0DmkvVlHYwA3f6BkxunWTI0GGaRN57GqD+H9tW8RKIKlopLS0qGaC54seFsPc601GDlqIuuHg==" rel="stylesheet" data-href="https://github.githubassets.com/assets/light_tritanopia-010780c79c07.css" /><link data-color-theme="dark_tritanopia" crossorigin="anonymous" media="all" integrity="sha512-+u5pmgAE0T03d/yI6Ha0NWwz6Pk0W6S6WEfIt8veDVdK8NTjcMbZmQB9XUCkDlrBoAKkABva8HuGJ+SzEpV1Uw==" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_tritanopia-faee699a0004.css" />
  
    <link crossorigin="anonymous" media="all" integrity="sha512-EAhBCLIJ/pXHG3Y6yQhs9s53SHV80sjJ+yCwlQtfv7LaVkD+VoEuZBZ5betQJFUNj/5qBSfZk5GFtazEDzWLAg==" rel="stylesheet" href="https://github.githubassets.com/assets/primer-10084108b209.css" />
    <link crossorigin="anonymous" media="all" integrity="sha512-oPOdLuGklyabk0ahpehbrOn2jEwWT5fIcgNPsUipsBIWjE4YWjMk8n4NDzJ135hL9jDhlewFHFtR38uZFsV8AA==" rel="stylesheet" href="https://github.githubassets.com/assets/global-a0f39d2ee1a4.css" />
    <link crossorigin="anonymous" media="all" integrity="sha512-+BXQXTcaoVpw6DQma9O1CCCIQiS9PZgyqRhSulibpIQIk0JhSfE6+hFl7fChAl+DmqKRE2lD3oO60mUTKYDpww==" rel="stylesheet" href="https://github.githubassets.com/assets/github-f815d05d371a.css" />
  <link crossorigin="anonymous" media="all" integrity="sha512-PXtwH8brj9qH7LskWA0iAMLw4Wx3RXN7txSxjlqdzQEalZKu3UcsQ+ajfHJMDkYDA2iWL1FIrf2zyLflA5Xu7A==" rel="stylesheet" href="https://github.githubassets.com/assets/code-3d7b701fc6eb.css" />

    <meta name="optimizely-datafile" content="{&quot;groups&quot;: [], &quot;environmentKey&quot;: &quot;production&quot;, &quot;rollouts&quot;: [], &quot;typedAudiences&quot;: [], &quot;projectId&quot;: &quot;16737760170&quot;, &quot;variables&quot;: [], &quot;featureFlags&quot;: [], &quot;experiments&quot;: [{&quot;status&quot;: &quot;Running&quot;, &quot;audienceIds&quot;: [], &quot;variations&quot;: [{&quot;variables&quot;: [], &quot;id&quot;: &quot;20667381018&quot;, &quot;key&quot;: &quot;control&quot;}, {&quot;variables&quot;: [], &quot;id&quot;: &quot;20680930759&quot;, &quot;key&quot;: &quot;treatment&quot;}], &quot;id&quot;: &quot;20652570897&quot;, &quot;key&quot;: &quot;project_genesis&quot;, &quot;layerId&quot;: &quot;20672300363&quot;, &quot;trafficAllocation&quot;: [{&quot;entityId&quot;: &quot;20667381018&quot;, &quot;endOfRange&quot;: 5000}, {&quot;entityId&quot;: &quot;20680930759&quot;, &quot;endOfRange&quot;: 10000}], &quot;forcedVariations&quot;: {&quot;83356e17066d336d1803024138ecb683&quot;: &quot;treatment&quot;, &quot;18e31c8a9b2271332466133162a4aa0d&quot;: &quot;treatment&quot;, &quot;10f8ab3fbc5ebe989a36a05f79d48f32&quot;: &quot;treatment&quot;, &quot;1686089f6d540cd2deeaec60ee43ecf7&quot;: &quot;treatment&quot;}}, {&quot;status&quot;: &quot;Running&quot;, &quot;audienceIds&quot;: [], &quot;variations&quot;: [{&quot;variables&quot;: [], &quot;id&quot;: &quot;21427950901&quot;, &quot;key&quot;: &quot;control&quot;}, {&quot;variables&quot;: [], &quot;id&quot;: &quot;21429710665&quot;, &quot;key&quot;: &quot;beginner&quot;}, {&quot;variables&quot;: [], &quot;id&quot;: &quot;21437291543&quot;, &quot;key&quot;: &quot;upstart&quot;}], &quot;id&quot;: &quot;21445030708&quot;, &quot;key&quot;: &quot;_259_zero_user_dashboard&quot;, &quot;layerId&quot;: &quot;21434011841&quot;, &quot;trafficAllocation&quot;: [{&quot;entityId&quot;: &quot;21427950901&quot;, &quot;endOfRange&quot;: 3334}, {&quot;entityId&quot;: &quot;21427950901&quot;, &quot;endOfRange&quot;: 5000}, {&quot;entityId&quot;: &quot;21427950901&quot;, &quot;endOfRange&quot;: 8333}, {&quot;entityId&quot;: &quot;21427950901&quot;, &quot;endOfRange&quot;: 10000}], &quot;forcedVariations&quot;: {&quot;3c64268131793aa297119a343c19e345&quot;: &quot;beginner&quot;, &quot;95b24126db31ea8693c0fe5ea9f53b65&quot;: &quot;beginner&quot;, &quot;086e2abe64e9101112af53b95d2d90b9&quot;: &quot;upstart&quot;, &quot;bae688df9d297afac98e2d254e912ada&quot;: &quot;control&quot;, &quot;6c2cfda7c41396fcc31a4db759a42b94&quot;: &quot;beginner&quot;, &quot;16ed2b4ff7de02663b7c606309695916&quot;: &quot;control&quot;, &quot;1971768911.1635962195&quot;: &quot;beginner&quot;, &quot;830bf802470ec6c9c5800c99d8e57445&quot;: &quot;beginner&quot;}}, {&quot;status&quot;: &quot;Running&quot;, &quot;audienceIds&quot;: [], &quot;variations&quot;: [{&quot;variables&quot;: [], &quot;id&quot;: &quot;21454052779&quot;, &quot;key&quot;: &quot;control&quot;}, {&quot;variables&quot;: [], &quot;id&quot;: &quot;21450922535&quot;, &quot;key&quot;: &quot;redesign&quot;}], &quot;id&quot;: &quot;21486342806&quot;, &quot;key&quot;: &quot;_261_downgrade&quot;, &quot;layerId&quot;: &quot;21478441323&quot;, &quot;trafficAllocation&quot;: [{&quot;entityId&quot;: &quot;21454052779&quot;, &quot;endOfRange&quot;: 5000}, {&quot;entityId&quot;: &quot;21450922535&quot;, &quot;endOfRange&quot;: 10000}], &quot;forcedVariations&quot;: {&quot;60c046ae30e9007c321e5539ae1738b5&quot;: &quot;redesign&quot;}}, {&quot;status&quot;: &quot;Running&quot;, &quot;audienceIds&quot;: [], &quot;variations&quot;: [{&quot;variables&quot;: [], &quot;id&quot;: &quot;21672251105&quot;, &quot;key&quot;: &quot;control&quot;}, {&quot;variables&quot;: [], &quot;id&quot;: &quot;21636601473&quot;, &quot;key&quot;: &quot;primer&quot;}, {&quot;variables&quot;: [], &quot;id&quot;: &quot;21663911434&quot;, &quot;key&quot;: &quot;growth&quot;}, {&quot;variables&quot;: [], &quot;id&quot;: &quot;21673341369&quot;, &quot;key&quot;: &quot;brand&quot;}], &quot;id&quot;: &quot;21685100630&quot;, &quot;key&quot;: &quot;_241_onboard_users_to_protect_branches&quot;, &quot;layerId&quot;: &quot;21696970697&quot;, &quot;trafficAllocation&quot;: [{&quot;entityId&quot;: &quot;21672251105&quot;, &quot;endOfRange&quot;: 825}, {&quot;entityId&quot;: &quot;&quot;, &quot;endOfRange&quot;: 2310}, {&quot;entityId&quot;: &quot;21636601473&quot;, &quot;endOfRange&quot;: 2500}, {&quot;entityId&quot;: &quot;21636601473&quot;, &quot;endOfRange&quot;: 2830}, {&quot;entityId&quot;: &quot;21636601473&quot;, &quot;endOfRange&quot;: 3135}, {&quot;entityId&quot;: &quot;&quot;, &quot;endOfRange&quot;: 3310}, {&quot;entityId&quot;: &quot;21663911434&quot;, &quot;endOfRange&quot;: 3325}, {&quot;entityId&quot;: &quot;21663911434&quot;, &quot;endOfRange&quot;: 3980}, {&quot;entityId&quot;: &quot;&quot;, &quot;endOfRange&quot;: 4170}, {&quot;entityId&quot;: &quot;&quot;, &quot;endOfRange&quot;: 5000}, {&quot;entityId&quot;: &quot;21663911434&quot;, &quot;endOfRange&quot;: 5155}, {&quot;entityId&quot;: &quot;&quot;, &quot;endOfRange&quot;: 5330}, {&quot;entityId&quot;: &quot;&quot;, &quot;endOfRange&quot;: 5825}, {&quot;entityId&quot;: &quot;&quot;, &quot;endOfRange&quot;: 6000}, {&quot;entityId&quot;: &quot;&quot;, &quot;endOfRange&quot;: 7500}, {&quot;entityId&quot;: &quot;21673341369&quot;, &quot;endOfRange&quot;: 7830}, {&quot;entityId&quot;: &quot;21673341369&quot;, &quot;endOfRange&quot;: 8325}, {&quot;entityId&quot;: &quot;&quot;, &quot;endOfRange&quot;: 9330}, {&quot;entityId&quot;: &quot;&quot;, &quot;endOfRange&quot;: 10000}], &quot;forcedVariations&quot;: {&quot;409007617793ebd1e12654adf87047d0&quot;: &quot;growth&quot;, &quot;3977d8a7a265a13d734f3edf9226214c&quot;: &quot;primer&quot;, &quot;bcf588169e3ac842af083a5a54708563&quot;: &quot;growth&quot;}}], &quot;version&quot;: &quot;4&quot;, &quot;audiences&quot;: [{&quot;conditions&quot;: &quot;[\&quot;or\&quot;, {\&quot;match\&quot;: \&quot;exact\&quot;, \&quot;name\&quot;: \&quot;$opt_dummy_attribute\&quot;, \&quot;type\&quot;: \&quot;custom_attribute\&quot;, \&quot;value\&quot;: \&quot;$opt_dummy_value\&quot;}]&quot;, &quot;id&quot;: &quot;$opt_dummy_audience&quot;, &quot;name&quot;: &quot;Optimizely-Generated Audience for Backwards Compatibility&quot;}], &quot;anonymizeIP&quot;: true, &quot;sdkKey&quot;: &quot;WTc6awnGuYDdG98CYRban&quot;, &quot;attributes&quot;: [{&quot;id&quot;: &quot;16822470375&quot;, &quot;key&quot;: &quot;user_id&quot;}, {&quot;id&quot;: &quot;17143601254&quot;, &quot;key&quot;: &quot;spammy&quot;}, {&quot;id&quot;: &quot;18175660309&quot;, &quot;key&quot;: &quot;organization_plan&quot;}, {&quot;id&quot;: &quot;18813001570&quot;, &quot;key&quot;: &quot;is_logged_in&quot;}, {&quot;id&quot;: &quot;19073851829&quot;, &quot;key&quot;: &quot;geo&quot;}, {&quot;id&quot;: &quot;20175462351&quot;, &quot;key&quot;: &quot;requestedCurrency&quot;}, {&quot;id&quot;: &quot;20785470195&quot;, &quot;key&quot;: &quot;country_code&quot;}, {&quot;id&quot;: &quot;21656311196&quot;, &quot;key&quot;: &quot;opened_downgrade_dialog&quot;}], &quot;botFiltering&quot;: false, &quot;accountId&quot;: &quot;16737760170&quot;, &quot;events&quot;: [{&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;17911811441&quot;, &quot;key&quot;: &quot;hydro_click.dashboard.teacher_toolbox_cta&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18124116703&quot;, &quot;key&quot;: &quot;submit.organizations.complete_sign_up&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18145892387&quot;, &quot;key&quot;: &quot;no_metric.tracked_outside_of_optimizely&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18178755568&quot;, &quot;key&quot;: &quot;click.org_onboarding_checklist.add_repo&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18180553241&quot;, &quot;key&quot;: &quot;submit.repository_imports.create&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18186103728&quot;, &quot;key&quot;: &quot;click.help.learn_more_about_repository_creation&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18188530140&quot;, &quot;key&quot;: &quot;test_event&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18191963644&quot;, &quot;key&quot;: &quot;click.empty_org_repo_cta.transfer_repository&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18195612788&quot;, &quot;key&quot;: &quot;click.empty_org_repo_cta.import_repository&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18210945499&quot;, &quot;key&quot;: &quot;click.org_onboarding_checklist.invite_members&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18211063248&quot;, &quot;key&quot;: &quot;click.empty_org_repo_cta.create_repository&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18215721889&quot;, &quot;key&quot;: &quot;click.org_onboarding_checklist.update_profile&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18224360785&quot;, &quot;key&quot;: &quot;click.org_onboarding_checklist.dismiss&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18234832286&quot;, &quot;key&quot;: &quot;submit.organization_activation.complete&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18252392383&quot;, &quot;key&quot;: &quot;submit.org_repository.create&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18257551537&quot;, &quot;key&quot;: &quot;submit.org_member_invitation.create&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18259522260&quot;, &quot;key&quot;: &quot;submit.organization_profile.update&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18564603625&quot;, &quot;key&quot;: &quot;view.classroom_select_organization&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18568612016&quot;, &quot;key&quot;: &quot;click.classroom_sign_in_click&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18572592540&quot;, &quot;key&quot;: &quot;view.classroom_name&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18574203855&quot;, &quot;key&quot;: &quot;click.classroom_create_organization&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18582053415&quot;, &quot;key&quot;: &quot;click.classroom_select_organization&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18589463420&quot;, &quot;key&quot;: &quot;click.classroom_create_classroom&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18591323364&quot;, &quot;key&quot;: &quot;click.classroom_create_first_classroom&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18591652321&quot;, &quot;key&quot;: &quot;click.classroom_grant_access&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18607131425&quot;, &quot;key&quot;: &quot;view.classroom_creation&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;18831680583&quot;, &quot;key&quot;: &quot;upgrade_account_plan&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19064064515&quot;, &quot;key&quot;: &quot;click.signup&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19075373687&quot;, &quot;key&quot;: &quot;click.view_account_billing_page&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19077355841&quot;, &quot;key&quot;: &quot;click.dismiss_signup_prompt&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19079713938&quot;, &quot;key&quot;: &quot;click.contact_sales&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19120963070&quot;, &quot;key&quot;: &quot;click.compare_account_plans&quot;}, {&quot;experimentIds&quot;: [&quot;21685100630&quot;], &quot;id&quot;: &quot;19151690317&quot;, &quot;key&quot;: &quot;click.upgrade_account_cta&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19424193129&quot;, &quot;key&quot;: &quot;click.open_account_switcher&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19520330825&quot;, &quot;key&quot;: &quot;click.visit_account_profile&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19540970635&quot;, &quot;key&quot;: &quot;click.switch_account_context&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19730198868&quot;, &quot;key&quot;: &quot;submit.homepage_signup&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19820830627&quot;, &quot;key&quot;: &quot;click.homepage_signup&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;19988571001&quot;, &quot;key&quot;: &quot;click.create_enterprise_trial&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20036538294&quot;, &quot;key&quot;: &quot;click.create_organization_team&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20040653299&quot;, &quot;key&quot;: &quot;click.input_enterprise_trial_form&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20062030003&quot;, &quot;key&quot;: &quot;click.continue_with_team&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20068947153&quot;, &quot;key&quot;: &quot;click.create_organization_free&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20086636658&quot;, &quot;key&quot;: &quot;click.signup_continue.username&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20091648988&quot;, &quot;key&quot;: &quot;click.signup_continue.create_account&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20103637615&quot;, &quot;key&quot;: &quot;click.signup_continue.email&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20111574253&quot;, &quot;key&quot;: &quot;click.signup_continue.password&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20120044111&quot;, &quot;key&quot;: &quot;view.pricing_page&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20152062109&quot;, &quot;key&quot;: &quot;submit.create_account&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20165800992&quot;, &quot;key&quot;: &quot;submit.upgrade_payment_form&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20171520319&quot;, &quot;key&quot;: &quot;submit.create_organization&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20222645674&quot;, &quot;key&quot;: &quot;click.recommended_plan_in_signup.discuss_your_needs&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20227443657&quot;, &quot;key&quot;: &quot;submit.verify_primary_user_email&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20234607160&quot;, &quot;key&quot;: &quot;click.recommended_plan_in_signup.try_enterprise&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20238175784&quot;, &quot;key&quot;: &quot;click.recommended_plan_in_signup.team&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20239847212&quot;, &quot;key&quot;: &quot;click.recommended_plan_in_signup.continue_free&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20251097193&quot;, &quot;key&quot;: &quot;recommended_plan&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20438619534&quot;, &quot;key&quot;: &quot;click.pricing_calculator.1_member&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20456699683&quot;, &quot;key&quot;: &quot;click.pricing_calculator.15_members&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20467868331&quot;, &quot;key&quot;: &quot;click.pricing_calculator.10_members&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20476267432&quot;, &quot;key&quot;: &quot;click.trial_days_remaining&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20476357660&quot;, &quot;key&quot;: &quot;click.discover_feature&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20479287901&quot;, &quot;key&quot;: &quot;click.pricing_calculator.custom_members&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20481107083&quot;, &quot;key&quot;: &quot;click.recommended_plan_in_signup.apply_teacher_benefits&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20483089392&quot;, &quot;key&quot;: &quot;click.pricing_calculator.5_members&quot;}, {&quot;experimentIds&quot;: [&quot;20652570897&quot;], &quot;id&quot;: &quot;20484283944&quot;, &quot;key&quot;: &quot;click.onboarding_task&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20484996281&quot;, &quot;key&quot;: &quot;click.recommended_plan_in_signup.apply_student_benefits&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20486713726&quot;, &quot;key&quot;: &quot;click.onboarding_task_breadcrumb&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20490791319&quot;, &quot;key&quot;: &quot;click.upgrade_to_enterprise&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20491786766&quot;, &quot;key&quot;: &quot;click.talk_to_us&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20494144087&quot;, &quot;key&quot;: &quot;click.dismiss_enterprise_trial&quot;}, {&quot;experimentIds&quot;: [&quot;20652570897&quot;], &quot;id&quot;: &quot;20499722759&quot;, &quot;key&quot;: &quot;completed_all_tasks&quot;}, {&quot;experimentIds&quot;: [&quot;20652570897&quot;], &quot;id&quot;: &quot;20500710104&quot;, &quot;key&quot;: &quot;completed_onboarding_tasks&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20513160672&quot;, &quot;key&quot;: &quot;click.read_doc&quot;}, {&quot;experimentIds&quot;: [&quot;20652570897&quot;], &quot;id&quot;: &quot;20516196762&quot;, &quot;key&quot;: &quot;actions_enabled&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20518980986&quot;, &quot;key&quot;: &quot;click.dismiss_trial_banner&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20535446721&quot;, &quot;key&quot;: &quot;click.issue_actions_prompt.dismiss_prompt&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20557002247&quot;, &quot;key&quot;: &quot;click.issue_actions_prompt.setup_workflow&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20595070227&quot;, &quot;key&quot;: &quot;click.pull_request_setup_workflow&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20626600314&quot;, &quot;key&quot;: &quot;click.seats_input&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20642310305&quot;, &quot;key&quot;: &quot;click.decrease_seats_number&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20662990045&quot;, &quot;key&quot;: &quot;click.increase_seats_number&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20679620969&quot;, &quot;key&quot;: &quot;click.public_product_roadmap&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20761240940&quot;, &quot;key&quot;: &quot;click.dismiss_survey_banner&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20767210721&quot;, &quot;key&quot;: &quot;click.take_survey&quot;}, {&quot;experimentIds&quot;: [&quot;20652570897&quot;], &quot;id&quot;: &quot;20795281201&quot;, &quot;key&quot;: &quot;click.archive_list&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20966790249&quot;, &quot;key&quot;: &quot;contact_sales.submit&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20996500333&quot;, &quot;key&quot;: &quot;contact_sales.existing_customer&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;20996890162&quot;, &quot;key&quot;: &quot;contact_sales.blank_message_field&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;21000470317&quot;, &quot;key&quot;: &quot;contact_sales.personal_email&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;21002790172&quot;, &quot;key&quot;: &quot;contact_sales.blank_phone_field&quot;}, {&quot;experimentIds&quot;: [&quot;21445030708&quot;], &quot;id&quot;: &quot;21354412592&quot;, &quot;key&quot;: &quot;click.dismiss_create_readme&quot;}, {&quot;experimentIds&quot;: [&quot;21445030708&quot;], &quot;id&quot;: &quot;21366102546&quot;, &quot;key&quot;: &quot;click.dismiss_zero_user_content&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;21370252505&quot;, &quot;key&quot;: &quot;account_did_downgrade&quot;}, {&quot;experimentIds&quot;: [&quot;21445030708&quot;], &quot;id&quot;: &quot;21370840408&quot;, &quot;key&quot;: &quot;click.cta_create_readme&quot;}, {&quot;experimentIds&quot;: [&quot;21445030708&quot;], &quot;id&quot;: &quot;21375451068&quot;, &quot;key&quot;: &quot;click.cta_create_new_repository&quot;}, {&quot;experimentIds&quot;: [&quot;21445030708&quot;], &quot;id&quot;: &quot;21385390948&quot;, &quot;key&quot;: &quot;click.zero_user_content&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;21467712175&quot;, &quot;key&quot;: &quot;click.downgrade_keep&quot;}, {&quot;experimentIds&quot;: [&quot;21486342806&quot;], &quot;id&quot;: &quot;21484112202&quot;, &quot;key&quot;: &quot;click.downgrade&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;21495292213&quot;, &quot;key&quot;: &quot;click.downgrade_survey_exit&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;21508241468&quot;, &quot;key&quot;: &quot;click.downgrade_survey_submit&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;21512030356&quot;, &quot;key&quot;: &quot;click.downgrade_support&quot;}, {&quot;experimentIds&quot;: [&quot;21486342806&quot;], &quot;id&quot;: &quot;21539090022&quot;, &quot;key&quot;: &quot;click.downgrade_exit&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;21543640644&quot;, &quot;key&quot;: &quot;click_fetch_upstream&quot;}, {&quot;experimentIds&quot;: [&quot;21685100630&quot;], &quot;id&quot;: &quot;21646510300&quot;, &quot;key&quot;: &quot;click.move_your_work&quot;}, {&quot;experimentIds&quot;: [&quot;21685100630&quot;], &quot;id&quot;: &quot;21656151116&quot;, &quot;key&quot;: &quot;click.add_branch_protection_rule&quot;}, {&quot;experimentIds&quot;: [], &quot;id&quot;: &quot;21663860599&quot;, &quot;key&quot;: &quot;click.downgrade_dialog_open&quot;}, {&quot;experimentIds&quot;: [&quot;21685100630&quot;], &quot;id&quot;: &quot;21687860483&quot;, &quot;key&quot;: &quot;click.learn_about_protected_branches&quot;}, {&quot;experimentIds&quot;: [&quot;21685100630&quot;], &quot;id&quot;: &quot;21689050333&quot;, &quot;key&quot;: &quot;click.dismiss_protect_this_branch&quot;}], &quot;revision&quot;: &quot;1321&quot;}" />


  <script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-44mCWWd9he+TZlQdLzIEo+cbYo6tgMXkx8954MY/9DknkwxQmYGmKJrGKCgbWmcMYmBgxLX6uOEgcRoDL/5eCA==" src="https://github.githubassets.com/assets/runtime-e3898259677d.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-ZXV4TpPmxfyBQ9eFqJaVR/Z8Rrt+f/In8yBbbMmt6pqCRMVcnlTWS7/Xy5aedmiIj1tNZXmsvW3cf/vRas/mvQ==" src="https://github.githubassets.com/assets/vendors-node_modules_delegated-events_dist_index_js-node_modules_stacktrace-parser_dist_stack-74aed8-6575784e93e6.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-km+JVvSjuMukaGXFPj5OuzW1lNCVhWt0dB2EAkW4NpEj6x301u0l22+XLYaKm9+hvluGH0OlM6BE4hoTjxtFoQ==" src="https://github.githubassets.com/assets/environment-926f8956f4a3.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-57NPhP0wWFMwvRygugK3iI3z+Sv0WTNy8MGBcwfMPYE7SoHKEoH1B89v+ANBqnW9GGvUYzf4gLT6UrP/VmhY2g==" src="https://github.githubassets.com/assets/vendors-node_modules_selector-observer_dist_index_esm_js-e7b34f84fd30.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-Es25N4GyPa8Yfp5wpahoe5b2fyPtkRMyR6mKIXyCJC0ocqQazeWvxhGZhx3StRxOfqDfHDR5SS35u/R3Wux6Cg==" src="https://github.githubassets.com/assets/vendors-node_modules_delegated-events_dist_index_js-node_modules_github_details-dialog-elemen-63debe-12cdb93781b2.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-lmiecOIgf+hakg5oKMNM7grVhEDyPoIrT39Px448JJH5PSAaK21PH0Twgyz5O5oi8+dnlLr3Jt8bBCtAcpNdRw==" src="https://github.githubassets.com/assets/vendors-node_modules_github_filter-input-element_dist_index_js-node_modules_github_remote-inp-c7e9ed-96689e70e220.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-FhIi1nHjAzm1txsZ2LPPUfqIASARJ44qRQ09VSY4p/NVvWz/1reBy21+3an4fDIi6QhfrHNUI4ldKz3NW5by/Q==" src="https://github.githubassets.com/assets/vendors-node_modules_github_catalyst_lib_index_js-node_modules_github_time-elements_dist_index_js-161222d671e3.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-DE9GK/TS3Hf/dJfP1GMiyjvsGRnpR4A1eGH64s0Ot7Vy7Tj7/aD1d5EOMWHFWQXlXy/ZSwu5MHInG6RZN31bMA==" src="https://github.githubassets.com/assets/vendors-node_modules_github_file-attachment-element_dist_index_js-node_modules_primer_view-co-52e104-0c4f462bf4d2.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-fcVStVRolV54DldAqKbEzSE1OB6Rd/jIIpSj/dcCRRaSc8EgN68GT9sT/Ya0gtpNTq0aAPzs9OLlhWY7l0s4eA==" src="https://github.githubassets.com/assets/github-elements-7dc552b55468.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-n0EqohMRhyf2gYDkWAvqYJsBzb8qCciNwqGUpwOEjVfSLESviOFqm7IrHsihpfLAm+ZhteYJkQ+PPwqjJTUTrQ==" src="https://github.githubassets.com/assets/element-registry-9f412aa21311.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-ULHDrjH3Nz+5xGQnGJ+51ZBv5qENKe3TikjwAxKli4TyT+8KZ5mnWUJxUdXaFwRVMGRJD+8CjfCVhj7913OiOA==" src="https://github.githubassets.com/assets/vendors-node_modules_lit-html_lit-html_js-50b1c3ae31f7.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-XubU6uMX6y2ka6JR/QVSIS8aAdXBH9Jhm1lLCNFS5Dy3xbDEdS6W4ENFx71XaEAwW3d8xzgiS4cS0J/zsnYm6w==" src="https://github.githubassets.com/assets/vendors-node_modules_github_remote-form_dist_index_js-node_modules_github_catalyst_lib_index_-bd1f73-5ee6d4eae317.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-0r1nf/rfPz54kyePp4f63bcPxkFo7wyaUZJD/SwIVDK3q0WzurAK9ydOm88tzKtPJm8xWI0Vo25NyCfecwxJ9g==" src="https://github.githubassets.com/assets/vendors-node_modules_github_mini-throttle_dist_index_js-node_modules_github_hotkey_dist_index-9f48bd-d2bd677ffadf.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-b6LnssJjHkph4nI0CxyYnXJ/d7eWTCd6fDCQZkhXUwNTMcB55fwq4nPNUDdsFG3h/KS3VEsMjhkqC8jBcQVazA==" src="https://github.githubassets.com/assets/vendors-node_modules_github_paste-markdown_dist_index_esm_js-node_modules_github_quote-select-f71f15-6fa2e7b2c263.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-aD+lpuc5jHemEy0Cf2KYz46MdwOIlj3+2cZ59XIi+mentNdewI1LzaDqroNLJzONIiL4IeUUZ7hJzhPYV4DQVA==" src="https://github.githubassets.com/assets/app_assets_modules_github_behaviors_pjax_ts-683fa5a6e739.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-i6G+/7pwOhMb9q+i08xUSvHWO8fWX9lkXtuIJQGpHGn299Mb74hWyc5ikFQAuqgd2i/cV9c5Jw6O9Z10jDfAwg==" src="https://github.githubassets.com/assets/app_assets_modules_github_behaviors_keyboard-shortcuts-helper_ts-app_assets_modules_github_be-af52ef-8ba1beffba70.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-sGIJsMNVLhivulsWgcWql7t/JEs3gUQQt/9GHRjArviQLj6smy1Cei4X6Bg51OC/rZMDXeTNSL733VSNtdlynA==" src="https://github.githubassets.com/assets/app_assets_modules_github_behaviors_details_ts-app_assets_modules_github_behaviors_include-fr-019af8-b06209b0c355.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-1CN8HrSEXNbvvtNrIvzOMA1IkGwLyUOaFBl/N2UE91/8EvcqBFxy3M83mJVi/n50Kdq4oIRIeZG5D5oTpFTBDg==" src="https://github.githubassets.com/assets/behaviors-d4237c1eb484.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-5nWr6hoxY6oc8ngCIfUbQS8h+5n8/1XZVb9KFgP0ak4NzsfM7ERe6b5639AYjyAbYZGs6I/7hC3eieSbWkHx9w==" src="https://github.githubassets.com/assets/notifications-global-e675abea1a31.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-omX+FWiTxaVbL188DLiuWbcEFe7gXWrjZnlIEQzyXz62qEXRVxLUZawdjbjuoAHZ9C5QINfpPE/OBDrfUUyctg==" src="https://github.githubassets.com/assets/vendors-node_modules_optimizely_optimizely-sdk_dist_optimizely_browser_es_min_js-a265fe156893.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-L+AwSmKfTSztSQvKJyGEp5+k/Y7QmjqDgHZTK5hERLTS1lnuP2QyZq+h0Yi06KpdFR+tjCmXNKcvR63T5QJTZw==" src="https://github.githubassets.com/assets/optimizely-2fe0304a629f.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-lLmCvJZc0vZs/OgX6nNSVPIR7RWr2mOB1gd6j7f3iwKe11903M9DxTRS3VmhZ4sUbt95WzbfI0AY4bMDy0pN/w==" src="https://github.githubassets.com/assets/vendors-node_modules_virtualized-list_es_index_js-node_modules_github_template-parts_lib_index_js-94b982bc965c.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-XMTjM6nqvsnzbHMLUica6szm/D6vX1dQp8qoHKtMVYekfBkUyk6LVYNNBKCdDT/m8skRHM95SIRQkwqnZpGvMg==" src="https://github.githubassets.com/assets/vendors-node_modules_github_remote-form_dist_index_js-node_modules_delegated-events_dist_inde-16f3e12-5cc4e333a9ea.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-OEHWziY/xQ1PrxMn2gJojsw//rueP6lpgkKi2/TW+XIcLLgJ8OjfYOvZrzrs/TK1UrAEy46NBcwY08hSDyRhCA==" src="https://github.githubassets.com/assets/codespaces-3841d6ce263f.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-zzkpgyV1rYpHXtI8aFObuA5zVz+nFt8Tv8F2eRRQL0mKDE/3SuuuA8j/AetOzMPzVeWnSLJx8C9JK6qNCtiHWQ==" src="https://github.githubassets.com/assets/vendors-node_modules_github_mini-throttle_dist_decorators_js-node_modules_github_remote-form_-65a541-cf3929832575.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-u4/B5kyvzmdjSiR3fjmMqqgMZhHep6rnuhlLK5XNI3DPmAcbm9WfKTX4duF5fn0JlqubgasXCyPWypjWVzalxA==" src="https://github.githubassets.com/assets/vendors-node_modules_github_file-attachment-element_dist_index_js-node_modules_github_filter--8b2f15-bb8fc1e64caf.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-fiLtIah3Q9m8zYMDZbUE6by3ewKUzVB8dbnT5M9y2EEGc4hB/JqzJ64/4pNb3uAcmq7z+KpJ4vGc7xVg7/rJ+w==" src="https://github.githubassets.com/assets/app_assets_modules_github_fetch_ts-app_assets_modules_github_input-demux_ts-app_assets_module-e5b55c-7e22ed21a877.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-AWqWq24FxOesFgq1EP6LkmVSDZKwFickfe2BAp9Q7OYZF9275sRUMLUoRSyWxT54vsZukqxCPQYDsKrB9zGXjQ==" src="https://github.githubassets.com/assets/repositories-016a96ab6e05.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-Pt7ahcbkvW9Z9bHqLXTQqTf+cQMWtUf2riE1VRFykaJfIN1rbgs/B+R/5yY7vMMd0wksYS5abhYPa5bu/Wuc5g==" src="https://github.githubassets.com/assets/topic-suggestions-3ededa85c6e4.js"></script>
<script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-irICMWCzTmBK7jCFWG5txCMlT5kz9CO8ZNx3g2fGXHQdlcCdYCckE9Fc+pw4NYoxsRU4QdispJ/V/2Ny9gJQAg==" src="https://github.githubassets.com/assets/code-menu-8ab2023160b3.js"></script>
  

  <title>GitHub - validatorjs/validator.js: String validation</title>



    

  <meta name="request-id" content="861E:11FF6:C268B6:D0E5AE:62CA3EE7" data-pjax-transient="true"/><meta name="html-safe-nonce" content="a85be77c2f7f81e5c35ec71d7957c60fc154ff26e2bfb322e5c199f1f81c56d9" data-pjax-transient="true"/><meta name="visitor-payload" content="eyJyZWZlcnJlciI6Imh0dHBzOi8vbW9uZ29vc2Vqcy5jb20vZG9jcy9hcGkvc2NoZW1hdHlwZS5odG1sIiwicmVxdWVzdF9pZCI6Ijg2MUU6MTFGRjY6QzI2OEI2OkQwRTVBRTo2MkNBM0VFNyIsInZpc2l0b3JfaWQiOiI1MzYwMzM0NDgwODkxMDY4MDkwIiwicmVnaW9uX2VkZ2UiOiJmcmEiLCJyZWdpb25fcmVuZGVyIjoiZnJhIn0=" data-pjax-transient="true"/><meta name="visitor-hmac" content="4699069e8622d0f86c7bdf5d431e2aeee775f4d6e6fe5110d79ded5ac4a8f561" data-pjax-transient="true"/>

    <meta name="hovercard-subject-tag" content="repository:965782" data-pjax-transient>


  <meta name="github-keyboard-shortcuts" content="repository" data-pjax-transient="true" />
  

  <meta name="selected-link" value="repo_source" data-pjax-transient>

    <meta name="google-site-verification" content="c1kuD-K2HIVF635lypcsWPoD4kilo5-jA_wBFyT4uMY">
  <meta name="google-site-verification" content="KT5gs8h0wvaagLKAVWq8bbeNwnZZK1r1XQysX3xurLU">
  <meta name="google-site-verification" content="ZzhVyEFwb7w3e0-uOTltm8Jsck2F5StVihD0exw2fsA">
  <meta name="google-site-verification" content="GXs5KoUUkNCoaAZn7wPN-t01Pywp9M3sEjnt_3_ZWPc">

<meta name="octolytics-url" content="https://collector.github.com/github/collect" />

  <meta name="analytics-location" content="/&lt;user-name&gt;/&lt;repo-name&gt;" data-pjax-transient="true" />

  




  

    <meta name="user-login" content="">

    <meta name="viewport" content="width=device-width">
    
      <meta name="description" content="String validation. Contribute to validatorjs/validator.js development by creating an account on GitHub.">
      <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
    <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
    <meta property="fb:app_id" content="1401488693436528">
    <meta name="apple-itunes-app" content="app-id=1477376905" />
      <meta name="twitter:image:src" content="https://opengraph.githubassets.com/a4c2577b08718f46c9c0e04c2d9d734b8576c580beddce965b8e2a8a92654c50/validatorjs/validator.js" /><meta name="twitter:site" content="@github" /><meta name="twitter:card" content="summary_large_image" /><meta name="twitter:title" content="GitHub - validatorjs/validator.js: String validation" /><meta name="twitter:description" content="String validation. Contribute to validatorjs/validator.js development by creating an account on GitHub." />
      <meta property="og:image" content="https://opengraph.githubassets.com/a4c2577b08718f46c9c0e04c2d9d734b8576c580beddce965b8e2a8a92654c50/validatorjs/validator.js" /><meta property="og:image:alt" content="String validation. Contribute to validatorjs/validator.js development by creating an account on GitHub." /><meta property="og:image:width" content="1200" /><meta property="og:image:height" content="600" /><meta property="og:site_name" content="GitHub" /><meta property="og:type" content="object" /><meta property="og:title" content="GitHub - validatorjs/validator.js: String validation" /><meta property="og:url" content="https://github.com/validatorjs/validator.js" /><meta property="og:description" content="String validation. Contribute to validatorjs/validator.js development by creating an account on GitHub." />
      
    <link rel="assets" href="https://github.githubassets.com/">
    


        <meta name="hostname" content="github.com">



        <meta name="expected-hostname" content="github.com">

    <meta name="enabled-features" content="IMAGE_METRIC_TRACKING,GEOJSON_AZURE_MAPS">


  <meta http-equiv="x-pjax-version" content="f1fd3893e68f50454c5316f0d8c515afde27c6a7dd8a0a19fc3f33608620612b" data-turbo-track="reload">
  <meta http-equiv="x-pjax-csp-version" content="485d6a5ccbb1eeae9c86b616b4870b531f6f458e8bd5c309c40280dc4f51defb" data-turbo-track="reload">
  <meta http-equiv="x-pjax-css-version" content="ca68c383111ae2bdf3846f2bb959b1ccc632871efa80f03714afc00024c4a733" data-turbo-track="reload">
  <meta http-equiv="x-pjax-js-version" content="12f34aa3adab8dba14618dc8ef7b1b39e025bf64156956251603245aff687188" data-turbo-track="reload">

  <meta name="turbo-cache-control" content="no-preview" data-pjax-transient="">

    
  <meta name="go-import" content="github.com/validatorjs/validator.js git https://github.com/validatorjs/validator.js.git">

  <meta name="octolytics-dimension-user_id" content="52114810" /><meta name="octolytics-dimension-user_login" content="validatorjs" /><meta name="octolytics-dimension-repository_id" content="965782" /><meta name="octolytics-dimension-repository_nwo" content="validatorjs/validator.js" /><meta name="octolytics-dimension-repository_public" content="true" /><meta name="octolytics-dimension-repository_is_fork" content="false" /><meta name="octolytics-dimension-repository_network_root_id" content="965782" /><meta name="octolytics-dimension-repository_network_root_nwo" content="validatorjs/validator.js" />



    <link rel="canonical" href="https://github.com/validatorjs/validator.js" data-pjax-transient>
  <meta name="turbo-body-classes" content="logged-out env-production page-responsive">


  <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">

  <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">

  <meta name="browser-optimizely-client-errors-url" content="https://api.github.com/_private/browser/optimizely_client/errors">

  <link rel="mask-icon" href="https://github.githubassets.com/pinned-octocat.svg" color="#000000">
  <link rel="alternate icon" class="js-site-favicon" type="image/png" href="https://github.githubassets.com/favicons/favicon.png">
  <link rel="icon" class="js-site-favicon" type="image/svg+xml" href="https://github.githubassets.com/favicons/favicon.svg">

<meta name="theme-color" content="#1e2327">
<meta name="color-scheme" content="light dark" />


  <link rel="manifest" href="/manifest.json" crossOrigin="use-credentials">

  </head>

  <body class="logged-out env-production page-responsive" style="word-wrap: break-word;">
    

    <div class="position-relative js-header-wrapper ">
      <a href="#start-of-content" class="px-2 py-4 color-bg-accent-emphasis color-fg-on-emphasis show-on-focus js-skip-to-content">Skip to content</a>
      <span data-view-component="true" class="progress-pjax-loader js-pjax-loader-bar Progress position-fixed width-full">
    <span style="width: 0%;" data-view-component="true" class="Progress-item progress-pjax-loader-bar left-0 top-0 color-bg-accent-emphasis"></span>
</span>      
      


        

            <script crossorigin="anonymous" defer="defer" type="application/javascript" integrity="sha512-J6lR4iW7FvBnTJHgra5DhPqvM1qWXmgI8QRAMSZMaqbscHR4w3EfHJJ1FRDFVBm8bShmPNzvwF/17QHJnNhB6g==" src="https://github.githubassets.com/assets/sessions-27a951e225bb.js"></script>
<header class="Header-old header-logged-out js-details-container Details position-relative f4 py-2" role="banner">
  <div class="container-xl d-lg-flex flex-items-center p-responsive">
    <div class="d-flex flex-justify-between flex-items-center">
      <a class="mr-4 color-fg-inherit" href="https://github.com/" aria-label="Homepage" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
        <svg height="32" aria-hidden="true" viewBox="0 0 16 16" version="1.1" width="32" data-view-component="true" class="octicon octicon-mark-github">
    <path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"></path>
</svg>
      </a>

        <div class="d-lg-none css-truncate css-truncate-target width-fit p-2">
          

        </div>

      <div class="d-flex flex-items-center">
            <a href="/signup?ref_cta=Sign+up&amp;ref_loc=header+logged+out&amp;ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E&amp;source=header-repo"
              class="d-inline-block d-lg-none f5 no-underline border color-border-default rounded-2 px-2 py-1 mr-3 mr-sm-5 color-fg-inherit"
              data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;site header&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;SIGN_UP&quot;,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="ffd48c3942d3a9e6b1857f3b3888bfd0ef9dd0d68696018c5ef745e2fb9e1abc"
            >
              Sign&nbsp;up
            </a>

        <button aria-label="Toggle navigation" aria-expanded="false" type="button" data-view-component="true" class="js-details-target btn-link d-lg-none mt-1 color-fg-inherit">  <svg aria-hidden="true" height="24" viewBox="0 0 16 16" version="1.1" width="24" data-view-component="true" class="octicon octicon-three-bars">
    <path fill-rule="evenodd" d="M1 2.75A.75.75 0 011.75 2h12.5a.75.75 0 110 1.5H1.75A.75.75 0 011 2.75zm0 5A.75.75 0 011.75 7h12.5a.75.75 0 110 1.5H1.75A.75.75 0 011 7.75zM1.75 12a.75.75 0 100 1.5h12.5a.75.75 0 100-1.5H1.75z"></path>
</svg>
  
</button>      </div>
    </div>

    <div class="HeaderMenu HeaderMenu--logged-out position-fixed top-0 right-0 bottom-0 height-fit position-lg-relative d-lg-flex flex-justify-between flex-items-center flex-auto">
      <div class="d-flex d-lg-none flex-justify-end border-bottom color-bg-subtle p-3">
        <button aria-label="Toggle navigation" aria-expanded="false" type="button" data-view-component="true" class="js-details-target btn-link">  <svg aria-hidden="true" height="24" viewBox="0 0 24 24" version="1.1" width="24" data-view-component="true" class="octicon octicon-x color-fg-muted">
    <path fill-rule="evenodd" d="M5.72 5.72a.75.75 0 011.06 0L12 10.94l5.22-5.22a.75.75 0 111.06 1.06L13.06 12l5.22 5.22a.75.75 0 11-1.06 1.06L12 13.06l-5.22 5.22a.75.75 0 01-1.06-1.06L10.94 12 5.72 6.78a.75.75 0 010-1.06z"></path>
</svg>
  
</button>      </div>

        <nav class="mt-0 px-3 px-lg-0 mb-5 mb-lg-0" aria-label="Global">
          <ul class="d-lg-flex list-style-none">
              <li class="mr-0 mr-lg-3 position-relative flex-wrap flex-justify-between flex-items-center border-bottom border-lg-bottom-0 d-block d-lg-flex flex-lg-nowrap flex-lg-items-center">
    <details class="HeaderMenu-details details-overlay details-reset width-full">
      <summary class="HeaderMenu-summary HeaderMenu-link px-0 py-3 border-0 no-wrap d-block d-lg-inline-block">
        Product
        <svg x="0" y="0" viewBox="0 0 14 8" xml:space="preserve" fill="none" class="icon-chevon-down-mktg position-absolute position-lg-relative"><path d="M1,1l6.2,6L13,1"></path></svg>
      </summary>
      <div class="dropdown-menu flex-auto rounded px-0 mt-0 pb-4 p-lg-4 position-relative position-lg-absolute left-0 left-lg-n4">
        <ul class="list-style-none f5 pb-1">
              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--primary text-bold py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Features&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Features;&quot;}" href="/features">
      Features
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Mobile&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Mobile;&quot;}" href="/mobile">
      Mobile
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Actions&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Actions;&quot;}" href="/features/actions">
      Actions
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Codespaces&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Codespaces;&quot;}" href="/features/codespaces">
      Codespaces
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Copilot&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Copilot;&quot;}" href="/features/copilot">
      Copilot
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Packages&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Packages;&quot;}" href="/features/packages">
      Packages
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Security&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Security;&quot;}" href="/features/security">
      Security
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Code review&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Code review;&quot;}" href="/features/code-review">
      Code review
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Issues&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Issues;&quot;}" href="/features/issues">
      Issues
</a>  </li>

            
              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Integrations&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Integrations;&quot;}" href="/features/integrations">
      Integrations
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--primary text-bold border-top pt-4 pb-2 mt-3" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to GitHub Sponsors&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:GitHub Sponsors;&quot;}" href="/sponsors">
      GitHub Sponsors
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--primary text-bold py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Product&quot;,&quot;action&quot;:&quot;click to go to Customer stories&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Customer stories;&quot;}" href="/customer-stories">
      Customer stories
</a>  </li>

        </ul>
      </div>
    </details>
</li>


              <li class="mr-0 mr-lg-3 position-relative flex-wrap flex-justify-between flex-items-center border-bottom border-lg-bottom-0 d-block d-lg-flex flex-lg-nowrap flex-lg-items-center">
    <a class="HeaderMenu-link no-underline py-3 d-block d-lg-inline-block" data-analytics-event="{&quot;category&quot;:&quot;Header menu top item (logged out)&quot;,&quot;action&quot;:&quot;click to go to Team&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Team;&quot;}" href="/team">Team</a>
</li>

              <li class="mr-0 mr-lg-3 position-relative flex-wrap flex-justify-between flex-items-center border-bottom border-lg-bottom-0 d-block d-lg-flex flex-lg-nowrap flex-lg-items-center">
    <a class="HeaderMenu-link no-underline py-3 d-block d-lg-inline-block" data-analytics-event="{&quot;category&quot;:&quot;Header menu top item (logged out)&quot;,&quot;action&quot;:&quot;click to go to Enterprise&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Enterprise;&quot;}" href="/enterprise">Enterprise</a>
</li>


            <li class="mr-0 mr-lg-3 position-relative flex-wrap flex-justify-between flex-items-center border-bottom border-lg-bottom-0 d-block d-lg-flex flex-lg-nowrap flex-lg-items-center">
    <details class="HeaderMenu-details details-overlay details-reset width-full">
      <summary class="HeaderMenu-summary HeaderMenu-link px-0 py-3 border-0 no-wrap d-block d-lg-inline-block">
        Explore
        <svg x="0" y="0" viewBox="0 0 14 8" xml:space="preserve" fill="none" class="icon-chevon-down-mktg position-absolute position-lg-relative"><path d="M1,1l6.2,6L13,1"></path></svg>
      </summary>
      <div class="dropdown-menu flex-auto rounded px-0 mt-0 pb-4 p-lg-4 position-relative position-lg-absolute left-0 left-lg-n4">
        <ul class="list-style-none f5 pb-1">
              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--primary text-bold py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to Explore GitHub&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Explore GitHub;&quot;}" href="/explore">
      Explore GitHub
</a>  </li>

              <li class="color-fg-muted text-normal f6 text-mono mb-1 border-top pt-3 mt-3 mb-1">Learn and contribute</li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to Topics&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Topics;&quot;}" href="/topics">
      Topics
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to Collections&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Collections;&quot;}" href="/collections">
      Collections
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to Trending&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Trending;&quot;}" href="/trending">
      Trending
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to Skills&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Skills;&quot;}" href="https://skills.github.com/">
      Skills
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to GitHub Sponsors&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:GitHub Sponsors;&quot;}" href="/sponsors/explore">
      GitHub Sponsors
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to Open source guides&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Open source guides;&quot;}" href="https://opensource.guide">
      Open source guides
</a>  </li>

              <li class="color-fg-muted text-normal f6 text-mono mb-1 border-top pt-3 mt-3 mb-1">Connect with others</li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to The ReadME Project&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:The ReadME Project;&quot;}" href="/readme">
      The ReadME Project
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to Events&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Events;&quot;}" href="/events">
      Events
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to Community forum&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Community forum;&quot;}" href="https://github.community">
      Community forum
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to GitHub Education&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:GitHub Education;&quot;}" href="https://education.github.com">
      GitHub Education
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Explore&quot;,&quot;action&quot;:&quot;click to go to GitHub Stars program&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:GitHub Stars program;&quot;}" href="https://stars.github.com">
      GitHub Stars program
</a>  </li>

        </ul>
      </div>
    </details>
</li>


            <li class="mr-0 mr-lg-3 position-relative flex-wrap flex-justify-between flex-items-center border-bottom border-lg-bottom-0 d-block d-lg-flex flex-lg-nowrap flex-lg-items-center">
    <a class="HeaderMenu-link no-underline py-3 d-block d-lg-inline-block" data-analytics-event="{&quot;category&quot;:&quot;Header menu top item (logged out)&quot;,&quot;action&quot;:&quot;click to go to Marketplace&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Marketplace;&quot;}" href="/marketplace">Marketplace</a>
</li>


            <li class="mr-0 mr-lg-3 position-relative flex-wrap flex-justify-between flex-items-center border-bottom border-lg-bottom-0 d-block d-lg-flex flex-lg-nowrap flex-lg-items-center">
    <details class="HeaderMenu-details details-overlay details-reset width-full">
      <summary class="HeaderMenu-summary HeaderMenu-link px-0 py-3 border-0 no-wrap d-block d-lg-inline-block">
        Pricing
        <svg x="0" y="0" viewBox="0 0 14 8" xml:space="preserve" fill="none" class="icon-chevon-down-mktg position-absolute position-lg-relative"><path d="M1,1l6.2,6L13,1"></path></svg>
      </summary>
      <div class="dropdown-menu flex-auto rounded px-0 mt-0 pb-4 p-lg-4 position-relative position-lg-absolute left-0 left-lg-n4">
        <ul class="list-style-none f5 pb-1">
              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--primary text-bold py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Pricing&quot;,&quot;action&quot;:&quot;click to go to Plans&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Plans;&quot;}" href="/pricing">
      Plans
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Pricing&quot;,&quot;action&quot;:&quot;click to go to Compare plans&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Compare plans;&quot;}" href="/pricing#compare-features">
      Compare plans
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--secondary py-2" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Pricing&quot;,&quot;action&quot;:&quot;click to go to Contact Sales&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Contact Sales;&quot;}" href="https://github.com/enterprise/contact">
      Contact Sales
</a>  </li>

              <li>
    <a class="lh-condensed-ultra d-block no-underline position-relative Link--primary text-bold border-top pt-4 pb-2 mt-3" data-analytics-event="{&quot;category&quot;:&quot;Header dropdown (logged out), Pricing&quot;,&quot;action&quot;:&quot;click to go to Education&quot;,&quot;label&quot;:&quot;ref_page:/validatorjs/validator.js;ref_cta:Education;&quot;}" href="https://education.github.com">
      Education
</a>  </li>

        </ul>
      </div>
    </details>
</li>

          </ul>
        </nav>

      <div class="d-lg-flex flex-items-center px-3 px-lg-0 text-center text-lg-left">
          <div class="d-lg-flex min-width-0 mb-3 mb-lg-0">
            



<div class="header-search flex-auto js-site-search position-relative flex-self-stretch flex-md-self-auto mb-3 mb-md-0 mr-0 mr-md-3 scoped-search site-scoped-search js-jump-to"
>
  <div class="position-relative">
    <!-- '"` --><!-- </textarea></xmp> --></option></form><form class="js-site-search-form" role="search" aria-label="Site" data-scope-type="Repository" data-scope-id="965782" data-scoped-search-url="/validatorjs/validator.js/search" data-owner-scoped-search-url="/orgs/validatorjs/search" data-unscoped-search-url="/search" data-turbo="false" action="/validatorjs/validator.js/search" accept-charset="UTF-8" method="get">
      <label class="form-control input-sm header-search-wrapper p-0 js-chromeless-input-container header-search-wrapper-jump-to position-relative d-flex flex-justify-between flex-items-center">
        <input type="text"
          class="form-control input-sm header-search-input jump-to-field js-jump-to-field js-site-search-focus js-site-search-field is-clearable"
          data-hotkey=s,/
          name="q"
          data-test-selector="nav-search-input"
          placeholder="Search"
          data-unscoped-placeholder="Search GitHub"
          data-scoped-placeholder="Search"
          autocapitalize="off"
          role="combobox"
          aria-haspopup="listbox"
          aria-expanded="false"
          aria-autocomplete="list"
          aria-controls="jump-to-results"
          aria-label="Search"
          data-jump-to-suggestions-path="/_graphql/GetSuggestedNavigationDestinations"
          spellcheck="false"
          autocomplete="off"
        >
        <input type="hidden" data-csrf="true" class="js-data-jump-to-suggestions-path-csrf" value="JqiCOf3/ovAZsWnobmg3sXezJak2gp0ROsBOlOyaCrEUQy39qeSNuvKPPpV4JgD3JsOp0mwF0NY1Dxp9sC782Q==" />
        <input type="hidden" class="js-site-search-type-field" name="type" >
            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="20" aria-hidden="true" class="mr-1 header-search-key-slash"><path fill="none" stroke="#979A9C" opacity=".4" d="M3.5.5h12c1.7 0 3 1.3 3 3v13c0 1.7-1.3 3-3 3h-12c-1.7 0-3-1.3-3-3v-13c0-1.7 1.3-3 3-3z"></path><path fill="#979A9C" d="M11.8 6L8 15.1h-.9L10.8 6h1z"></path></svg>


          <div class="Box position-absolute overflow-hidden d-none jump-to-suggestions js-jump-to-suggestions-container">
            
<ul class="d-none js-jump-to-suggestions-template-container">
  

<li class="d-flex flex-justify-start flex-items-center p-0 f5 navigation-item js-navigation-item js-jump-to-suggestion" role="option">
  <a tabindex="-1" class="no-underline d-flex flex-auto flex-items-center jump-to-suggestions-path js-jump-to-suggestion-path js-navigation-open p-2" href="" data-item-type="suggestion">
    <div class="jump-to-octicon js-jump-to-octicon flex-shrink-0 mr-2 text-center d-none">
      <svg title="Repository" aria-label="Repository" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo js-jump-to-octicon-repo d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M2 2.5A2.5 2.5 0 014.5 0h8.75a.75.75 0 01.75.75v12.5a.75.75 0 01-.75.75h-2.5a.75.75 0 110-1.5h1.75v-2h-8a1 1 0 00-.714 1.7.75.75 0 01-1.072 1.05A2.495 2.495 0 012 11.5v-9zm10.5-1V9h-8c-.356 0-.694.074-1 .208V2.5a1 1 0 011-1h8zM5 12.25v3.25a.25.25 0 00.4.2l1.45-1.087a.25.25 0 01.3 0L8.6 15.7a.25.25 0 00.4-.2v-3.25a.25.25 0 00-.25-.25h-3.5a.25.25 0 00-.25.25z"></path>
</svg>
      <svg title="Project" aria-label="Project" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-project js-jump-to-octicon-project d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M1.75 0A1.75 1.75 0 000 1.75v12.5C0 15.216.784 16 1.75 16h12.5A1.75 1.75 0 0016 14.25V1.75A1.75 1.75 0 0014.25 0H1.75zM1.5 1.75a.25.25 0 01.25-.25h12.5a.25.25 0 01.25.25v12.5a.25.25 0 01-.25.25H1.75a.25.25 0 01-.25-.25V1.75zM11.75 3a.75.75 0 00-.75.75v7.5a.75.75 0 001.5 0v-7.5a.75.75 0 00-.75-.75zm-8.25.75a.75.75 0 011.5 0v5.5a.75.75 0 01-1.5 0v-5.5zM8 3a.75.75 0 00-.75.75v3.5a.75.75 0 001.5 0v-3.5A.75.75 0 008 3z"></path>
</svg>
      <svg title="Search" aria-label="Search" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search js-jump-to-octicon-search d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M11.5 7a4.499 4.499 0 11-8.998 0A4.499 4.499 0 0111.5 7zm-.82 4.74a6 6 0 111.06-1.06l3.04 3.04a.75.75 0 11-1.06 1.06l-3.04-3.04z"></path>
</svg>
    </div>

    <img class="avatar mr-2 flex-shrink-0 js-jump-to-suggestion-avatar d-none" alt="" aria-label="Team" src="" width="28" height="28">

    <div class="jump-to-suggestion-name js-jump-to-suggestion-name flex-auto overflow-hidden text-left no-wrap css-truncate css-truncate-target">
    </div>

    <div class="border rounded-2 flex-shrink-0 color-bg-subtle px-1 color-fg-muted ml-1 f6 d-none js-jump-to-badge-search">
      <span class="js-jump-to-badge-search-text-default d-none" aria-label="in this repository">
        In this repository
      </span>
      <span class="js-jump-to-badge-search-text-global d-none" aria-label="in all of GitHub">
        All GitHub
      </span>
      <span aria-hidden="true" class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>

    <div aria-hidden="true" class="border rounded-2 flex-shrink-0 color-bg-subtle px-1 color-fg-muted ml-1 f6 d-none d-on-nav-focus js-jump-to-badge-jump">
      Jump to
      <span class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>
  </a>
</li>

</ul>

<ul class="d-none js-jump-to-no-results-template-container">
  <li class="d-flex flex-justify-center flex-items-center f5 d-none js-jump-to-suggestion p-2">
    <span class="color-fg-muted">No suggested jump to results</span>
  </li>
</ul>

<ul id="jump-to-results" role="listbox" class="p-0 m-0 js-navigation-container jump-to-suggestions-results-container js-jump-to-suggestions-results-container">
  

<li class="d-flex flex-justify-start flex-items-center p-0 f5 navigation-item js-navigation-item js-jump-to-scoped-search d-none" role="option">
  <a tabindex="-1" class="no-underline d-flex flex-auto flex-items-center jump-to-suggestions-path js-jump-to-suggestion-path js-navigation-open p-2" href="" data-item-type="scoped_search">
    <div class="jump-to-octicon js-jump-to-octicon flex-shrink-0 mr-2 text-center d-none">
      <svg title="Repository" aria-label="Repository" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo js-jump-to-octicon-repo d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M2 2.5A2.5 2.5 0 014.5 0h8.75a.75.75 0 01.75.75v12.5a.75.75 0 01-.75.75h-2.5a.75.75 0 110-1.5h1.75v-2h-8a1 1 0 00-.714 1.7.75.75 0 01-1.072 1.05A2.495 2.495 0 012 11.5v-9zm10.5-1V9h-8c-.356 0-.694.074-1 .208V2.5a1 1 0 011-1h8zM5 12.25v3.25a.25.25 0 00.4.2l1.45-1.087a.25.25 0 01.3 0L8.6 15.7a.25.25 0 00.4-.2v-3.25a.25.25 0 00-.25-.25h-3.5a.25.25 0 00-.25.25z"></path>
</svg>
      <svg title="Project" aria-label="Project" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-project js-jump-to-octicon-project d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M1.75 0A1.75 1.75 0 000 1.75v12.5C0 15.216.784 16 1.75 16h12.5A1.75 1.75 0 0016 14.25V1.75A1.75 1.75 0 0014.25 0H1.75zM1.5 1.75a.25.25 0 01.25-.25h12.5a.25.25 0 01.25.25v12.5a.25.25 0 01-.25.25H1.75a.25.25 0 01-.25-.25V1.75zM11.75 3a.75.75 0 00-.75.75v7.5a.75.75 0 001.5 0v-7.5a.75.75 0 00-.75-.75zm-8.25.75a.75.75 0 011.5 0v5.5a.75.75 0 01-1.5 0v-5.5zM8 3a.75.75 0 00-.75.75v3.5a.75.75 0 001.5 0v-3.5A.75.75 0 008 3z"></path>
</svg>
      <svg title="Search" aria-label="Search" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search js-jump-to-octicon-search d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M11.5 7a4.499 4.499 0 11-8.998 0A4.499 4.499 0 0111.5 7zm-.82 4.74a6 6 0 111.06-1.06l3.04 3.04a.75.75 0 11-1.06 1.06l-3.04-3.04z"></path>
</svg>
    </div>

    <img class="avatar mr-2 flex-shrink-0 js-jump-to-suggestion-avatar d-none" alt="" aria-label="Team" src="" width="28" height="28">

    <div class="jump-to-suggestion-name js-jump-to-suggestion-name flex-auto overflow-hidden text-left no-wrap css-truncate css-truncate-target">
    </div>

    <div class="border rounded-2 flex-shrink-0 color-bg-subtle px-1 color-fg-muted ml-1 f6 d-none js-jump-to-badge-search">
      <span class="js-jump-to-badge-search-text-default d-none" aria-label="in this repository">
        In this repository
      </span>
      <span class="js-jump-to-badge-search-text-global d-none" aria-label="in all of GitHub">
        All GitHub
      </span>
      <span aria-hidden="true" class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>

    <div aria-hidden="true" class="border rounded-2 flex-shrink-0 color-bg-subtle px-1 color-fg-muted ml-1 f6 d-none d-on-nav-focus js-jump-to-badge-jump">
      Jump to
      <span class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>
  </a>
</li>

  

<li class="d-flex flex-justify-start flex-items-center p-0 f5 navigation-item js-navigation-item js-jump-to-owner-scoped-search d-none" role="option">
  <a tabindex="-1" class="no-underline d-flex flex-auto flex-items-center jump-to-suggestions-path js-jump-to-suggestion-path js-navigation-open p-2" href="" data-item-type="owner_scoped_search">
    <div class="jump-to-octicon js-jump-to-octicon flex-shrink-0 mr-2 text-center d-none">
      <svg title="Repository" aria-label="Repository" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo js-jump-to-octicon-repo d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M2 2.5A2.5 2.5 0 014.5 0h8.75a.75.75 0 01.75.75v12.5a.75.75 0 01-.75.75h-2.5a.75.75 0 110-1.5h1.75v-2h-8a1 1 0 00-.714 1.7.75.75 0 01-1.072 1.05A2.495 2.495 0 012 11.5v-9zm10.5-1V9h-8c-.356 0-.694.074-1 .208V2.5a1 1 0 011-1h8zM5 12.25v3.25a.25.25 0 00.4.2l1.45-1.087a.25.25 0 01.3 0L8.6 15.7a.25.25 0 00.4-.2v-3.25a.25.25 0 00-.25-.25h-3.5a.25.25 0 00-.25.25z"></path>
</svg>
      <svg title="Project" aria-label="Project" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-project js-jump-to-octicon-project d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M1.75 0A1.75 1.75 0 000 1.75v12.5C0 15.216.784 16 1.75 16h12.5A1.75 1.75 0 0016 14.25V1.75A1.75 1.75 0 0014.25 0H1.75zM1.5 1.75a.25.25 0 01.25-.25h12.5a.25.25 0 01.25.25v12.5a.25.25 0 01-.25.25H1.75a.25.25 0 01-.25-.25V1.75zM11.75 3a.75.75 0 00-.75.75v7.5a.75.75 0 001.5 0v-7.5a.75.75 0 00-.75-.75zm-8.25.75a.75.75 0 011.5 0v5.5a.75.75 0 01-1.5 0v-5.5zM8 3a.75.75 0 00-.75.75v3.5a.75.75 0 001.5 0v-3.5A.75.75 0 008 3z"></path>
</svg>
      <svg title="Search" aria-label="Search" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search js-jump-to-octicon-search d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M11.5 7a4.499 4.499 0 11-8.998 0A4.499 4.499 0 0111.5 7zm-.82 4.74a6 6 0 111.06-1.06l3.04 3.04a.75.75 0 11-1.06 1.06l-3.04-3.04z"></path>
</svg>
    </div>

    <img class="avatar mr-2 flex-shrink-0 js-jump-to-suggestion-avatar d-none" alt="" aria-label="Team" src="" width="28" height="28">

    <div class="jump-to-suggestion-name js-jump-to-suggestion-name flex-auto overflow-hidden text-left no-wrap css-truncate css-truncate-target">
    </div>

    <div class="border rounded-2 flex-shrink-0 color-bg-subtle px-1 color-fg-muted ml-1 f6 d-none js-jump-to-badge-search">
      <span class="js-jump-to-badge-search-text-default d-none" aria-label="in this organization">
        In this organization
      </span>
      <span class="js-jump-to-badge-search-text-global d-none" aria-label="in all of GitHub">
        All GitHub
      </span>
      <span aria-hidden="true" class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>

    <div aria-hidden="true" class="border rounded-2 flex-shrink-0 color-bg-subtle px-1 color-fg-muted ml-1 f6 d-none d-on-nav-focus js-jump-to-badge-jump">
      Jump to
      <span class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>
  </a>
</li>

  

<li class="d-flex flex-justify-start flex-items-center p-0 f5 navigation-item js-navigation-item js-jump-to-global-search d-none" role="option">
  <a tabindex="-1" class="no-underline d-flex flex-auto flex-items-center jump-to-suggestions-path js-jump-to-suggestion-path js-navigation-open p-2" href="" data-item-type="global_search">
    <div class="jump-to-octicon js-jump-to-octicon flex-shrink-0 mr-2 text-center d-none">
      <svg title="Repository" aria-label="Repository" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo js-jump-to-octicon-repo d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M2 2.5A2.5 2.5 0 014.5 0h8.75a.75.75 0 01.75.75v12.5a.75.75 0 01-.75.75h-2.5a.75.75 0 110-1.5h1.75v-2h-8a1 1 0 00-.714 1.7.75.75 0 01-1.072 1.05A2.495 2.495 0 012 11.5v-9zm10.5-1V9h-8c-.356 0-.694.074-1 .208V2.5a1 1 0 011-1h8zM5 12.25v3.25a.25.25 0 00.4.2l1.45-1.087a.25.25 0 01.3 0L8.6 15.7a.25.25 0 00.4-.2v-3.25a.25.25 0 00-.25-.25h-3.5a.25.25 0 00-.25.25z"></path>
</svg>
      <svg title="Project" aria-label="Project" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-project js-jump-to-octicon-project d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M1.75 0A1.75 1.75 0 000 1.75v12.5C0 15.216.784 16 1.75 16h12.5A1.75 1.75 0 0016 14.25V1.75A1.75 1.75 0 0014.25 0H1.75zM1.5 1.75a.25.25 0 01.25-.25h12.5a.25.25 0 01.25.25v12.5a.25.25 0 01-.25.25H1.75a.25.25 0 01-.25-.25V1.75zM11.75 3a.75.75 0 00-.75.75v7.5a.75.75 0 001.5 0v-7.5a.75.75 0 00-.75-.75zm-8.25.75a.75.75 0 011.5 0v5.5a.75.75 0 01-1.5 0v-5.5zM8 3a.75.75 0 00-.75.75v3.5a.75.75 0 001.5 0v-3.5A.75.75 0 008 3z"></path>
</svg>
      <svg title="Search" aria-label="Search" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search js-jump-to-octicon-search d-none flex-shrink-0">
    <path fill-rule="evenodd" d="M11.5 7a4.499 4.499 0 11-8.998 0A4.499 4.499 0 0111.5 7zm-.82 4.74a6 6 0 111.06-1.06l3.04 3.04a.75.75 0 11-1.06 1.06l-3.04-3.04z"></path>
</svg>
    </div>

    <img class="avatar mr-2 flex-shrink-0 js-jump-to-suggestion-avatar d-none" alt="" aria-label="Team" src="" width="28" height="28">

    <div class="jump-to-suggestion-name js-jump-to-suggestion-name flex-auto overflow-hidden text-left no-wrap css-truncate css-truncate-target">
    </div>

    <div class="border rounded-2 flex-shrink-0 color-bg-subtle px-1 color-fg-muted ml-1 f6 d-none js-jump-to-badge-search">
      <span class="js-jump-to-badge-search-text-default d-none" aria-label="in this repository">
        In this repository
      </span>
      <span class="js-jump-to-badge-search-text-global d-none" aria-label="in all of GitHub">
        All GitHub
      </span>
      <span aria-hidden="true" class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>

    <div aria-hidden="true" class="border rounded-2 flex-shrink-0 color-bg-subtle px-1 color-fg-muted ml-1 f6 d-none d-on-nav-focus js-jump-to-badge-jump">
      Jump to
      <span class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>
  </a>
</li>


</ul>

          </div>
      </label>
</form>  </div>
</div>

          </div>

        <div class="position-relative mr-3 mb-4 mb-lg-0 d-inline-block">
          <a href="/login?return_to=https%3A%2F%2Fgithub.com%2Fvalidatorjs%2Fvalidator.js"
            class="HeaderMenu-link flex-shrink-0 no-underline"
            data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;site header menu&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;SIGN_UP&quot;,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="de2c0df18e331780c9631409f0b834ec2b0c40f3f440a7a13801b0d96195b188"
            data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">
            Sign in
          </a>
        </div>

          <a href="/signup?ref_cta=Sign+up&amp;ref_loc=header+logged+out&amp;ref_page=%2F%3Cuser-name%3E%2F%3Crepo-name%3E&amp;source=header-repo&amp;source_repo=validatorjs%2Fvalidator.js"
            class="HeaderMenu-link flex-shrink-0 d-inline-block no-underline border color-border-default rounded px-2 py-1"
            data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;site header menu&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;SIGN_UP&quot;,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="de2c0df18e331780c9631409f0b834ec2b0c40f3f440a7a13801b0d96195b188"
            data-analytics-event="{&quot;category&quot;:&quot;Sign up&quot;,&quot;action&quot;:&quot;click to sign up for account&quot;,&quot;label&quot;:&quot;ref_page:/&lt;user-name&gt;/&lt;repo-name&gt;;ref_cta:Sign up;ref_loc:header logged out&quot;}"
          >
            Sign up
          </a>
      </div>
    </div>
  </div>
</header>

    </div>

  <div id="start-of-content" class="show-on-focus"></div>







    <div data-pjax-replace id="js-flash-container" data-turbo-replace>



  <template class="js-flash-template">
    <div class="flash flash-full  {{ className }}">
  <div class="px-2" >
    <button class="flash-close js-flash-close" type="button" aria-label="Dismiss this message">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path fill-rule="evenodd" d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.75.75 0 111.06 1.06L9.06 8l3.22 3.22a.75.75 0 11-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 01-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 010-1.06z"></path>
</svg>
    </button>
    
      <div>{{ message }}</div>

  </div>
</div>
  </template>
</div>


    
  <include-fragment class="js-notification-shelf-include-fragment" data-base-src="https://github.com/notifications/beta/shelf"></include-fragment>





  <div
    class="application-main "
    data-commit-hovercards-enabled
    data-discussion-hovercards-enabled
    data-issue-and-pr-hovercards-enabled
  >
        <div itemscope itemtype="http://schema.org/SoftwareSourceCode" class="">
    <main id="js-repo-pjax-container" data-pjax-container >
      
  




    
    








  <div id="repository-container-header" class="pt-3 hide-full-screen" style="background-color: var(--color-page-header-bg);" data-pjax-replace data-turbo-replace>

      <div class="d-flex mb-3 px-3 px-md-4 px-lg-5">

        <div class="flex-auto min-width-0 width-fit mr-3">
            <div class=" d-flex flex-wrap flex-items-center wb-break-word f3 text-normal">
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo color-fg-muted mr-2">
    <path fill-rule="evenodd" d="M2 2.5A2.5 2.5 0 014.5 0h8.75a.75.75 0 01.75.75v12.5a.75.75 0 01-.75.75h-2.5a.75.75 0 110-1.5h1.75v-2h-8a1 1 0 00-.714 1.7.75.75 0 01-1.072 1.05A2.495 2.495 0 012 11.5v-9zm10.5-1V9h-8c-.356 0-.694.074-1 .208V2.5a1 1 0 011-1h8zM5 12.25v3.25a.25.25 0 00.4.2l1.45-1.087a.25.25 0 01.3 0L8.6 15.7a.25.25 0 00.4-.2v-3.25a.25.25 0 00-.25-.25h-3.5a.25.25 0 00-.25.25z"></path>
</svg>
  <span class="author flex-self-stretch" itemprop="author">
    <a class="url fn" rel="author" data-hovercard-type="organization" data-hovercard-url="/orgs/validatorjs/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/validatorjs">validatorjs</a>
  </span>
  <span class="mx-1 flex-self-stretch color-fg-muted">/</span>
  <strong itemprop="name" class="mr-2 flex-self-stretch">
    <a data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js">validator.js</a>
  </strong>

  <span></span><span class="Label Label--secondary v-align-middle mr-1">Public</span>
</div>

        </div>

          <ul class="pagehead-actions flex-shrink-0 d-none d-md-inline" style="padding: 2px 0;">
      <li>
        <include-fragment src="/validatorjs/validator.js/sponsor_button"></include-fragment>
      </li>

    

  <li>
      <a href="/login?return_to=%2Fvalidatorjs%2Fvalidator.js" rel="nofollow" data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;notification subscription menu watch&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;LOG_IN&quot;,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="c01bc0f53f6002d354146e3849c850af43ccaab1a31f20f2f8aa90b67f5febbe" aria-label="You must be signed in to change notification settings" data-view-component="true" class="tooltipped tooltipped-s btn-sm btn">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-bell mr-2">
    <path d="M8 16a2 2 0 001.985-1.75c.017-.137-.097-.25-.235-.25h-3.5c-.138 0-.252.113-.235.25A2 2 0 008 16z"></path><path fill-rule="evenodd" d="M8 1.5A3.5 3.5 0 004.5 5v2.947c0 .346-.102.683-.294.97l-1.703 2.556a.018.018 0 00-.003.01l.001.006c0 .002.002.004.004.006a.017.017 0 00.006.004l.007.001h10.964l.007-.001a.016.016 0 00.006-.004.016.016 0 00.004-.006l.001-.007a.017.017 0 00-.003-.01l-1.703-2.554a1.75 1.75 0 01-.294-.97V5A3.5 3.5 0 008 1.5zM3 5a5 5 0 0110 0v2.947c0 .05.015.098.042.139l1.703 2.555A1.518 1.518 0 0113.482 13H2.518a1.518 1.518 0 01-1.263-2.36l1.703-2.554A.25.25 0 003 7.947V5z"></path>
</svg>Notifications
  
</a>
  </li>

  <li>
      
  <a href="/login?return_to=%2Fvalidatorjs%2Fvalidator.js" rel="nofollow" data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;repo details fork button&quot;,&quot;repository_id&quot;:965782,&quot;auth_type&quot;:&quot;LOG_IN&quot;,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="fcf52ca1402ba59509e7969790d0eb2e8916b55ba79842ddc6f23a96d8075daf" aria-label="You must be signed in to fork a repository" data-view-component="true" class="tooltipped tooltipped-s btn-sm btn">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo-forked mr-2">
    <path fill-rule="evenodd" d="M5 3.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm0 2.122a2.25 2.25 0 10-1.5 0v.878A2.25 2.25 0 005.75 8.5h1.5v2.128a2.251 2.251 0 101.5 0V8.5h1.5a2.25 2.25 0 002.25-2.25v-.878a2.25 2.25 0 10-1.5 0v.878a.75.75 0 01-.75.75h-4.5A.75.75 0 015 6.25v-.878zm3.75 7.378a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm3-8.75a.75.75 0 100-1.5.75.75 0 000 1.5z"></path>
</svg>Fork
    <span id="repo-network-counter" data-pjax-replace="true" title="1,954" data-view-component="true" class="Counter">2k</span>
  
</a>
  </li>

  <li>
        <div data-view-component="true" class="BtnGroup d-flex">
      <a href="/login?return_to=%2Fvalidatorjs%2Fvalidator.js" rel="nofollow" data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;star button&quot;,&quot;repository_id&quot;:965782,&quot;auth_type&quot;:&quot;LOG_IN&quot;,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="102a76e224f193858b1435cfb962874f1867f3a568dae15d18c047c6a0499dfb" aria-label="You must be signed in to star a repository" data-view-component="true" class="tooltipped tooltipped-s btn-sm btn BtnGroup-item">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-star v-align-text-bottom d-inline-block mr-2">
    <path fill-rule="evenodd" d="M8 .25a.75.75 0 01.673.418l1.882 3.815 4.21.612a.75.75 0 01.416 1.279l-3.046 2.97.719 4.192a.75.75 0 01-1.088.791L8 12.347l-3.766 1.98a.75.75 0 01-1.088-.79l.72-4.194L.818 6.374a.75.75 0 01.416-1.28l4.21-.611L7.327.668A.75.75 0 018 .25zm0 2.445L6.615 5.5a.75.75 0 01-.564.41l-3.097.45 2.24 2.184a.75.75 0 01.216.664l-.528 3.084 2.769-1.456a.75.75 0 01.698 0l2.77 1.456-.53-3.084a.75.75 0 01.216-.664l2.24-2.183-3.096-.45a.75.75 0 01-.564-.41L8 2.694v.001z"></path>
</svg><span data-view-component="true" class="d-inline">
          Star
</span>          <span id="repo-stars-counter-star" aria-label="19814 users starred this repository" data-singular-suffix="user starred this repository" data-plural-suffix="users starred this repository" data-pjax-replace="true" data-turbo-replace="true" title="19,814" data-view-component="true" class="Counter js-social-count">19.8k</span>
  
</a>      <button disabled="disabled" aria-label="You must be signed in to add this repository to a list" type="button" data-view-component="true" class="btn-sm btn BtnGroup-item px-2">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-triangle-down">
    <path d="M4.427 7.427l3.396 3.396a.25.25 0 00.354 0l3.396-3.396A.25.25 0 0011.396 7H4.604a.25.25 0 00-.177.427z"></path>
</svg>
  
</button></div>
  </li>

  

</ul>

      </div>

      <div id="responsive-meta-container" data-pjax-replace data-turbo-replace>
      <div class="d-block d-md-none mb-2 px-3 px-md-4 px-lg-5">
      <p class="f4 mb-3">
        String validation
      </p>

    <h3 class="sr-only">License</h3>
  <div class="mb-2">
    <a href="/validatorjs/validator.js/blob/master/LICENSE"
      class="Link--muted"
      
      data-analytics-event="{&quot;category&quot;:&quot;Repository Overview&quot;,&quot;action&quot;:&quot;click&quot;,&quot;label&quot;:&quot;location:sidebar;file:license&quot;}"
    >
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-law mr-2">
    <path fill-rule="evenodd" d="M8.75.75a.75.75 0 00-1.5 0V2h-.984c-.305 0-.604.08-.869.23l-1.288.737A.25.25 0 013.984 3H1.75a.75.75 0 000 1.5h.428L.066 9.192a.75.75 0 00.154.838l.53-.53-.53.53v.001l.002.002.002.002.006.006.016.015.045.04a3.514 3.514 0 00.686.45A4.492 4.492 0 003 11c.88 0 1.556-.22 2.023-.454a3.515 3.515 0 00.686-.45l.045-.04.016-.015.006-.006.002-.002.001-.002L5.25 9.5l.53.53a.75.75 0 00.154-.838L3.822 4.5h.162c.305 0 .604-.08.869-.23l1.289-.737a.25.25 0 01.124-.033h.984V13h-2.5a.75.75 0 000 1.5h6.5a.75.75 0 000-1.5h-2.5V3.5h.984a.25.25 0 01.124.033l1.29.736c.264.152.563.231.868.231h.162l-2.112 4.692a.75.75 0 00.154.838l.53-.53-.53.53v.001l.002.002.002.002.006.006.016.015.045.04a3.517 3.517 0 00.686.45A4.492 4.492 0 0013 11c.88 0 1.556-.22 2.023-.454a3.512 3.512 0 00.686-.45l.045-.04.01-.01.006-.005.006-.006.002-.002.001-.002-.529-.531.53.53a.75.75 0 00.154-.838L13.823 4.5h.427a.75.75 0 000-1.5h-2.234a.25.25 0 01-.124-.033l-1.29-.736A1.75 1.75 0 009.735 2H8.75V.75zM1.695 9.227c.285.135.718.273 1.305.273s1.02-.138 1.305-.273L3 6.327l-1.305 2.9zm10 0c.285.135.718.273 1.305.273s1.02-.138 1.305-.273L13 6.327l-1.305 2.9z"></path>
</svg>
     MIT license
    </a>
  </div>


    <div class="mb-3">
      <a class="Link--secondary no-underline mr-3" href="/validatorjs/validator.js/stargazers">
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-star mr-1">
    <path fill-rule="evenodd" d="M8 .25a.75.75 0 01.673.418l1.882 3.815 4.21.612a.75.75 0 01.416 1.279l-3.046 2.97.719 4.192a.75.75 0 01-1.088.791L8 12.347l-3.766 1.98a.75.75 0 01-1.088-.79l.72-4.194L.818 6.374a.75.75 0 01.416-1.28l4.21-.611L7.327.668A.75.75 0 018 .25zm0 2.445L6.615 5.5a.75.75 0 01-.564.41l-3.097.45 2.24 2.184a.75.75 0 01.216.664l-.528 3.084 2.769-1.456a.75.75 0 01.698 0l2.77 1.456-.53-3.084a.75.75 0 01.216-.664l2.24-2.183-3.096-.45a.75.75 0 01-.564-.41L8 2.694v.001z"></path>
</svg>
        <span class="text-bold">19.8k</span>
        stars
</a>      <a class="Link--secondary no-underline" href="/validatorjs/validator.js/network/members">
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo-forked mr-1">
    <path fill-rule="evenodd" d="M5 3.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm0 2.122a2.25 2.25 0 10-1.5 0v.878A2.25 2.25 0 005.75 8.5h1.5v2.128a2.251 2.251 0 101.5 0V8.5h1.5a2.25 2.25 0 002.25-2.25v-.878a2.25 2.25 0 10-1.5 0v.878a.75.75 0 01-.75.75h-4.5A.75.75 0 015 6.25v-.878zm3.75 7.378a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm3-8.75a.75.75 0 100-1.5.75.75 0 000 1.5z"></path>
</svg>
        <span class="text-bold">2k</span>
        forks
</a>    </div>
    <div class="d-flex">
      <div class="flex-1 mr-2">
          <div data-view-component="true" class="BtnGroup d-flex">
      <a href="/login?return_to=%2Fvalidatorjs%2Fvalidator.js" rel="nofollow" data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;star button&quot;,&quot;repository_id&quot;:965782,&quot;auth_type&quot;:&quot;LOG_IN&quot;,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="102a76e224f193858b1435cfb962874f1867f3a568dae15d18c047c6a0499dfb" aria-label="You must be signed in to star a repository" data-view-component="true" class="tooltipped tooltipped-s btn-sm btn btn-block BtnGroup-item">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-star v-align-text-bottom d-inline-block mr-2">
    <path fill-rule="evenodd" d="M8 .25a.75.75 0 01.673.418l1.882 3.815 4.21.612a.75.75 0 01.416 1.279l-3.046 2.97.719 4.192a.75.75 0 01-1.088.791L8 12.347l-3.766 1.98a.75.75 0 01-1.088-.79l.72-4.194L.818 6.374a.75.75 0 01.416-1.28l4.21-.611L7.327.668A.75.75 0 018 .25zm0 2.445L6.615 5.5a.75.75 0 01-.564.41l-3.097.45 2.24 2.184a.75.75 0 01.216.664l-.528 3.084 2.769-1.456a.75.75 0 01.698 0l2.77 1.456-.53-3.084a.75.75 0 01.216-.664l2.24-2.183-3.096-.45a.75.75 0 01-.564-.41L8 2.694v.001z"></path>
</svg><span data-view-component="true" class="d-inline">
          Star
</span>
  
</a>      <button disabled="disabled" aria-label="You must be signed in to add this repository to a list" type="button" data-view-component="true" class="btn-sm btn BtnGroup-item px-2">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-triangle-down">
    <path d="M4.427 7.427l3.396 3.396a.25.25 0 00.354 0l3.396-3.396A.25.25 0 0011.396 7H4.604a.25.25 0 00-.177.427z"></path>
</svg>
  
</button></div>
      </div>
      <div class="flex-1">
          <a href="/login?return_to=%2Fvalidatorjs%2Fvalidator.js" rel="nofollow" data-hydro-click="{&quot;event_type&quot;:&quot;authentication.click&quot;,&quot;payload&quot;:{&quot;location_in_page&quot;:&quot;notification subscription menu watch&quot;,&quot;repository_id&quot;:null,&quot;auth_type&quot;:&quot;LOG_IN&quot;,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="c01bc0f53f6002d354146e3849c850af43ccaab1a31f20f2f8aa90b67f5febbe" aria-label="You must be signed in to change notification settings" data-view-component="true" class="tooltipped tooltipped-s btn-sm btn btn-block">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-bell mr-2">
    <path d="M8 16a2 2 0 001.985-1.75c.017-.137-.097-.25-.235-.25h-3.5c-.138 0-.252.113-.235.25A2 2 0 008 16z"></path><path fill-rule="evenodd" d="M8 1.5A3.5 3.5 0 004.5 5v2.947c0 .346-.102.683-.294.97l-1.703 2.556a.018.018 0 00-.003.01l.001.006c0 .002.002.004.004.006a.017.017 0 00.006.004l.007.001h10.964l.007-.001a.016.016 0 00.006-.004.016.016 0 00.004-.006l.001-.007a.017.017 0 00-.003-.01l-1.703-2.554a1.75 1.75 0 01-.294-.97V5A3.5 3.5 0 008 1.5zM3 5a5 5 0 0110 0v2.947c0 .05.015.098.042.139l1.703 2.555A1.518 1.518 0 0113.482 13H2.518a1.518 1.518 0 01-1.263-2.36l1.703-2.554A.25.25 0 003 7.947V5z"></path>
</svg>Notifications
  
</a>
      </div>
    </div>
  </div>

</div>


        
<nav data-pjax="#js-repo-pjax-container" aria-label="Repository" data-view-component="true" class="js-repo-nav js-sidenav-container-pjax js-responsive-underlinenav overflow-hidden UnderlineNav px-3 px-md-4 px-lg-5">

  <ul data-view-component="true" class="UnderlineNav-body list-style-none">
      <li data-view-component="true" class="d-inline-flex">
  <a id="code-tab" href="/validatorjs/validator.js" data-tab-item="i0code-tab" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches repo_packages repo_deployments /validatorjs/validator.js" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g c" data-ga-click="Repository, Navigation click, Code tab" aria-current="page" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item selected">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-code UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M4.72 3.22a.75.75 0 011.06 1.06L2.06 8l3.72 3.72a.75.75 0 11-1.06 1.06L.47 8.53a.75.75 0 010-1.06l4.25-4.25zm6.56 0a.75.75 0 10-1.06 1.06L13.94 8l-3.72 3.72a.75.75 0 101.06 1.06l4.25-4.25a.75.75 0 000-1.06l-4.25-4.25z"></path>
</svg>
          <span data-content="Code">Code</span>
            <span id="code-repo-tab-count" data-pjax-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="issues-tab" href="/validatorjs/validator.js/issues" data-tab-item="i1issues-tab" data-selected-links="repo_issues repo_labels repo_milestones /validatorjs/validator.js/issues" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g i" data-ga-click="Repository, Navigation click, Issues tab" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-issue-opened UnderlineNav-octicon d-none d-sm-inline">
    <path d="M8 9.5a1.5 1.5 0 100-3 1.5 1.5 0 000 3z"></path><path fill-rule="evenodd" d="M8 0a8 8 0 100 16A8 8 0 008 0zM1.5 8a6.5 6.5 0 1113 0 6.5 6.5 0 01-13 0z"></path>
</svg>
          <span data-content="Issues">Issues</span>
            <span id="issues-repo-tab-count" data-pjax-replace="" title="144" data-view-component="true" class="Counter">144</span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="pull-requests-tab" href="/validatorjs/validator.js/pulls" data-tab-item="i2pull-requests-tab" data-selected-links="repo_pulls checks /validatorjs/validator.js/pulls" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g p" data-ga-click="Repository, Navigation click, Pull requests tab" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-git-pull-request UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M7.177 3.073L9.573.677A.25.25 0 0110 .854v4.792a.25.25 0 01-.427.177L7.177 3.427a.25.25 0 010-.354zM3.75 2.5a.75.75 0 100 1.5.75.75 0 000-1.5zm-2.25.75a2.25 2.25 0 113 2.122v5.256a2.251 2.251 0 11-1.5 0V5.372A2.25 2.25 0 011.5 3.25zM11 2.5h-1V4h1a1 1 0 011 1v5.628a2.251 2.251 0 101.5 0V5A2.5 2.5 0 0011 2.5zm1 10.25a.75.75 0 111.5 0 .75.75 0 01-1.5 0zM3.75 12a.75.75 0 100 1.5.75.75 0 000-1.5z"></path>
</svg>
          <span data-content="Pull requests">Pull requests</span>
            <span id="pull-requests-repo-tab-count" data-pjax-replace="" title="119" data-view-component="true" class="Counter">119</span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="actions-tab" href="/validatorjs/validator.js/actions" data-tab-item="i3actions-tab" data-selected-links="repo_actions /validatorjs/validator.js/actions" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g a" data-analytics-event="{&quot;category&quot;:&quot;Actions&quot;,&quot;action&quot;:&quot;clicked&quot;,&quot;label&quot;:&quot;ref_cta:Actions;ref_loc:navigation_helper&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-play UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M1.5 8a6.5 6.5 0 1113 0 6.5 6.5 0 01-13 0zM8 0a8 8 0 100 16A8 8 0 008 0zM6.379 5.227A.25.25 0 006 5.442v5.117a.25.25 0 00.379.214l4.264-2.559a.25.25 0 000-.428L6.379 5.227z"></path>
</svg>
          <span data-content="Actions">Actions</span>
            <span id="actions-repo-tab-count" data-pjax-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="projects-tab" href="/validatorjs/validator.js/projects?type=beta" data-tab-item="i4projects-tab" data-selected-links="repo_projects new_repo_project repo_project /validatorjs/validator.js/projects?type=beta" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g b" data-ga-click="Repository, Navigation click, Projects tab" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-table UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M0 1.75C0 .784.784 0 1.75 0h12.5C15.216 0 16 .784 16 1.75v3.585a.746.746 0 010 .83v8.085A1.75 1.75 0 0114.25 16H6.309a.748.748 0 01-1.118 0H1.75A1.75 1.75 0 010 14.25V6.165a.746.746 0 010-.83V1.75zM1.5 6.5v7.75c0 .138.112.25.25.25H5v-8H1.5zM5 5H1.5V1.75a.25.25 0 01.25-.25H5V5zm1.5 1.5v8h7.75a.25.25 0 00.25-.25V6.5h-8zm8-1.5h-8V1.5h7.75a.25.25 0 01.25.25V5z"></path>
</svg>
          <span data-content="Projects">Projects</span>
            <span id="projects-repo-tab-count" data-pjax-replace="" title="0" hidden="hidden" data-view-component="true" class="Counter">0</span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="wiki-tab" href="/validatorjs/validator.js/wiki" data-tab-item="i5wiki-tab" data-selected-links="repo_wiki /validatorjs/validator.js/wiki" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g w" data-ga-click="Repository, Navigation click, Wikis tab" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-book UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M0 1.75A.75.75 0 01.75 1h4.253c1.227 0 2.317.59 3 1.501A3.744 3.744 0 0111.006 1h4.245a.75.75 0 01.75.75v10.5a.75.75 0 01-.75.75h-4.507a2.25 2.25 0 00-1.591.659l-.622.621a.75.75 0 01-1.06 0l-.622-.621A2.25 2.25 0 005.258 13H.75a.75.75 0 01-.75-.75V1.75zm8.755 3a2.25 2.25 0 012.25-2.25H14.5v9h-3.757c-.71 0-1.4.201-1.992.572l.004-7.322zm-1.504 7.324l.004-5.073-.002-2.253A2.25 2.25 0 005.003 2.5H1.5v9h3.757a3.75 3.75 0 011.994.574z"></path>
</svg>
          <span data-content="Wiki">Wiki</span>
            <span id="wiki-repo-tab-count" data-pjax-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="security-tab" href="/validatorjs/validator.js/security" data-tab-item="i6security-tab" data-selected-links="security overview alerts policy token_scanning code_scanning /validatorjs/validator.js/security" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g s" data-ga-click="Repository, Navigation click, Security tab" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-shield UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M7.467.133a1.75 1.75 0 011.066 0l5.25 1.68A1.75 1.75 0 0115 3.48V7c0 1.566-.32 3.182-1.303 4.682-.983 1.498-2.585 2.813-5.032 3.855a1.7 1.7 0 01-1.33 0c-2.447-1.042-4.049-2.357-5.032-3.855C1.32 10.182 1 8.566 1 7V3.48a1.75 1.75 0 011.217-1.667l5.25-1.68zm.61 1.429a.25.25 0 00-.153 0l-5.25 1.68a.25.25 0 00-.174.238V7c0 1.358.275 2.666 1.057 3.86.784 1.194 2.121 2.34 4.366 3.297a.2.2 0 00.154 0c2.245-.956 3.582-2.104 4.366-3.298C13.225 9.666 13.5 8.36 13.5 7V3.48a.25.25 0 00-.174-.237l-5.25-1.68zM9 10.5a1 1 0 11-2 0 1 1 0 012 0zm-.25-5.75a.75.75 0 10-1.5 0v3a.75.75 0 001.5 0v-3z"></path>
</svg>
          <span data-content="Security">Security</span>
            <include-fragment src="/validatorjs/validator.js/security/overall-count" accept="text/fragment+html"></include-fragment>

    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="insights-tab" href="/validatorjs/validator.js/pulse" data-tab-item="i7insights-tab" data-selected-links="repo_graphs repo_contributors dependency_graph dependabot_updates pulse people community /validatorjs/validator.js/pulse" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-ga-click="Repository, Navigation click, Insights tab" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
                  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-graph UnderlineNav-octicon d-none d-sm-inline">
    <path fill-rule="evenodd" d="M1.5 1.75a.75.75 0 00-1.5 0v12.5c0 .414.336.75.75.75h14.5a.75.75 0 000-1.5H1.5V1.75zm14.28 2.53a.75.75 0 00-1.06-1.06L10 7.94 7.53 5.47a.75.75 0 00-1.06 0L3.22 8.72a.75.75 0 001.06 1.06L7 7.06l2.47 2.47a.75.75 0 001.06 0l5.25-5.25z"></path>
</svg>
          <span data-content="Insights">Insights</span>
            <span id="insights-repo-tab-count" data-pjax-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
</ul>
    <div style="visibility:hidden;" data-view-component="true" class="UnderlineNav-actions js-responsive-underlinenav-overflow position-absolute pr-3 pr-md-4 pr-lg-5 right-0">      <details data-view-component="true" class="details-overlay details-reset position-relative">
  <summary role="button" data-view-component="true">          <div class="UnderlineNav-item mr-0 border-0">
            <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-kebab-horizontal">
    <path d="M8 9a1.5 1.5 0 100-3 1.5 1.5 0 000 3zM1.5 9a1.5 1.5 0 100-3 1.5 1.5 0 000 3zm13 0a1.5 1.5 0 100-3 1.5 1.5 0 000 3z"></path>
</svg>
            <span class="sr-only">More</span>
          </div>
</summary>
  <div data-view-component="true">          <details-menu role="menu" data-view-component="true" class="dropdown-menu dropdown-menu-sw">
  
            <ul>
                <li data-menu-item="i0code-tab" hidden>
                  <a role="menuitem" class="js-selected-navigation-item selected dropdown-item" aria-current="page" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches repo_packages repo_deployments /validatorjs/validator.js" href="/validatorjs/validator.js">
                    Code
</a>                </li>
                <li data-menu-item="i1issues-tab" hidden>
                  <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_issues repo_labels repo_milestones /validatorjs/validator.js/issues" href="/validatorjs/validator.js/issues">
                    Issues
</a>                </li>
                <li data-menu-item="i2pull-requests-tab" hidden>
                  <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_pulls checks /validatorjs/validator.js/pulls" href="/validatorjs/validator.js/pulls">
                    Pull requests
</a>                </li>
                <li data-menu-item="i3actions-tab" hidden>
                  <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_actions /validatorjs/validator.js/actions" href="/validatorjs/validator.js/actions">
                    Actions
</a>                </li>
                <li data-menu-item="i4projects-tab" hidden>
                  <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_projects new_repo_project repo_project /validatorjs/validator.js/projects?type=beta" href="/validatorjs/validator.js/projects?type=beta">
                    Projects
</a>                </li>
                <li data-menu-item="i5wiki-tab" hidden>
                  <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_wiki /validatorjs/validator.js/wiki" href="/validatorjs/validator.js/wiki">
                    Wiki
</a>                </li>
                <li data-menu-item="i6security-tab" hidden>
                  <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="security overview alerts policy token_scanning code_scanning /validatorjs/validator.js/security" href="/validatorjs/validator.js/security">
                    Security
</a>                </li>
                <li data-menu-item="i7insights-tab" hidden>
                  <a role="menuitem" class="js-selected-navigation-item dropdown-item" data-selected-links="repo_graphs repo_contributors dependency_graph dependabot_updates pulse people community /validatorjs/validator.js/pulse" href="/validatorjs/validator.js/pulse">
                    Insights
</a>                </li>
            </ul>

</details-menu></div>
</details></div>
</nav>
  </div>




    <div id="repo-content-pjax-container" class="repository-content " >
    
    


    
      
  <h1 class='sr-only'>validatorjs/validator.js</h1>
  <div class="clearfix container-xl px-3 px-md-4 px-lg-5 mt-4">
    

<div>
  

  <div class="d-none d-lg-block mt-6 mr-3 Popover top-0 right-0 color-shadow-medium col-3">
    
  </div>

  <div id="spoof-warning" class="mt-0 pb-3" hidden aria-hidden>
  <div data-view-component="true" class="flash flash-warn mt-0 clearfix">
  
  
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert float-left mt-1">
    <path fill-rule="evenodd" d="M8.22 1.754a.25.25 0 00-.44 0L1.698 13.132a.25.25 0 00.22.368h12.164a.25.25 0 00.22-.368L8.22 1.754zm-1.763-.707c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0114.082 15H1.918a1.75 1.75 0 01-1.543-2.575L6.457 1.047zM9 11a1 1 0 11-2 0 1 1 0 012 0zm-.25-5.25a.75.75 0 00-1.5 0v2.5a.75.75 0 001.5 0v-2.5z"></path>
</svg>

      <div class="overflow-hidden">This commit does not belong to any branch on this repository, and may belong to a fork outside of the repository.</div>


  
</div></div>

  <include-fragment src="/validatorjs/validator.js/spoofed_commit_check/6fb8bb5ea6c97a0b8302cf9d7bd503f7209b64cb" data-test-selector="spoofed-commit-check"></include-fragment>

  <div data-view-component="true" class="Layout Layout--flowRow-until-md Layout--sidebarPosition-end Layout--sidebarPosition-flowRow-end">
  <div data-view-component="true" class="Layout-main">      
      
      <div class="file-navigation mb-3 d-flex flex-items-start">
  
<div class="position-relative">
  <details class="details-reset details-overlay mr-0 mb-0 " id="branch-select-menu">
    <summary class="btn css-truncate"
            data-hotkey="w"
            title="Switch branches or tags">
      <svg text="gray" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-git-branch">
    <path fill-rule="evenodd" d="M11.75 2.5a.75.75 0 100 1.5.75.75 0 000-1.5zm-2.25.75a2.25 2.25 0 113 2.122V6A2.5 2.5 0 0110 8.5H6a1 1 0 00-1 1v1.128a2.251 2.251 0 11-1.5 0V5.372a2.25 2.25 0 111.5 0v1.836A2.492 2.492 0 016 7h4a1 1 0 001-1v-.628A2.25 2.25 0 019.5 3.25zM4.25 12a.75.75 0 100 1.5.75.75 0 000-1.5zM3.5 3.25a.75.75 0 111.5 0 .75.75 0 01-1.5 0z"></path>
</svg>
      <span class="css-truncate-target" data-menu-button>master</span>
      <span class="dropdown-caret"></span>
    </summary>

    
<div class="SelectMenu">
  <div class="SelectMenu-modal">
    <header class="SelectMenu-header">
      <span class="SelectMenu-title">Switch branches/tags</span>
      <button class="SelectMenu-closeButton" type="button" data-toggle-for="branch-select-menu"><svg aria-label="Close menu" aria-hidden="false" role="img" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path fill-rule="evenodd" d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.75.75 0 111.06 1.06L9.06 8l3.22 3.22a.75.75 0 11-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 01-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 010-1.06z"></path>
</svg></button>
    </header>

    <input-demux data-action="tab-container-change:input-demux#storeInput tab-container-changed:input-demux#updateInput">
      <tab-container class="d-flex flex-column js-branches-tags-tabs" style="min-height: 0;">
        <div class="SelectMenu-filter">
          <input data-target="input-demux.source"
                 id="context-commitish-filter-field"
                 class="SelectMenu-input form-control"
                 aria-owns="ref-list-branches"
                 data-controls-ref-menu-id="ref-list-branches"
                 autofocus
                 autocomplete="off"
                 aria-label="Filter branches/tags"
                 placeholder="Filter branches/tags"
                 type="text"
          >
        </div>

        <div class="SelectMenu-tabs" role="tablist" data-target="input-demux.control" >
          <button class="SelectMenu-tab" type="button" role="tab" aria-selected="true">Branches</button>
          <button class="SelectMenu-tab" type="button" role="tab">Tags</button>
        </div>

        <div role="tabpanel" id="ref-list-branches" data-filter-placeholder="Filter branches/tags" tabindex="" class="d-flex flex-column flex-auto overflow-auto">
          <ref-selector
            type="branch"
            data-targets="input-demux.sinks"
            data-action="
              input-entered:ref-selector#inputEntered
              tab-selected:ref-selector#tabSelected
              focus-list:ref-selector#focusFirstListMember
            "
            query-endpoint="/validatorjs/validator.js/refs"
            
            cache-key="v0:1650599469.735086"
            current-committish="bWFzdGVy"
            default-branch="bWFzdGVy"
            name-with-owner="dmFsaWRhdG9yanMvdmFsaWRhdG9yLmpz"
            prefetch-on-mouseover
          >

            <template data-target="ref-selector.fetchFailedTemplate">
              <div class="SelectMenu-message" data-index="{{ index }}">Could not load branches</div>
            </template>

              <template data-target="ref-selector.noMatchTemplate">
    <div class="SelectMenu-message">Nothing to show</div>
</template>


            <div data-target="ref-selector.listContainer" role="menu" class="SelectMenu-list " data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame">
              <div class="SelectMenu-loading pt-3 pb-0 overflow-hidden" aria-label="Menu is loading">
                <svg style="box-sizing: content-box; color: var(--color-icon-primary);" width="32" height="32" viewBox="0 0 16 16" fill="none" data-view-component="true" class="anim-rotate">
  <circle cx="8" cy="8" r="7" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" vector-effect="non-scaling-stroke" />
  <path d="M15 8a7.002 7.002 0 00-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke" />
</svg>
              </div>
            </div>

              <template data-target="ref-selector.itemTemplate">
  <a href="https://github.com/validatorjs/validator.js/tree/{{ urlEncodedRefName }}" class="SelectMenu-item" role="menuitemradio" rel="nofollow" aria-checked="{{ isCurrent }}" data-index="{{ index }}">
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check SelectMenu-icon SelectMenu-icon--check">
    <path fill-rule="evenodd" d="M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z"></path>
</svg>
    <span class="flex-1 css-truncate css-truncate-overflow {{ isFilteringClass }}">{{ refName }}</span>
    <span hidden="{{ isNotDefault }}" class="Label Label--secondary flex-self-start">default</span>
  </a>
</template>


              <footer class="SelectMenu-footer"><a href="/validatorjs/validator.js/branches">View all branches</a></footer>
          </ref-selector>

        </div>

        <div role="tabpanel" id="tags-menu" data-filter-placeholder="Find a tag" tabindex="" hidden class="d-flex flex-column flex-auto overflow-auto">
          <ref-selector
            type="tag"
            data-action="
              input-entered:ref-selector#inputEntered
              tab-selected:ref-selector#tabSelected
              focus-list:ref-selector#focusFirstListMember
            "
            data-targets="input-demux.sinks"
            query-endpoint="/validatorjs/validator.js/refs"
            cache-key="v0:1650599469.735086"
            current-committish="bWFzdGVy"
            default-branch="bWFzdGVy"
            name-with-owner="dmFsaWRhdG9yanMvdmFsaWRhdG9yLmpz"
          >

            <template data-target="ref-selector.fetchFailedTemplate">
              <div class="SelectMenu-message" data-index="{{ index }}">Could not load tags</div>
            </template>

            <template data-target="ref-selector.noMatchTemplate">
              <div class="SelectMenu-message" data-index="{{ index }}">Nothing to show</div>
            </template>

              <template data-target="ref-selector.itemTemplate">
  <a href="https://github.com/validatorjs/validator.js/tree/{{ urlEncodedRefName }}" class="SelectMenu-item" role="menuitemradio" rel="nofollow" aria-checked="{{ isCurrent }}" data-index="{{ index }}">
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check SelectMenu-icon SelectMenu-icon--check">
    <path fill-rule="evenodd" d="M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z"></path>
</svg>
    <span class="flex-1 css-truncate css-truncate-overflow {{ isFilteringClass }}">{{ refName }}</span>
    <span hidden="{{ isNotDefault }}" class="Label Label--secondary flex-self-start">default</span>
  </a>
</template>


            <div data-target="ref-selector.listContainer" role="menu" class="SelectMenu-list" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame">
              <div class="SelectMenu-loading pt-3 pb-0 overflow-hidden" aria-label="Menu is loading">
                <svg style="box-sizing: content-box; color: var(--color-icon-primary);" width="32" height="32" viewBox="0 0 16 16" fill="none" data-view-component="true" class="anim-rotate">
  <circle cx="8" cy="8" r="7" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" vector-effect="non-scaling-stroke" />
  <path d="M15 8a7.002 7.002 0 00-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke" />
</svg>
              </div>
            </div>
              <footer class="SelectMenu-footer"><a href="/validatorjs/validator.js/tags">View all tags</a></footer>
          </ref-selector>
        </div>
      </tab-container>
    </input-demux>
  </div>
</div>

  </details>

</div>


  <div class="flex-self-center ml-3 flex-self-stretch d-none d-lg-flex flex-items-center lh-condensed-ultra">
    <a data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/branches" class="Link--primary no-underline">
          <svg text="gray" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-git-branch">
    <path fill-rule="evenodd" d="M11.75 2.5a.75.75 0 100 1.5.75.75 0 000-1.5zm-2.25.75a2.25 2.25 0 113 2.122V6A2.5 2.5 0 0110 8.5H6a1 1 0 00-1 1v1.128a2.251 2.251 0 11-1.5 0V5.372a2.25 2.25 0 111.5 0v1.836A2.492 2.492 0 016 7h4a1 1 0 001-1v-.628A2.25 2.25 0 019.5 3.25zM4.25 12a.75.75 0 100 1.5.75.75 0 000-1.5zM3.5 3.25a.75.75 0 111.5 0 .75.75 0 01-1.5 0z"></path>
</svg>
          <strong>6</strong>
          <span class="color-fg-muted">branches</span>
    </a>
    <a data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/tags" class="ml-3 Link--primary no-underline">
      <svg text="gray" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-tag">
    <path fill-rule="evenodd" d="M2.5 7.775V2.75a.25.25 0 01.25-.25h5.025a.25.25 0 01.177.073l6.25 6.25a.25.25 0 010 .354l-5.025 5.025a.25.25 0 01-.354 0l-6.25-6.25a.25.25 0 01-.073-.177zm-1.5 0V2.75C1 1.784 1.784 1 2.75 1h5.025c.464 0 .91.184 1.238.513l6.25 6.25a1.75 1.75 0 010 2.474l-5.026 5.026a1.75 1.75 0 01-2.474 0l-6.25-6.25A1.75 1.75 0 011 7.775zM6 5a1 1 0 100 2 1 1 0 000-2z"></path>
</svg>
        <strong>150</strong>
        <span class="color-fg-muted">tags</span>
    </a>
  </div>

  <div class="flex-auto"></div>

  <include-fragment data-test-selector="overview-actions-fragment" src="/validatorjs/validator.js/overview_actions/master"></include-fragment>


    <span class="d-none d-md-flex ml-2">
      
<get-repo class="">
    
    <details class="position-relative details-overlay details-reset js-codespaces-details-container"
             data-action="toggle:get-repo#onDetailsToggle"
             
    >
      <summary data-hydro-click="{&quot;event_type&quot;:&quot;repository.click&quot;,&quot;payload&quot;:{&quot;repository_id&quot;:965782,&quot;target&quot;:&quot;CLONE_OR_DOWNLOAD_BUTTON&quot;,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="cc17d7091968135ff153b2687b1586c57bd3ef6689e4b295a066e407166be768" data-view-component="true" class="btn-primary btn">  Code<span class="dropdown-caret"></span>
  
</summary>      <div class="position-relative">
        <div class="dropdown-menu dropdown-menu-sw p-0" style="top:6px;width:378px;">
            <include-fragment
                src="/validatorjs/validator.js/code_menu_contents/master"
            >
              <svg style="box-sizing: content-box; color: var(--color-icon-primary);" width="32" height="32" viewBox="0 0 16 16" fill="none" data-view-component="true" class="anim-rotate">
  <circle cx="8" cy="8" r="7" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" vector-effect="non-scaling-stroke" />
  <path d="M15 8a7.002 7.002 0 00-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke" />
</svg>
            </include-fragment>
        </div>
      </div>
    </details>

</get-repo>

        
    </span>
</div>



      


<div class="Box mb-3">
  <div class="Box-header position-relative">
    <h2 class="sr-only">Latest commit</h2>
    <div class="js-details-container Details d-flex rounded-top-2 flex-items-center flex-wrap" data-issue-and-pr-hovercards-enabled>
      
  <div class="flex-shrink-0 ml-n1 mr-n1 mt-n1 mb-n1 hx_avatar_stack_commit" >
    
<div class="AvatarStack flex-self-start  " >
  <div class="AvatarStack-body" aria-label="adida948" >
      <a class="avatar avatar-user" style="width:24px;height:24px;" data-skip-pjax="true" data-test-selector="commits-avatar-stack-avatar-link" data-hovercard-type="user" data-hovercard-url="/users/adida948/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/adida948">
        <img data-test-selector="commits-avatar-stack-avatar-image" src="https://avatars.githubusercontent.com/u/4950838?s=48&amp;v=4" width="24" height="24" alt="@adida948" class=" avatar-user" />
</a>  </div>
</div>

  </div>
  <div class="flex-1 d-flex flex-items-center ml-3 min-width-0">
    <div class="css-truncate css-truncate-overflow color-fg-muted" >
          <a class="commit-author user-mention" title="View all commits by adida948" href="/validatorjs/validator.js/commits?author=adida948">adida948</a>
     and 
    <span class="commit-author user-mention" title="Danilo Carrion">Danilo Carrion</span>
    
  

        <span class="d-none d-sm-inline">
          <a data-pjax="true" data-test-selector="commit-tease-commit-message" title="feat(isMobilePhone): Added regex for Aruba nl-AW (#1985)

* feat(isMobilePhone): Added regex for Aruba nl-AW

* fix(docs): Remove merge markers

Co-authored-by: Danilo Carrion &lt;Danilo.X.Carrion@aexp.com&gt;" class="Link--primary markdown-title" href="/validatorjs/validator.js/commit/6fb8bb5ea6c97a0b8302cf9d7bd503f7209b64cb">feat(isMobilePhone): Added regex for Aruba nl-AW (</a><a class="issue-link js-issue-link" data-error-text="Failed to load title" data-id="1269561397" data-permission-text="Title is private" data-url="https://github.com/validatorjs/validator.js/issues/1985" data-hovercard-type="pull_request" data-hovercard-url="/validatorjs/validator.js/pull/1985/hovercard" href="https://github.com/validatorjs/validator.js/pull/1985">#1985</a><a data-pjax="true" data-test-selector="commit-tease-commit-message" title="feat(isMobilePhone): Added regex for Aruba nl-AW (#1985)

* feat(isMobilePhone): Added regex for Aruba nl-AW

* fix(docs): Remove merge markers

Co-authored-by: Danilo Carrion &lt;Danilo.X.Carrion@aexp.com&gt;" class="Link--primary markdown-title" href="/validatorjs/validator.js/commit/6fb8bb5ea6c97a0b8302cf9d7bd503f7209b64cb">)</a>
        </span>
    </div>
    <span
      class="hidden-text-expander ml-2 d-inline-block "
      
    >
      <button
        type="button"
        class="color-fg-default ellipsis-expander js-details-target"
        aria-expanded="false"
        
      >
        &hellip;
      </button>
    </span>
    <div class="d-flex flex-auto flex-justify-end ml-3 flex-items-baseline">
        <include-fragment accept="text/fragment+html" src="/validatorjs/validator.js/commit/6fb8bb5ea6c97a0b8302cf9d7bd503f7209b64cb/rollup?direction=sw" class="d-inline" ></include-fragment>
      <a
        href="/validatorjs/validator.js/commit/6fb8bb5ea6c97a0b8302cf9d7bd503f7209b64cb"
        class="f6 Link--secondary text-mono ml-2 d-none d-lg-inline"
        data-pjax="#repo-content-pjax-container"
        data-turbo-frame="repo-content-turbo-frame"
        
      >
        6fb8bb5
      </a>
      <a
        href="/validatorjs/validator.js/commit/6fb8bb5ea6c97a0b8302cf9d7bd503f7209b64cb"
        class="Link--secondary ml-2"
        data-pjax="#repo-content-pjax-container"
        data-turbo-frame="repo-content-turbo-frame"
        
      >
        <relative-time datetime="2022-07-03T03:54:44Z" class="no-wrap">Jul 3, 2022</relative-time>
      </a>
    </div>
  </div>
  <div class="pl-0 pl-md-5 flex-order-1 width-full Details-content--hidden">
      <div class="mt-2">
        <a data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-test-selector="commit-tease-commit-message" class="Link--primary text-bold" href="/validatorjs/validator.js/commit/6fb8bb5ea6c97a0b8302cf9d7bd503f7209b64cb">feat(isMobilePhone): Added regex for Aruba nl-AW (</a><a class="issue-link js-issue-link" data-error-text="Failed to load title" data-id="1269561397" data-permission-text="Title is private" data-url="https://github.com/validatorjs/validator.js/issues/1985" data-hovercard-type="pull_request" data-hovercard-url="/validatorjs/validator.js/pull/1985/hovercard" href="https://github.com/validatorjs/validator.js/pull/1985">#1985</a><a data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-test-selector="commit-tease-commit-message" class="Link--primary text-bold" href="/validatorjs/validator.js/commit/6fb8bb5ea6c97a0b8302cf9d7bd503f7209b64cb">)</a>
      </div>
      <pre class="mt-2 text-mono color-fg-muted text-small ws-pre-wrap">* feat(isMobilePhone): Added regex for Aruba nl-AW

* fix(docs): Remove merge markers

Co-authored-by: Danilo Carrion &lt;Danilo.X.Carrion@aexp.com&gt;</pre>
    <div class="d-flex flex-items-center">
      <code class="border d-lg-none mt-2 px-1 rounded-2">6fb8bb5</code>
    </div>
  </div>
      <div class="flex-shrink-0">
        <h2 class="sr-only">Git stats</h2>
        <ul class="list-style-none d-flex">
          <li class="ml-0 ml-md-3">
            <a data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/commits/master" class="pl-3 pr-3 py-3 p-md-0 mt-n3 mb-n3 mr-n3 m-md-0 Link--primary no-underline no-wrap">
              <svg text="gray" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-history">
    <path fill-rule="evenodd" d="M1.643 3.143L.427 1.927A.25.25 0 000 2.104V5.75c0 .138.112.25.25.25h3.646a.25.25 0 00.177-.427L2.715 4.215a6.5 6.5 0 11-1.18 4.458.75.75 0 10-1.493.154 8.001 8.001 0 101.6-5.684zM7.75 4a.75.75 0 01.75.75v2.992l2.028.812a.75.75 0 01-.557 1.392l-2.5-1A.75.75 0 017 8.25v-3.5A.75.75 0 017.75 4z"></path>
</svg>
              <span class="d-none d-sm-inline">
                    <strong>2,062</strong>
                    <span aria-label="Commits on master" class="color-fg-muted d-none d-lg-inline">
                      commits
                    </span>
              </span>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
    <h2 id="files"  class="sr-only">Files</h2>
    


  <include-fragment src="/validatorjs/validator.js/file-list/master">
      <a class="d-none js-permalink-shortcut" data-hotkey="y" href="/validatorjs/validator.js/tree/6fb8bb5ea6c97a0b8302cf9d7bd503f7209b64cb">Permalink</a>

  <div data-view-component="true" class="include-fragment-error flash flash-error flash-full py-2">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert">
    <path fill-rule="evenodd" d="M8.22 1.754a.25.25 0 00-.44 0L1.698 13.132a.25.25 0 00.22.368h12.164a.25.25 0 00.22-.368L8.22 1.754zm-1.763-.707c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0114.082 15H1.918a1.75 1.75 0 01-1.543-2.575L6.457 1.047zM9 11a1 1 0 11-2 0 1 1 0 012 0zm-.25-5.25a.75.75 0 00-1.5 0v2.5a.75.75 0 001.5 0v-2.5z"></path>
</svg>
  
    Failed to load latest commit information.


  
</div>  <div class="js-details-container Details">
    <div role="grid" aria-labelledby="files" class="Details-content--hidden-not-important js-navigation-container js-active-navigation-container d-md-block" data-pjax>
      <div class="sr-only" role="row">
        <div role="columnheader">Type</div>
        <div role="columnheader">Name</div>
        <div role="columnheader" class="d-none d-md-block">Latest commit message</div>
        <div role="columnheader">Commit time</div>
      </div>

        <div role="row" class="Box-row Box-row--focus-gray py-2 d-flex position-relative js-navigation-item ">
          <div role="gridcell" class="mr-3 flex-shrink-0" style="width: 16px;">
              <svg aria-label="Directory" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file-directory-fill hx_color-icon-directory">
    <path d="M1.75 1A1.75 1.75 0 000 2.75v10.5C0 14.216.784 15 1.75 15h12.5A1.75 1.75 0 0016 13.25v-8.5A1.75 1.75 0 0014.25 3H7.5a.25.25 0 01-.2-.1l-.9-1.2C6.07 1.26 5.55 1 5 1H1.75z"></path>
</svg>
          </div>

          <div role="rowheader" class="flex-auto min-width-0 col-md-2 mr-3">
            <span class="css-truncate css-truncate-target d-block width-fit"><a class="js-navigation-open Link--primary" title=".github" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/tree/master/.github">.github</a></span>
          </div>

          <div role="gridcell" class="flex-auto min-width-0 d-none d-md-block col-5 mr-3" >
              <div class="Skeleton Skeleton--text col-7">&nbsp;</div>
          </div>

          <div role="gridcell" class="color-fg-muted text-right" style="width:100px;">
              <div class="Skeleton Skeleton--text">&nbsp;</div>
          </div>

        </div>
        <div role="row" class="Box-row Box-row--focus-gray py-2 d-flex position-relative js-navigation-item ">
          <div role="gridcell" class="mr-3 flex-shrink-0" style="width: 16px;">
              <svg aria-label="Directory" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file-directory-fill hx_color-icon-directory">
    <path d="M1.75 1A1.75 1.75 0 000 2.75v10.5C0 14.216.784 15 1.75 15h12.5A1.75 1.75 0 0016 13.25v-8.5A1.75 1.75 0 0014.25 3H7.5a.25.25 0 01-.2-.1l-.9-1.2C6.07 1.26 5.55 1 5 1H1.75z"></path>
</svg>
          </div>

          <div role="rowheader" class="flex-auto min-width-0 col-md-2 mr-3">
            <span class="css-truncate css-truncate-target d-block width-fit"><a class="js-navigation-open Link--primary" title="src" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/tree/master/src">src</a></span>
          </div>

          <div role="gridcell" class="flex-auto min-width-0 d-none d-md-block col-5 mr-3" >
              <div class="Skeleton Skeleton--text col-7">&nbsp;</div>
          </div>

          <div role="gridcell" class="color-fg-muted text-right" style="width:100px;">
              <div class="Skeleton Skeleton--text">&nbsp;</div>
          </div>

        </div>
        <div role="row" class="Box-row Box-row--focus-gray py-2 d-flex position-relative js-navigation-item ">
          <div role="gridcell" class="mr-3 flex-shrink-0" style="width: 16px;">
              <svg aria-label="Directory" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file-directory-fill hx_color-icon-directory">
    <path d="M1.75 1A1.75 1.75 0 000 2.75v10.5C0 14.216.784 15 1.75 15h12.5A1.75 1.75 0 0016 13.25v-8.5A1.75 1.75 0 0014.25 3H7.5a.25.25 0 01-.2-.1l-.9-1.2C6.07 1.26 5.55 1 5 1H1.75z"></path>
</svg>
          </div>

          <div role="rowheader" class="flex-auto min-width-0 col-md-2 mr-3">
            <span class="css-truncate css-truncate-target d-block width-fit"><a class="js-navigation-open Link--primary" title="test" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/tree/master/test">test</a></span>
          </div>

          <div role="gridcell" class="flex-auto min-width-0 d-none d-md-block col-5 mr-3" >
              <div class="Skeleton Skeleton--text col-7">&nbsp;</div>
          </div>

          <div role="gridcell" class="color-fg-muted text-right" style="width:100px;">
              <div class="Skeleton Skeleton--text">&nbsp;</div>
          </div>

        </div>
        <div role="row" class="Box-row Box-row--focus-gray py-2 d-flex position-relative js-navigation-item ">
          <div role="gridcell" class="mr-3 flex-shrink-0" style="width: 16px;">
              <svg aria-label="File" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file color-fg-muted">
    <path fill-rule="evenodd" d="M3.75 1.5a.25.25 0 00-.25.25v12.5c0 .138.112.25.25.25h9.5a.25.25 0 00.25-.25V6h-2.75A1.75 1.75 0 019 4.25V1.5H3.75zm6.75.062V4.25c0 .138.112.25.25.25h2.688a.252.252 0 00-.011-.013l-2.914-2.914a.272.272 0 00-.013-.011zM2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0113.25 16h-9.5A1.75 1.75 0 012 14.25V1.75z"></path>
</svg>
          </div>

          <div role="rowheader" class="flex-auto min-width-0 col-md-2 mr-3">
            <span class="css-truncate css-truncate-target d-block width-fit"><a class="js-navigation-open Link--primary" title=".babelrc" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/blob/master/.babelrc">.babelrc</a></span>
          </div>

          <div role="gridcell" class="flex-auto min-width-0 d-none d-md-block col-5 mr-3" >
              <div class="Skeleton Skeleton--text col-7">&nbsp;</div>
          </div>

          <div role="gridcell" class="color-fg-muted text-right" style="width:100px;">
              <div class="Skeleton Skeleton--text">&nbsp;</div>
          </div>

        </div>
        <div role="row" class="Box-row Box-row--focus-gray py-2 d-flex position-relative js-navigation-item ">
          <div role="gridcell" class="mr-3 flex-shrink-0" style="width: 16px;">
              <svg aria-label="File" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file color-fg-muted">
    <path fill-rule="evenodd" d="M3.75 1.5a.25.25 0 00-.25.25v12.5c0 .138.112.25.25.25h9.5a.25.25 0 00.25-.25V6h-2.75A1.75 1.75 0 019 4.25V1.5H3.75zm6.75.062V4.25c0 .138.112.25.25.25h2.688a.252.252 0 00-.011-.013l-2.914-2.914a.272.272 0 00-.013-.011zM2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0113.25 16h-9.5A1.75 1.75 0 012 14.25V1.75z"></path>
</svg>
          </div>

          <div role="rowheader" class="flex-auto min-width-0 col-md-2 mr-3">
            <span class="css-truncate css-truncate-target d-block width-fit"><a class="js-navigation-open Link--primary" title=".eslintrc.json" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/blob/master/.eslintrc.json">.eslintrc.json</a></span>
          </div>

          <div role="gridcell" class="flex-auto min-width-0 d-none d-md-block col-5 mr-3" >
              <div class="Skeleton Skeleton--text col-7">&nbsp;</div>
          </div>

          <div role="gridcell" class="color-fg-muted text-right" style="width:100px;">
              <div class="Skeleton Skeleton--text">&nbsp;</div>
          </div>

        </div>
        <div role="row" class="Box-row Box-row--focus-gray py-2 d-flex position-relative js-navigation-item ">
          <div role="gridcell" class="mr-3 flex-shrink-0" style="width: 16px;">
              <svg aria-label="File" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file color-fg-muted">
    <path fill-rule="evenodd" d="M3.75 1.5a.25.25 0 00-.25.25v12.5c0 .138.112.25.25.25h9.5a.25.25 0 00.25-.25V6h-2.75A1.75 1.75 0 019 4.25V1.5H3.75zm6.75.062V4.25c0 .138.112.25.25.25h2.688a.252.252 0 00-.011-.013l-2.914-2.914a.272.272 0 00-.013-.011zM2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0113.25 16h-9.5A1.75 1.75 0 012 14.25V1.75z"></path>
</svg>
          </div>

          <div role="rowheader" class="flex-auto min-width-0 col-md-2 mr-3">
            <span class="css-truncate css-truncate-target d-block width-fit"><a class="js-navigation-open Link--primary" title=".gitignore" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/blob/master/.gitignore">.gitignore</a></span>
          </div>

          <div role="gridcell" class="flex-auto min-width-0 d-none d-md-block col-5 mr-3" >
              <div class="Skeleton Skeleton--text col-7">&nbsp;</div>
          </div>

          <div role="gridcell" class="color-fg-muted text-right" style="width:100px;">
              <div class="Skeleton Skeleton--text">&nbsp;</div>
          </div>

        </div>
        <div role="row" class="Box-row Box-row--focus-gray py-2 d-flex position-relative js-navigation-item ">
          <div role="gridcell" class="mr-3 flex-shrink-0" style="width: 16px;">
              <svg aria-label="File" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file color-fg-muted">
    <path fill-rule="evenodd" d="M3.75 1.5a.25.25 0 00-.25.25v12.5c0 .138.112.25.25.25h9.5a.25.25 0 00.25-.25V6h-2.75A1.75 1.75 0 019 4.25V1.5H3.75zm6.75.062V4.25c0 .138.112.25.25.25h2.688a.252.252 0 00-.011-.013l-2.914-2.914a.272.272 0 00-.013-.011zM2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0113.25 16h-9.5A1.75 1.75 0 012 14.25V1.75z"></path>
</svg>
          </div>

          <div role="rowheader" class="flex-auto min-width-0 col-md-2 mr-3">
            <span class="css-truncate css-truncate-target d-block width-fit"><a class="js-navigation-open Link--primary" title=".nycrc" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/blob/master/.nycrc">.nycrc</a></span>
          </div>

          <div role="gridcell" class="flex-auto min-width-0 d-none d-md-block col-5 mr-3" >
              <div class="Skeleton Skeleton--text col-7">&nbsp;</div>
          </div>

          <div role="gridcell" class="color-fg-muted text-right" style="width:100px;">
              <div class="Skeleton Skeleton--text">&nbsp;</div>
          </div>

        </div>
        <div role="row" class="Box-row Box-row--focus-gray py-2 d-flex position-relative js-navigation-item ">
          <div role="gridcell" class="mr-3 flex-shrink-0" style="width: 16px;">
              <svg aria-label="File" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file color-fg-muted">
    <path fill-rule="evenodd" d="M3.75 1.5a.25.25 0 00-.25.25v12.5c0 .138.112.25.25.25h9.5a.25.25 0 00.25-.25V6h-2.75A1.75 1.75 0 019 4.25V1.5H3.75zm6.75.062V4.25c0 .138.112.25.25.25h2.688a.252.252 0 00-.011-.013l-2.914-2.914a.272.272 0 00-.013-.011zM2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0113.25 16h-9.5A1.75 1.75 0 012 14.25V1.75z"></path>
</svg>
          </div>

          <div role="rowheader" class="flex-auto min-width-0 col-md-2 mr-3">
            <span class="css-truncate css-truncate-target d-block width-fit"><a class="js-navigation-open Link--primary" title="CHANGELOG.md" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/blob/master/CHANGELOG.md">CHANGELOG.md</a></span>
          </div>

          <div role="gridcell" class="flex-auto min-width-0 d-none d-md-block col-5 mr-3" >
              <div class="Skeleton Skeleton--text col-7">&nbsp;</div>
          </div>

          <div role="gridcell" class="color-fg-muted text-right" style="width:100px;">
              <div class="Skeleton Skeleton--text">&nbsp;</div>
          </div>

        </div>
        <div role="row" class="Box-row Box-row--focus-gray py-2 d-flex position-relative js-navigation-item ">
          <div role="gridcell" class="mr-3 flex-shrink-0" style="width: 16px;">
              <svg aria-label="File" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file color-fg-muted">
    <path fill-rule="evenodd" d="M3.75 1.5a.25.25 0 00-.25.25v12.5c0 .138.112.25.25.25h9.5a.25.25 0 00.25-.25V6h-2.75A1.75 1.75 0 019 4.25V1.5H3.75zm6.75.062V4.25c0 .138.112.25.25.25h2.688a.252.252 0 00-.011-.013l-2.914-2.914a.272.272 0 00-.013-.011zM2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0113.25 16h-9.5A1.75 1.75 0 012 14.25V1.75z"></path>
</svg>
          </div>

          <div role="rowheader" class="flex-auto min-width-0 col-md-2 mr-3">
            <span class="css-truncate css-truncate-target d-block width-fit"><a class="js-navigation-open Link--primary" title="LICENSE" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" itemprop="license" href="/validatorjs/validator.js/blob/master/LICENSE">LICENSE</a></span>
          </div>

          <div role="gridcell" class="flex-auto min-width-0 d-none d-md-block col-5 mr-3" >
              <div class="Skeleton Skeleton--text col-7">&nbsp;</div>
          </div>

          <div role="gridcell" class="color-fg-muted text-right" style="width:100px;">
              <div class="Skeleton Skeleton--text">&nbsp;</div>
          </div>

        </div>
        <div role="row" class="Box-row Box-row--focus-gray py-2 d-flex position-relative js-navigation-item ">
          <div role="gridcell" class="mr-3 flex-shrink-0" style="width: 16px;">
              <svg aria-label="File" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file color-fg-muted">
    <path fill-rule="evenodd" d="M3.75 1.5a.25.25 0 00-.25.25v12.5c0 .138.112.25.25.25h9.5a.25.25 0 00.25-.25V6h-2.75A1.75 1.75 0 019 4.25V1.5H3.75zm6.75.062V4.25c0 .138.112.25.25.25h2.688a.252.252 0 00-.011-.013l-2.914-2.914a.272.272 0 00-.013-.011zM2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0113.25 16h-9.5A1.75 1.75 0 012 14.25V1.75z"></path>
</svg>
          </div>

          <div role="rowheader" class="flex-auto min-width-0 col-md-2 mr-3">
            <span class="css-truncate css-truncate-target d-block width-fit"><a class="js-navigation-open Link--primary" title="README.md" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/blob/master/README.md">README.md</a></span>
          </div>

          <div role="gridcell" class="flex-auto min-width-0 d-none d-md-block col-5 mr-3" >
              <div class="Skeleton Skeleton--text col-7">&nbsp;</div>
          </div>

          <div role="gridcell" class="color-fg-muted text-right" style="width:100px;">
              <div class="Skeleton Skeleton--text">&nbsp;</div>
          </div>

        </div>
        <div role="row" class="Box-row Box-row--focus-gray py-2 d-flex position-relative js-navigation-item ">
          <div role="gridcell" class="mr-3 flex-shrink-0" style="width: 16px;">
              <svg aria-label="File" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file color-fg-muted">
    <path fill-rule="evenodd" d="M3.75 1.5a.25.25 0 00-.25.25v12.5c0 .138.112.25.25.25h9.5a.25.25 0 00.25-.25V6h-2.75A1.75 1.75 0 019 4.25V1.5H3.75zm6.75.062V4.25c0 .138.112.25.25.25h2.688a.252.252 0 00-.011-.013l-2.914-2.914a.272.272 0 00-.013-.011zM2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0113.25 16h-9.5A1.75 1.75 0 012 14.25V1.75z"></path>
</svg>
          </div>

          <div role="rowheader" class="flex-auto min-width-0 col-md-2 mr-3">
            <span class="css-truncate css-truncate-target d-block width-fit"><a class="js-navigation-open Link--primary" title="SECURITY.md" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/blob/master/SECURITY.md">SECURITY.md</a></span>
          </div>

          <div role="gridcell" class="flex-auto min-width-0 d-none d-md-block col-5 mr-3" >
              <div class="Skeleton Skeleton--text col-7">&nbsp;</div>
          </div>

          <div role="gridcell" class="color-fg-muted text-right" style="width:100px;">
              <div class="Skeleton Skeleton--text">&nbsp;</div>
          </div>

        </div>
        <div role="row" class="Box-row Box-row--focus-gray py-2 d-flex position-relative js-navigation-item ">
          <div role="gridcell" class="mr-3 flex-shrink-0" style="width: 16px;">
              <svg aria-label="File" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file color-fg-muted">
    <path fill-rule="evenodd" d="M3.75 1.5a.25.25 0 00-.25.25v12.5c0 .138.112.25.25.25h9.5a.25.25 0 00.25-.25V6h-2.75A1.75 1.75 0 019 4.25V1.5H3.75zm6.75.062V4.25c0 .138.112.25.25.25h2.688a.252.252 0 00-.011-.013l-2.914-2.914a.272.272 0 00-.013-.011zM2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0113.25 16h-9.5A1.75 1.75 0 012 14.25V1.75z"></path>
</svg>
          </div>

          <div role="rowheader" class="flex-auto min-width-0 col-md-2 mr-3">
            <span class="css-truncate css-truncate-target d-block width-fit"><a class="js-navigation-open Link--primary" title="bower.json" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/blob/master/bower.json">bower.json</a></span>
          </div>

          <div role="gridcell" class="flex-auto min-width-0 d-none d-md-block col-5 mr-3" >
              <div class="Skeleton Skeleton--text col-7">&nbsp;</div>
          </div>

          <div role="gridcell" class="color-fg-muted text-right" style="width:100px;">
              <div class="Skeleton Skeleton--text">&nbsp;</div>
          </div>

        </div>
        <div role="row" class="Box-row Box-row--focus-gray py-2 d-flex position-relative js-navigation-item ">
          <div role="gridcell" class="mr-3 flex-shrink-0" style="width: 16px;">
              <svg aria-label="File" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file color-fg-muted">
    <path fill-rule="evenodd" d="M3.75 1.5a.25.25 0 00-.25.25v12.5c0 .138.112.25.25.25h9.5a.25.25 0 00.25-.25V6h-2.75A1.75 1.75 0 019 4.25V1.5H3.75zm6.75.062V4.25c0 .138.112.25.25.25h2.688a.252.252 0 00-.011-.013l-2.914-2.914a.272.272 0 00-.013-.011zM2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0113.25 16h-9.5A1.75 1.75 0 012 14.25V1.75z"></path>
</svg>
          </div>

          <div role="rowheader" class="flex-auto min-width-0 col-md-2 mr-3">
            <span class="css-truncate css-truncate-target d-block width-fit"><a class="js-navigation-open Link--primary" title="build-browser.js" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/blob/master/build-browser.js">build-browser.js</a></span>
          </div>

          <div role="gridcell" class="flex-auto min-width-0 d-none d-md-block col-5 mr-3" >
              <div class="Skeleton Skeleton--text col-7">&nbsp;</div>
          </div>

          <div role="gridcell" class="color-fg-muted text-right" style="width:100px;">
              <div class="Skeleton Skeleton--text">&nbsp;</div>
          </div>

        </div>
        <div role="row" class="Box-row Box-row--focus-gray py-2 d-flex position-relative js-navigation-item ">
          <div role="gridcell" class="mr-3 flex-shrink-0" style="width: 16px;">
              <svg aria-label="File" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file color-fg-muted">
    <path fill-rule="evenodd" d="M3.75 1.5a.25.25 0 00-.25.25v12.5c0 .138.112.25.25.25h9.5a.25.25 0 00.25-.25V6h-2.75A1.75 1.75 0 019 4.25V1.5H3.75zm6.75.062V4.25c0 .138.112.25.25.25h2.688a.252.252 0 00-.011-.013l-2.914-2.914a.272.272 0 00-.013-.011zM2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0113.25 16h-9.5A1.75 1.75 0 012 14.25V1.75z"></path>
</svg>
          </div>

          <div role="rowheader" class="flex-auto min-width-0 col-md-2 mr-3">
            <span class="css-truncate css-truncate-target d-block width-fit"><a class="js-navigation-open Link--primary" title="jsconfig.json" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/blob/master/jsconfig.json">jsconfig.json</a></span>
          </div>

          <div role="gridcell" class="flex-auto min-width-0 d-none d-md-block col-5 mr-3" >
              <div class="Skeleton Skeleton--text col-7">&nbsp;</div>
          </div>

          <div role="gridcell" class="color-fg-muted text-right" style="width:100px;">
              <div class="Skeleton Skeleton--text">&nbsp;</div>
          </div>

        </div>
        <div role="row" class="Box-row Box-row--focus-gray py-2 d-flex position-relative js-navigation-item ">
          <div role="gridcell" class="mr-3 flex-shrink-0" style="width: 16px;">
              <svg aria-label="File" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file color-fg-muted">
    <path fill-rule="evenodd" d="M3.75 1.5a.25.25 0 00-.25.25v12.5c0 .138.112.25.25.25h9.5a.25.25 0 00.25-.25V6h-2.75A1.75 1.75 0 019 4.25V1.5H3.75zm6.75.062V4.25c0 .138.112.25.25.25h2.688a.252.252 0 00-.011-.013l-2.914-2.914a.272.272 0 00-.013-.011zM2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0113.25 16h-9.5A1.75 1.75 0 012 14.25V1.75z"></path>
</svg>
          </div>

          <div role="rowheader" class="flex-auto min-width-0 col-md-2 mr-3">
            <span class="css-truncate css-truncate-target d-block width-fit"><a class="js-navigation-open Link--primary" title="package.json" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/blob/master/package.json">package.json</a></span>
          </div>

          <div role="gridcell" class="flex-auto min-width-0 d-none d-md-block col-5 mr-3" >
              <div class="Skeleton Skeleton--text col-7">&nbsp;</div>
          </div>

          <div role="gridcell" class="color-fg-muted text-right" style="width:100px;">
              <div class="Skeleton Skeleton--text">&nbsp;</div>
          </div>

        </div>
    </div>
    <div class="Details-content--shown Box-footer d-md-none p-0">
      <button aria-expanded="false" type="button" data-view-component="true" class="js-details-target btn-link d-block width-full px-3 py-2">  View code
  
</button>    </div>
  </div>

</include-fragment>


</div>

  
      <readme-toc>

      <div id="readme" class="Box md js-code-block-container js-code-nav-container js-tagsearch-file Box--responsive"
          data-tagsearch-path="README.md"
          data-tagsearch-lang="Markdown">

        <div class="d-flex  js-sticky js-position-sticky top-0 border-top-0 border-bottom p-2 flex-items-center flex-justify-between color-bg-default rounded-top-2"  style="position: sticky; z-index: 30;" >
          <div class="d-flex flex-items-center">
              <details
  data-target="readme-toc.trigger"
  data-menu-hydro-click="{&quot;event_type&quot;:&quot;repository_toc_menu.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;trigger&quot;,&quot;repository_id&quot;:965782,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}"
  data-menu-hydro-click-hmac="f0c9b8c01fd4d6fe4a24c2d946541056ab08b4ca782e38dc7ffeca89838e26c7"
  class="dropdown details-reset details-overlay"
>
  <summary
    class="btn btn-octicon m-0 mr-2 p-2"
    aria-haspopup="true"
    aria-label="Table of Contents">
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-list-unordered">
    <path fill-rule="evenodd" d="M2 4a1 1 0 100-2 1 1 0 000 2zm3.75-1.5a.75.75 0 000 1.5h8.5a.75.75 0 000-1.5h-8.5zm0 5a.75.75 0 000 1.5h8.5a.75.75 0 000-1.5h-8.5zm0 5a.75.75 0 000 1.5h8.5a.75.75 0 000-1.5h-8.5zM3 8a1 1 0 11-2 0 1 1 0 012 0zm-1 6a1 1 0 100-2 1 1 0 000 2z"></path>
</svg>
  </summary>


  <details-menu class="SelectMenu" role="menu">
    <div class="SelectMenu-modal rounded-3 mt-1" style="max-height:340px;">

        <div class="SelectMenu-filter">
          <input
            class="SelectMenu-input form-control js-filterable-field"
            id="toc-filter-field"
            type="text"
            autocomplete="off"
            spellcheck="false"
            autofocus
            placeholder="Filter headings"
            aria-label="Filter headings">
        </div>

      <div class="SelectMenu-list SelectMenu-list--borderless p-2" style="overscroll-behavior: contain;" data-filterable-for="toc-filter-field" data-filterable-type="substring">
          <a role="menuitem" class="filter-item SelectMenu-item ws-normal wb-break-word line-clamp-2 py-1 text-emphasized" style="-webkit-box-orient: vertical; padding-left: 12px;" data-action="click:readme-toc#blur" data-targets="readme-toc.entries" data-hydro-click="{&quot;event_type&quot;:&quot;repository_toc_menu.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;entry&quot;,&quot;repository_id&quot;:965782,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="8f66a1a9557891e50219e578a184c32661d9cae16f4b736f213a44c69edf556c" href="#validatorjs">validator.js</a>
          <a role="menuitem" class="filter-item SelectMenu-item ws-normal wb-break-word line-clamp-2 py-1 " style="-webkit-box-orient: vertical; padding-left: 24px;" data-action="click:readme-toc#blur" data-targets="readme-toc.entries" data-hydro-click="{&quot;event_type&quot;:&quot;repository_toc_menu.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;entry&quot;,&quot;repository_id&quot;:965782,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="8f66a1a9557891e50219e578a184c32661d9cae16f4b736f213a44c69edf556c" href="#strings-only">Strings only</a>
          <a role="menuitem" class="filter-item SelectMenu-item ws-normal wb-break-word line-clamp-2 py-1 " style="-webkit-box-orient: vertical; padding-left: 24px;" data-action="click:readme-toc#blur" data-targets="readme-toc.entries" data-hydro-click="{&quot;event_type&quot;:&quot;repository_toc_menu.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;entry&quot;,&quot;repository_id&quot;:965782,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="8f66a1a9557891e50219e578a184c32661d9cae16f4b736f213a44c69edf556c" href="#installation-and-usage">Installation and Usage</a>
          <a role="menuitem" class="filter-item SelectMenu-item ws-normal wb-break-word line-clamp-2 py-1 " style="-webkit-box-orient: vertical; padding-left: 36px;" data-action="click:readme-toc#blur" data-targets="readme-toc.entries" data-hydro-click="{&quot;event_type&quot;:&quot;repository_toc_menu.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;entry&quot;,&quot;repository_id&quot;:965782,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="8f66a1a9557891e50219e578a184c32661d9cae16f4b736f213a44c69edf556c" href="#server-side-usage">Server-side usage</a>
          <a role="menuitem" class="filter-item SelectMenu-item ws-normal wb-break-word line-clamp-2 py-1 " style="-webkit-box-orient: vertical; padding-left: 48px;" data-action="click:readme-toc#blur" data-targets="readme-toc.entries" data-hydro-click="{&quot;event_type&quot;:&quot;repository_toc_menu.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;entry&quot;,&quot;repository_id&quot;:965782,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="8f66a1a9557891e50219e578a184c32661d9cae16f4b736f213a44c69edf556c" href="#no-es6">No ES6</a>
          <a role="menuitem" class="filter-item SelectMenu-item ws-normal wb-break-word line-clamp-2 py-1 " style="-webkit-box-orient: vertical; padding-left: 48px;" data-action="click:readme-toc#blur" data-targets="readme-toc.entries" data-hydro-click="{&quot;event_type&quot;:&quot;repository_toc_menu.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;entry&quot;,&quot;repository_id&quot;:965782,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="8f66a1a9557891e50219e578a184c32661d9cae16f4b736f213a44c69edf556c" href="#es6">ES6</a>
          <a role="menuitem" class="filter-item SelectMenu-item ws-normal wb-break-word line-clamp-2 py-1 " style="-webkit-box-orient: vertical; padding-left: 48px;" data-action="click:readme-toc#blur" data-targets="readme-toc.entries" data-hydro-click="{&quot;event_type&quot;:&quot;repository_toc_menu.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;entry&quot;,&quot;repository_id&quot;:965782,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="8f66a1a9557891e50219e578a184c32661d9cae16f4b736f213a44c69edf556c" href="#tree-shakeable-es-imports">Tree-shakeable ES imports</a>
          <a role="menuitem" class="filter-item SelectMenu-item ws-normal wb-break-word line-clamp-2 py-1 " style="-webkit-box-orient: vertical; padding-left: 36px;" data-action="click:readme-toc#blur" data-targets="readme-toc.entries" data-hydro-click="{&quot;event_type&quot;:&quot;repository_toc_menu.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;entry&quot;,&quot;repository_id&quot;:965782,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="8f66a1a9557891e50219e578a184c32661d9cae16f4b736f213a44c69edf556c" href="#client-side-usage">Client-side usage</a>
          <a role="menuitem" class="filter-item SelectMenu-item ws-normal wb-break-word line-clamp-2 py-1 " style="-webkit-box-orient: vertical; padding-left: 24px;" data-action="click:readme-toc#blur" data-targets="readme-toc.entries" data-hydro-click="{&quot;event_type&quot;:&quot;repository_toc_menu.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;entry&quot;,&quot;repository_id&quot;:965782,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="8f66a1a9557891e50219e578a184c32661d9cae16f4b736f213a44c69edf556c" href="#contributors">Contributors</a>
          <a role="menuitem" class="filter-item SelectMenu-item ws-normal wb-break-word line-clamp-2 py-1 " style="-webkit-box-orient: vertical; padding-left: 24px;" data-action="click:readme-toc#blur" data-targets="readme-toc.entries" data-hydro-click="{&quot;event_type&quot;:&quot;repository_toc_menu.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;entry&quot;,&quot;repository_id&quot;:965782,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="8f66a1a9557891e50219e578a184c32661d9cae16f4b736f213a44c69edf556c" href="#validators">Validators</a>
          <a role="menuitem" class="filter-item SelectMenu-item ws-normal wb-break-word line-clamp-2 py-1 " style="-webkit-box-orient: vertical; padding-left: 24px;" data-action="click:readme-toc#blur" data-targets="readme-toc.entries" data-hydro-click="{&quot;event_type&quot;:&quot;repository_toc_menu.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;entry&quot;,&quot;repository_id&quot;:965782,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="8f66a1a9557891e50219e578a184c32661d9cae16f4b736f213a44c69edf556c" href="#sanitizers">Sanitizers</a>
          <a role="menuitem" class="filter-item SelectMenu-item ws-normal wb-break-word line-clamp-2 py-1 " style="-webkit-box-orient: vertical; padding-left: 36px;" data-action="click:readme-toc#blur" data-targets="readme-toc.entries" data-hydro-click="{&quot;event_type&quot;:&quot;repository_toc_menu.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;entry&quot;,&quot;repository_id&quot;:965782,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="8f66a1a9557891e50219e578a184c32661d9cae16f4b736f213a44c69edf556c" href="#xss-sanitization">XSS Sanitization</a>
          <a role="menuitem" class="filter-item SelectMenu-item ws-normal wb-break-word line-clamp-2 py-1 " style="-webkit-box-orient: vertical; padding-left: 24px;" data-action="click:readme-toc#blur" data-targets="readme-toc.entries" data-hydro-click="{&quot;event_type&quot;:&quot;repository_toc_menu.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;entry&quot;,&quot;repository_id&quot;:965782,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="8f66a1a9557891e50219e578a184c32661d9cae16f4b736f213a44c69edf556c" href="#contributing">Contributing</a>
          <a role="menuitem" class="filter-item SelectMenu-item ws-normal wb-break-word line-clamp-2 py-1 " style="-webkit-box-orient: vertical; padding-left: 24px;" data-action="click:readme-toc#blur" data-targets="readme-toc.entries" data-hydro-click="{&quot;event_type&quot;:&quot;repository_toc_menu.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;entry&quot;,&quot;repository_id&quot;:965782,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="8f66a1a9557891e50219e578a184c32661d9cae16f4b736f213a44c69edf556c" href="#tests">Tests</a>
          <a role="menuitem" class="filter-item SelectMenu-item ws-normal wb-break-word line-clamp-2 py-1 " style="-webkit-box-orient: vertical; padding-left: 24px;" data-action="click:readme-toc#blur" data-targets="readme-toc.entries" data-hydro-click="{&quot;event_type&quot;:&quot;repository_toc_menu.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;entry&quot;,&quot;repository_id&quot;:965782,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="8f66a1a9557891e50219e578a184c32661d9cae16f4b736f213a44c69edf556c" href="#maintainers">Maintainers</a>
          <a role="menuitem" class="filter-item SelectMenu-item ws-normal wb-break-word line-clamp-2 py-1 " style="-webkit-box-orient: vertical; padding-left: 24px;" data-action="click:readme-toc#blur" data-targets="readme-toc.entries" data-hydro-click="{&quot;event_type&quot;:&quot;repository_toc_menu.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;entry&quot;,&quot;repository_id&quot;:965782,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="8f66a1a9557891e50219e578a184c32661d9cae16f4b736f213a44c69edf556c" href="#reading">Reading</a>
          <a role="menuitem" class="filter-item SelectMenu-item ws-normal wb-break-word line-clamp-2 py-1 " style="-webkit-box-orient: vertical; padding-left: 24px;" data-action="click:readme-toc#blur" data-targets="readme-toc.entries" data-hydro-click="{&quot;event_type&quot;:&quot;repository_toc_menu.click&quot;,&quot;payload&quot;:{&quot;target&quot;:&quot;entry&quot;,&quot;repository_id&quot;:965782,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;,&quot;user_id&quot;:null}}" data-hydro-click-hmac="8f66a1a9557891e50219e578a184c32661d9cae16f4b736f213a44c69edf556c" href="#license-mit">License (MIT)</a>
      </div>
    </div>
  </details-menu>
</details>

            <h2 class="Box-title">
              <a href="#readme" data-view-component="true" class="Link--primary">README.md</a>
            </h2>
          </div>
        </div>

          <div data-target="readme-toc.content" class="Box-body px-5 pb-5">
            <article class="markdown-body entry-content container-lg" itemprop="text"><h1 dir="auto"><a id="user-content-validatorjs" class="anchor" aria-hidden="true" href="#validatorjs"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>validator.js</h1>
<p dir="auto"><a href="https://npmjs.org/package/validator" rel="nofollow"><img src="https://camo.githubusercontent.com/6c8bde63cf84c2500202e8e0eb925d93a43c9549ece59af11b85866d3f5744d9/687474703a2f2f696d672e736869656c64732e696f2f6e706d2f762f76616c696461746f722e737667" alt="NPM version" data-canonical-src="http://img.shields.io/npm/v/validator.svg" style="max-width: 100%;"></a>
<a href="https://github.com/validatorjs/validator.js/actions?query=workflow%3ACI"><img src="https://github.com/validatorjs/validator.js/workflows/CI/badge.svg?branch=master" alt="CI" style="max-width: 100%;"></a>
<a href="https://codecov.io/gh/validatorjs/validator.js" rel="nofollow"><img src="https://camo.githubusercontent.com/0b43baa6ffc3671147d7edf43d17e0cfc21dc8d03ab12cb05cf85f06c48f7daa/68747470733a2f2f636f6465636f762e696f2f67682f76616c696461746f726a732f76616c696461746f722e6a732f6272616e63682f6d61737465722f67726170682f62616467652e737667" alt="Coverage" data-canonical-src="https://codecov.io/gh/validatorjs/validator.js/branch/master/graph/badge.svg" style="max-width: 100%;"></a>
<a href="https://npmjs.org/package/validator" rel="nofollow"><img src="https://camo.githubusercontent.com/a2c4ac43446ae7e5878ef42782cad5d1e4605f972cd4f290d7b4474a547c63b9/687474703a2f2f696d672e736869656c64732e696f2f6e706d2f646d2f76616c696461746f722e737667" alt="Downloads" data-canonical-src="http://img.shields.io/npm/dm/validator.svg" style="max-width: 100%;"></a>
<a href="#backers"><img src="https://camo.githubusercontent.com/55d76c6c5df431247822fc9803cb7d9ab7ee9286526838623f4c8256fb06445e/68747470733a2f2f6f70656e636f6c6c6563746976652e636f6d2f76616c696461746f726a732f6261636b6572732f62616467652e737667" alt="Backers on Open Collective" data-canonical-src="https://opencollective.com/validatorjs/backers/badge.svg" style="max-width: 100%;"></a>
<a href="#sponsors"><img src="https://camo.githubusercontent.com/110629f3a1264b1f97ebcbed469eb24ce217aa828db0ec5f2c7ee394847c7696/68747470733a2f2f6f70656e636f6c6c6563746976652e636f6d2f76616c696461746f726a732f73706f6e736f72732f62616467652e737667" alt="Sponsors on Open Collective" data-canonical-src="https://opencollective.com/validatorjs/sponsors/badge.svg" style="max-width: 100%;"></a>
<a href="https://gitter.im/validatorjs/community" rel="nofollow"><img src="https://camo.githubusercontent.com/09c1bcf7b7f4289198eee72c6cbaa20abfe2ffc87c7e54fea0a2825845abb217/68747470733a2f2f6261646765732e6769747465722e696d2f76616c696461746f726a732f636f6d6d756e6974792e737667" alt="Gitter" data-canonical-src="https://badges.gitter.im/validatorjs/community.svg" style="max-width: 100%;"></a>
<a href="https://huntr.dev/bounties/disclose/?target=https://github.com/validatorjs/validator.js" rel="nofollow"><img src="https://camo.githubusercontent.com/30c28e8a19d49b9af85a85ca1c2911731b9659e2e8596315faf92162888f162f/68747470733a2f2f63646e2e68756e74722e6465762f68756e74725f73656375726974795f62616467655f6d6f6e6f2e737667" alt="Disclose a vulnerability" data-canonical-src="https://cdn.huntr.dev/huntr_security_badge_mono.svg" style="max-width: 100%;"></a></p>
<p dir="auto">A library of string validators and sanitizers.</p>
<h2 dir="auto"><a id="user-content-strings-only" class="anchor" aria-hidden="true" href="#strings-only"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>Strings only</h2>
<p dir="auto"><strong>This library validates and sanitizes strings only.</strong></p>
<p dir="auto">If you're not sure if your input is a string, coerce it using <code>input + ''</code>.
Passing anything other than a string will result in an error.</p>
<h2 dir="auto"><a id="user-content-installation-and-usage" class="anchor" aria-hidden="true" href="#installation-and-usage"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>Installation and Usage</h2>
<h3 dir="auto"><a id="user-content-server-side-usage" class="anchor" aria-hidden="true" href="#server-side-usage"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>Server-side usage</h3>
<p dir="auto">Install the library with <code>npm install validator</code></p>
<h4 dir="auto"><a id="user-content-no-es6" class="anchor" aria-hidden="true" href="#no-es6"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>No ES6</h4>
<div class="highlight highlight-source-js notranslate position-relative overflow-auto" data-snippet-clipboard-copy-content="var validator = require('validator');

validator.isEmail('foo@bar.com'); //=&gt; true"><pre><span class="pl-k">var</span> <span class="pl-s1">validator</span> <span class="pl-c1">=</span> <span class="pl-en">require</span><span class="pl-kos">(</span><span class="pl-s">'validator'</span><span class="pl-kos">)</span><span class="pl-kos">;</span>

<span class="pl-s1">validator</span><span class="pl-kos">.</span><span class="pl-en">isEmail</span><span class="pl-kos">(</span><span class="pl-s">'foo@bar.com'</span><span class="pl-kos">)</span><span class="pl-kos">;</span> <span class="pl-c">//=&gt; true</span></pre></div>
<h4 dir="auto"><a id="user-content-es6" class="anchor" aria-hidden="true" href="#es6"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>ES6</h4>
<div class="highlight highlight-source-js notranslate position-relative overflow-auto" data-snippet-clipboard-copy-content="import validator from 'validator';"><pre><span class="pl-k">import</span> <span class="pl-s1">validator</span> <span class="pl-k">from</span> <span class="pl-s">'validator'</span><span class="pl-kos">;</span></pre></div>
<p dir="auto">Or, import only a subset of the library:</p>
<div class="highlight highlight-source-js notranslate position-relative overflow-auto" data-snippet-clipboard-copy-content="import isEmail from 'validator/lib/isEmail';"><pre><span class="pl-k">import</span> <span class="pl-s1">isEmail</span> <span class="pl-k">from</span> <span class="pl-s">'validator/lib/isEmail'</span><span class="pl-kos">;</span></pre></div>
<h4 dir="auto"><a id="user-content-tree-shakeable-es-imports" class="anchor" aria-hidden="true" href="#tree-shakeable-es-imports"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>Tree-shakeable ES imports</h4>
<div class="highlight highlight-source-js notranslate position-relative overflow-auto" data-snippet-clipboard-copy-content="import isEmail from 'validator/es/lib/isEmail';"><pre><span class="pl-k">import</span> <span class="pl-s1">isEmail</span> <span class="pl-k">from</span> <span class="pl-s">'validator/es/lib/isEmail'</span><span class="pl-kos">;</span></pre></div>
<h3 dir="auto"><a id="user-content-client-side-usage" class="anchor" aria-hidden="true" href="#client-side-usage"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>Client-side usage</h3>
<p dir="auto">The library can be loaded either as a standalone script, or through an <a href="http://requirejs.org/docs/whyamd.html" rel="nofollow">AMD</a>-compatible loader</p>
<div class="highlight highlight-text-html-basic notranslate position-relative overflow-auto" data-snippet-clipboard-copy-content="&lt;script type=&quot;text/javascript&quot; src=&quot;validator.min.js&quot;&gt;&lt;/script&gt;
&lt;script type=&quot;text/javascript&quot;&gt;
  validator.isEmail('foo@bar.com'); //=&gt; true
&lt;/script&gt;"><pre><span class="pl-kos">&lt;</span><span class="pl-ent">script</span> <span class="pl-c1">type</span>="<span class="pl-s">text/javascript</span>" <span class="pl-c1">src</span>="<span class="pl-s">validator.min.js</span>"<span class="pl-kos">&gt;</span><span class="pl-kos">&lt;/</span><span class="pl-ent">script</span><span class="pl-kos">&gt;</span>
<span class="pl-kos">&lt;</span><span class="pl-ent">script</span> <span class="pl-c1">type</span>="<span class="pl-s">text/javascript</span>"<span class="pl-kos">&gt;</span>
  <span class="pl-s1">validator</span><span class="pl-kos">.</span><span class="pl-en">isEmail</span><span class="pl-kos">(</span><span class="pl-s">'foo@bar.com'</span><span class="pl-kos">)</span><span class="pl-kos">;</span> <span class="pl-c">//=&gt; true</span>
<span class="pl-kos">&lt;/</span><span class="pl-ent">script</span><span class="pl-kos">&gt;</span></pre></div>
<p dir="auto">The library can also be installed through <a href="http://bower.io/" rel="nofollow">bower</a></p>
<div class="highlight highlight-source-shell notranslate position-relative overflow-auto" data-snippet-clipboard-copy-content="$ bower install validator-js"><pre>$ bower install validator-js</pre></div>
<p dir="auto">CDN</p>
<div class="highlight highlight-text-html-basic notranslate position-relative overflow-auto" data-snippet-clipboard-copy-content="&lt;script src=&quot;https://unpkg.com/validator@latest/validator.min.js&quot;&gt;&lt;/script&gt;"><pre><span class="pl-kos">&lt;</span><span class="pl-ent">script</span> <span class="pl-c1">src</span>="<span class="pl-s">https://unpkg.com/validator@latest/validator.min.js</span>"<span class="pl-kos">&gt;</span><span class="pl-kos">&lt;/</span><span class="pl-ent">script</span><span class="pl-kos">&gt;</span></pre></div>
<h2 dir="auto"><a id="user-content-contributors" class="anchor" aria-hidden="true" href="#contributors"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>Contributors</h2>
<p dir="auto"><a href="https://opencollective.com/validatorjs#backer" rel="nofollow">Become a backer</a></p>
<p dir="auto"><a href="https://opencollective.com/validatorjs#sponsor" rel="nofollow">Become a sponsor</a></p>
<p dir="auto">Thank you to the people who have already contributed:</p>
<p dir="auto"><a href="https://github.com/validatorjs/validator.js/graphs/contributors"><img src="https://camo.githubusercontent.com/c79118f0f01e7dc3948206811b93d4d1440a007ca8c635eb3832905a0876f647/68747470733a2f2f6f70656e636f6c6c6563746976652e636f6d2f76616c696461746f726a732f636f6e7472696275746f72732e7376673f77696474683d383930" data-canonical-src="https://opencollective.com/validatorjs/contributors.svg?width=890" style="max-width: 100%;"></a></p>
<h2 dir="auto"><a id="user-content-validators" class="anchor" aria-hidden="true" href="#validators"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>Validators</h2>
<p dir="auto">Here is a list of the validators currently available.</p>
<table>
<thead>
<tr>
<th>Validator</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong>contains(str, seed [, options ])</strong></td>
<td>check if the string contains the seed.<br><br><code>options</code> is an object that defaults to <code>{ ignoreCase: false, minOccurrences: 1 }</code>.<br>Options: <br> <code>ignoreCase</code>: Ignore case when doing comparison, default false<br><code>minOccurences</code>: Minimum number of occurrences for the seed in the string. Defaults to 1.</td>
</tr>
<tr>
<td><strong>equals(str, comparison)</strong></td>
<td>check if the string matches the comparison.</td>
</tr>
<tr>
<td><strong>isAfter(str [, date])</strong></td>
<td>check if the string is a date that's after the specified date (defaults to now).</td>
</tr>
<tr>
<td><strong>isAlpha(str [, locale, options])</strong></td>
<td>check if the string contains only letters (a-zA-Z).<br><br>Locale is one of <code>['ar', 'ar-AE', 'ar-BH', 'ar-DZ', 'ar-EG', 'ar-IQ', 'ar-JO', 'ar-KW', 'ar-LB', 'ar-LY', 'ar-MA', 'ar-QA', 'ar-QM', 'ar-SA', 'ar-SD', 'ar-SY', 'ar-TN', 'ar-YE', 'bg-BG', 'cs-CZ', 'da-DK', 'de-DE', 'el-GR', 'en-AU', 'en-GB', 'en-HK', 'en-IN', 'en-NZ', 'en-US', 'en-ZA', 'en-ZM', 'es-ES', 'fa-IR', 'fi-FI', 'fr-CA', 'fr-FR', 'he', 'hi-IN', 'hu-HU', 'it-IT', 'ku-IQ', 'nb-NO', 'nl-NL', 'nn-NO', 'pl-PL', 'pt-BR', 'pt-PT', 'ru-RU', 'sl-SI', 'sk-SK', 'sr-RS', 'sr-RS@latin', 'sv-SE', 'tr-TR', 'uk-UA']</code>) and defaults to <code>en-US</code>. Locale list is <code>validator.isAlphaLocales</code>. options is an optional object that can be supplied with the following key(s): ignore which can either be a String or RegExp of characters to be ignored e.g. " -" will ignore spaces and -'s.</td>
</tr>
<tr>
<td><strong>isAlphanumeric(str [, locale, options])</strong></td>
<td>check if the string contains only letters and numbers (a-zA-Z0-9).<br><br>Locale is one of <code>['ar', 'ar-AE', 'ar-BH', 'ar-DZ', 'ar-EG', 'ar-IQ', 'ar-JO', 'ar-KW', 'ar-LB', 'ar-LY', 'ar-MA', 'ar-QA', 'ar-QM', 'ar-SA', 'ar-SD', 'ar-SY', 'ar-TN', 'ar-YE', 'bg-BG', 'cs-CZ', 'da-DK', 'de-DE', 'el-GR', 'en-AU', 'en-GB', 'en-HK', 'en-IN', 'en-NZ', 'en-US', 'en-ZA', 'en-ZM', 'es-ES', 'fa-IR', 'fi-FI', 'fr-CA', 'fr-FR', 'he', 'hi-IN', 'hu-HU', 'it-IT', 'ku-IQ', 'nb-NO', 'nl-NL', 'nn-NO', 'pl-PL', 'pt-BR', 'pt-PT', 'ru-RU', 'sl-SI', 'sk-SK', 'sr-RS', 'sr-RS@latin', 'sv-SE', 'tr-TR', 'uk-UA']</code>) and defaults to <code>en-US</code>. Locale list is <code>validator.isAlphanumericLocales</code>. options is an optional object that can be supplied with the following key(s): ignore which can either be a String or RegExp of characters to be ignored e.g. " -" will ignore spaces and -'s.</td>
</tr>
<tr>
<td><strong>isAscii(str)</strong></td>
<td>check if the string contains ASCII chars only.</td>
</tr>
<tr>
<td><strong>isBase32(str [, options])</strong></td>
<td>check if a string is base32 encoded. <code>options</code> is optional and defaults to <code>{crockford: false}</code>.<br> When <code>crockford</code> is true it tests the given base32 encoded string using <a href="http://www.crockford.com/base32.html" rel="nofollow">Crockford's base32 alternative</a>.</td>
</tr>
<tr>
<td><strong>isBase58(str)</strong></td>
<td>check if a string is base58 encoded.</td>
</tr>
<tr>
<td><strong>isBase64(str [, options])</strong></td>
<td>check if a string is base64 encoded. options is optional and defaults to <code>{urlSafe: false}</code><br> when <code>urlSafe</code> is true it tests the given base64 encoded string is <a href="https://base64.guru/standards/base64url" rel="nofollow">url safe</a></td>
</tr>
<tr>
<td><strong>isBefore(str [, date])</strong></td>
<td>check if the string is a date that's before the specified date.</td>
</tr>
<tr>
<td><strong>isBIC(str)</strong></td>
<td>check if a string is a BIC (Bank Identification Code) or SWIFT code.</td>
</tr>
<tr>
<td><strong>isBoolean(str [, options])</strong></td>
<td>check if a string is a boolean.<br><code>options</code> is an object which defaults to <code>{ loose: false }</code>. If loose is is set to false, the validator will strictly match ['true', 'false', '0', '1']. If loose is set to true, the validator will also match 'yes', 'no', and will match a valid boolean string of any case. (eg: ['true', 'True', 'TRUE']).</td>
</tr>
<tr>
<td><strong>isBtcAddress(str)</strong></td>
<td>check if the string is a valid BTC address.</td>
</tr>
<tr>
<td><strong>isByteLength(str [, options])</strong></td>
<td>check if the string's length (in UTF-8 bytes) falls in a range.<br><br><code>options</code> is an object which defaults to <code>{min:0, max: undefined}</code>.</td>
</tr>
<tr>
<td><strong>isCreditCard(str)</strong></td>
<td>check if the string is a credit card.</td>
</tr>
<tr>
<td><strong>isCurrency(str [, options])</strong></td>
<td>check if the string is a valid currency amount.<br><br><code>options</code> is an object which defaults to <code>{symbol: '$', require_symbol: false, allow_space_after_symbol: false, symbol_after_digits: false, allow_negatives: true, parens_for_negatives: false, negative_sign_before_digits: false, negative_sign_after_digits: false, allow_negative_sign_placeholder: false, thousands_separator: ',', decimal_separator: '.', allow_decimal: true, require_decimal: false, digits_after_decimal: [2], allow_space_after_digits: false}</code>.<br><strong>Note:</strong> The array <code>digits_after_decimal</code> is filled with the exact number of digits allowed not a range, for example a range 1 to 3 will be given as [1, 2, 3].</td>
</tr>
<tr>
<td><strong>isDataURI(str)</strong></td>
<td>check if the string is a <a href="https://developer.mozilla.org/en-US/docs/Web/HTTP/data_URIs" rel="nofollow">data uri format</a>.</td>
</tr>
<tr>
<td><strong>isDate(input [, options])</strong></td>
<td>Check if the input is a valid date. e.g. [<code>2002-07-15</code>, new Date()].<br><br> <code>options</code> is an object which can contain the keys <code>format</code>, <code>strictMode</code> and/or <code>delimiters</code><br><br><code>format</code> is a string and defaults to <code>YYYY/MM/DD</code>.<br><br><code>strictMode</code> is a boolean and defaults to <code>false</code>. If <code>strictMode</code> is set to true, the validator will reject inputs different from <code>format</code>.<br><br> <code>delimiters</code> is an array of allowed date delimiters and defaults to <code>['/', '-']</code>.</td>
</tr>
<tr>
<td><strong>isDecimal(str [, options])</strong></td>
<td>check if the string represents a decimal number, such as 0.1, .3, 1.1, 1.00003, 4.0, etc.<br><br><code>options</code> is an object which defaults to <code>{force_decimal: false, decimal_digits: '1,', locale: 'en-US'}</code><br><br><code>locale</code> determine the decimal separator and is one of <code>['ar', 'ar-AE', 'ar-BH', 'ar-DZ', 'ar-EG', 'ar-IQ', 'ar-JO', 'ar-KW', 'ar-LB', 'ar-LY', 'ar-MA', 'ar-QA', 'ar-QM', 'ar-SA', 'ar-SD', 'ar-SY', 'ar-TN', 'ar-YE', 'bg-BG', 'cs-CZ', 'da-DK', 'de-DE', 'el-GR', 'en-AU', 'en-GB', 'en-HK', 'en-IN', 'en-NZ', 'en-US', 'en-ZA', 'en-ZM', 'es-ES', 'fa', 'fa-AF', 'fa-IR', 'fr-FR', 'fr-CA', 'hu-HU', 'id-ID', 'it-IT', 'ku-IQ', 'nb-NO', 'nl-NL', 'nn-NO', 'pl-PL', 'pl-Pl', 'pt-BR', 'pt-PT', 'ru-RU', 'sl-SI', 'sr-RS', 'sr-RS@latin', 'sv-SE', 'tr-TR', 'uk-UA', 'vi-VN']</code>.<br><strong>Note:</strong> <code>decimal_digits</code> is given as a range like '1,3', a specific value like '3' or min like '1,'.</td>
</tr>
<tr>
<td><strong>isDivisibleBy(str, number)</strong></td>
<td>check if the string is a number that's divisible by another.</td>
</tr>
<tr>
<td><strong>isEAN(str)</strong></td>
<td>check if the string is an EAN (European Article Number).</td>
</tr>
<tr>
<td><strong>isEmail(str [, options])</strong></td>
<td>check if the string is an email.<br><br><code>options</code> is an object which defaults to <code>{ allow_display_name: false, require_display_name: false, allow_utf8_local_part: true, require_tld: true, allow_ip_domain: false, domain_specific_validation: false, blacklisted_chars: '', host_blacklist: [] }</code>. If <code>allow_display_name</code> is set to true, the validator will also match <code>Display Name &lt;email-address&gt;</code>. If <code>require_display_name</code> is set to true, the validator will reject strings without the format <code>Display Name &lt;email-address&gt;</code>. If <code>allow_utf8_local_part</code> is set to false, the validator will not allow any non-English UTF8 character in email address' local part. If <code>require_tld</code> is set to false, e-mail addresses without having TLD in their domain will also be matched. If <code>ignore_max_length</code> is set to true, the validator will not check for the standard max length of an email. If <code>allow_ip_domain</code> is set to true, the validator will allow IP addresses in the host part. If <code>domain_specific_validation</code> is true, some additional validation will be enabled, e.g. disallowing certain syntactically valid email addresses that are rejected by GMail. If <code>blacklisted_chars</code> receives a string, then the validator will reject emails that include any of the characters in the string, in the name part. If <code>host_blacklist</code> is set to an array of strings and the part of the email after the <code>@</code> symbol matches one of the strings defined in it, the validation fails.</td>
</tr>
<tr>
<td><strong>isEmpty(str [, options])</strong></td>
<td>check if the string has a length of zero.<br><br><code>options</code> is an object which defaults to <code>{ ignore_whitespace:false }</code>.</td>
</tr>
<tr>
<td><strong>isEthereumAddress(str)</strong></td>
<td>check if the string is an <a href="https://ethereum.org/" rel="nofollow">Ethereum</a> address using basic regex. Does not validate address checksums.</td>
</tr>
<tr>
<td><strong>isFloat(str [, options])</strong></td>
<td>check if the string is a float.<br><br><code>options</code> is an object which can contain the keys <code>min</code>, <code>max</code>, <code>gt</code>, and/or <code>lt</code> to validate the float is within boundaries (e.g. <code>{ min: 7.22, max: 9.55 }</code>) it also has <code>locale</code> as an option.<br><br><code>min</code> and <code>max</code> are equivalent to 'greater or equal' and 'less or equal', respectively while <code>gt</code> and <code>lt</code> are their strict counterparts.<br><br><code>locale</code> determine the decimal separator and is one of <code>['ar', 'ar-AE', 'ar-BH', 'ar-DZ', 'ar-EG', 'ar-IQ', 'ar-JO', 'ar-KW', 'ar-LB', 'ar-LY', 'ar-MA', 'ar-QA', 'ar-QM', 'ar-SA', 'ar-SD', 'ar-SY', 'ar-TN', 'ar-YE', 'bg-BG', 'cs-CZ', 'da-DK', 'de-DE', 'en-AU', 'en-GB', 'en-HK', 'en-IN', 'en-NZ', 'en-US', 'en-ZA', 'en-ZM', 'es-ES', 'fr-CA', 'fr-FR', 'hu-HU', 'it-IT', 'nb-NO', 'nl-NL', 'nn-NO', 'pl-PL', 'pt-BR', 'pt-PT', 'ru-RU', 'sl-SI', 'sr-RS', 'sr-RS@latin', 'sv-SE', 'tr-TR', 'uk-UA']</code>. Locale list is <code>validator.isFloatLocales</code>.</td>
</tr>
<tr>
<td><strong>isFQDN(str [, options])</strong></td>
<td>check if the string is a fully qualified domain name (e.g. domain.com).<br><br><code>options</code> is an object which defaults to <code>{ require_tld: true, allow_underscores: false, allow_trailing_dot: false, allow_numeric_tld: false, allow_wildcard: false }</code>. If <code>allow_wildcard</code> is set to true, the validator will allow domain starting with <code>*.</code> (e.g. <code>*.example.com</code> or <code>*.shop.example.com</code>).</td>
</tr>
<tr>
<td><strong>isFullWidth(str)</strong></td>
<td>check if the string contains any full-width chars.</td>
</tr>
<tr>
<td><strong>isHalfWidth(str)</strong></td>
<td>check if the string contains any half-width chars.</td>
</tr>
<tr>
<td><strong>isHash(str, algorithm)</strong></td>
<td>check if the string is a hash of type algorithm.<br><br>Algorithm is one of <code>['md4', 'md5', 'sha1', 'sha256', 'sha384', 'sha512', 'ripemd128', 'ripemd160', 'tiger128', 'tiger160', 'tiger192', 'crc32', 'crc32b']</code></td>
</tr>
<tr>
<td><strong>isHexadecimal(str)</strong></td>
<td>check if the string is a hexadecimal number.</td>
</tr>
<tr>
<td><strong>isHexColor(str)</strong></td>
<td>check if the string is a hexadecimal color.</td>
</tr>
<tr>
<td><strong>isHSL(str)</strong></td>
<td>check if the string is an HSL (hue, saturation, lightness, optional alpha) color based on <a href="https://developer.mozilla.org/en-US/docs/Web/CSS/color_value" rel="nofollow">CSS Colors Level 4 specification</a>.<br><br>Comma-separated format supported. Space-separated format supported with the exception of a few edge cases (ex: <code>hsl(200grad+.1%62%/1)</code>).</td>
</tr>
<tr>
<td><strong>isIBAN(str)</strong></td>
<td>check if a string is a IBAN (International Bank Account Number).</td>
</tr>
<tr>
<td><strong>isIdentityCard(str [, locale])</strong></td>
<td>check if the string is a valid identity card code.<br><br><code>locale</code> is one of <code>['LK', 'PL', 'ES', 'FI', 'IN', 'IT', 'IR', 'MZ', 'NO', 'TH', 'zh-TW', 'he-IL', 'ar-LY', 'ar-TN', 'zh-CN']</code> OR <code>'any'</code>. If 'any' is used, function will check if any of the locals match.<br><br>Defaults to 'any'.</td>
</tr>
<tr>
<td><strong>isIMEI(str [, options]))</strong></td>
<td>check if the string is a valid IMEI number. Imei should be of format <code>###############</code> or <code>##-######-######-#</code>.<br><br><code>options</code> is an object which can contain the keys <code>allow_hyphens</code>. Defaults to first format . If allow_hyphens is set to true, the validator will validate the second format.</td>
</tr>
<tr>
<td><strong>isIn(str, values)</strong></td>
<td>check if the string is in a array of allowed values.</td>
</tr>
<tr>
<td><strong>isInt(str [, options])</strong></td>
<td>check if the string is an integer.<br><br><code>options</code> is an object which can contain the keys <code>min</code> and/or <code>max</code> to check the integer is within boundaries (e.g. <code>{ min: 10, max: 99 }</code>). <code>options</code> can also contain the key <code>allow_leading_zeroes</code>, which when set to false will disallow integer values with leading zeroes (e.g. <code>{ allow_leading_zeroes: false }</code>). Finally, <code>options</code> can contain the keys <code>gt</code> and/or <code>lt</code> which will enforce integers being greater than or less than, respectively, the value provided (e.g. <code>{gt: 1, lt: 4}</code> for a number between 1 and 4).</td>
</tr>
<tr>
<td><strong>isIP(str [, version])</strong></td>
<td>check if the string is an IP (version 4 or 6).</td>
</tr>
<tr>
<td><strong>isIPRange(str [, version])</strong></td>
<td>check if the string is an IP Range (version 4 or 6).</td>
</tr>
<tr>
<td><strong>isISBN(str [, version])</strong></td>
<td>check if the string is an ISBN (version 10 or 13).</td>
</tr>
<tr>
<td><strong>isISIN(str)</strong></td>
<td>check if the string is an <a href="https://en.wikipedia.org/wiki/International_Securities_Identification_Number" rel="nofollow">ISIN</a> (stock/security identifier).</td>
</tr>
<tr>
<td><strong>isISO6391(str)</strong></td>
<td>check if the string is a valid <a href="https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes" rel="nofollow">ISO 639-1</a> language code.</td>
</tr>
<tr>
<td><strong>isISO8601(str [, options])</strong></td>
<td>check if the string is a valid <a href="https://en.wikipedia.org/wiki/ISO_8601" rel="nofollow">ISO 8601</a> date. <br><code>options</code> is an object which defaults to <code>{ strict: false, strictSeparator: false }</code>. If <code>strict</code> is true, date strings with invalid dates like <code>2009-02-29</code> will be invalid. If <code>strictSeparator</code> is true, date strings with date and time separated by anything other than a T will be invalid.</td>
</tr>
<tr>
<td><strong>isISO31661Alpha2(str)</strong></td>
<td>check if the string is a valid <a href="https://en.wikipedia.org/wiki/ISO_3166-1_alpha-2" rel="nofollow">ISO 3166-1 alpha-2</a> officially assigned country code.</td>
</tr>
<tr>
<td><strong>isISO31661Alpha3(str)</strong></td>
<td>check if the string is a valid <a href="https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3" rel="nofollow">ISO 3166-1 alpha-3</a> officially assigned country code.</td>
</tr>
<tr>
<td><strong>isISO4217(str)</strong></td>
<td>check if the string is a valid <a href="https://en.wikipedia.org/wiki/ISO_4217" rel="nofollow">ISO 4217</a> officially assigned currency code.</td>
</tr>
<tr>
<td><strong>isISRC(str)</strong></td>
<td>check if the string is a <a href="https://en.wikipedia.org/wiki/International_Standard_Recording_Code" rel="nofollow">ISRC</a>.</td>
</tr>
<tr>
<td><strong>isISSN(str [, options])</strong></td>
<td>check if the string is an <a href="https://en.wikipedia.org/wiki/International_Standard_Serial_Number" rel="nofollow">ISSN</a>.<br><br><code>options</code> is an object which defaults to <code>{ case_sensitive: false, require_hyphen: false }</code>. If <code>case_sensitive</code> is true, ISSNs with a lowercase <code>'x'</code> as the check digit are rejected.</td>
</tr>
<tr>
<td><strong>isJSON(str [, options])</strong></td>
<td>check if the string is valid JSON (note: uses JSON.parse).<br><br><code>options</code> is an object which defaults to <code>{ allow_primitives: false }</code>. If <code>allow_primitives</code> is true, the primitives 'true', 'false' and 'null' are accepted as valid JSON values.</td>
</tr>
<tr>
<td><strong>isJWT(str)</strong></td>
<td>check if the string is valid JWT token.</td>
</tr>
<tr>
<td><strong>isLatLong(str [, options])</strong></td>
<td>check if the string is a valid latitude-longitude coordinate in the format <code>lat,long</code> or <code>lat, long</code>.<br><br><code>options</code> is an object that defaults to <code>{ checkDMS: false }</code>. Pass <code>checkDMS</code> as <code>true</code> to validate DMS(degrees, minutes, and seconds) latitude-longitude format.</td>
</tr>
<tr>
<td><strong>isLength(str [, options])</strong></td>
<td>check if the string's length falls in a range.<br><br><code>options</code> is an object which defaults to <code>{min:0, max: undefined}</code>. Note: this function takes into account surrogate pairs.</td>
</tr>
<tr>
<td><strong>isLicensePlate(str [, locale])</strong></td>
<td>check if string matches the format of a country's license plate.<br><br>(locale is one of <code>['cs-CZ', 'de-DE', 'de-LI', 'fi-FI', 'pt-BR', 'pt-PT', 'sq-AL', 'sv-SE']</code> or <code>any</code>)</td>
</tr>
<tr>
<td><strong>isLocale(str)</strong></td>
<td>check if the string is a locale</td>
</tr>
<tr>
<td><strong>isLowercase(str)</strong></td>
<td>check if the string is lowercase.</td>
</tr>
<tr>
<td><strong>isMACAddress(str [, options])</strong></td>
<td>check if the string is a MAC address.<br><br><code>options</code> is an object which defaults to <code>{no_separators: false}</code>. If <code>no_separators</code> is true, the validator will allow MAC addresses without separators. Also, it allows the use of hyphens, spaces or dots e.g  '01 02 03 04 05 ab', '01-02-03-04-05-ab' or '0102.0304.05ab'. The options also allow a <code>eui</code> property to specify if it needs to be validated against EUI-48 or EUI-64. The accepted values of <code>eui</code> are: 48, 64.</td>
</tr>
<tr>
<td><strong>isMagnetURI(str)</strong></td>
<td>check if the string is a <a href="https://en.wikipedia.org/wiki/Magnet_URI_scheme" rel="nofollow">magnet uri format</a>.</td>
</tr>
<tr>
<td><strong>isMD5(str)</strong></td>
<td>check if the string is a MD5 hash.<br><br>Please note that you can also use the <code>isHash(str, 'md5')</code> function. Keep in mind that MD5 has some collision weaknesses compared to other algorithms (e.g., SHA).</td>
</tr>
<tr>
<td><strong>isMimeType(str)</strong></td>
<td>check if the string matches to a valid <a href="https://en.wikipedia.org/wiki/Media_type" rel="nofollow">MIME type</a> format</td>
</tr>
<tr>
<td><strong>isMobilePhone(str [, locale [, options]])</strong></td>
<td>check if the string is a mobile phone number,<br><br>(locale is either an array of locales (e.g <code>['sk-SK', 'sr-RS']</code>) OR one of <code>['am-Am', 'ar-AE', 'ar-BH', 'ar-DZ', 'ar-EG', 'ar-IQ', ar-JO', 'ar-KW', 'ar-PS', 'ar-SA', 'ar-SY', 'ar-TN', 'az-AZ', 'az-LY', 'az-LB', 'bs-BA', 'be-BY', 'bg-BG', 'bn-BD', 'ca-AD', 'cs-CZ', 'da-DK', 'de-DE', 'de-AT', 'de-CH', 'de-LU', 'dv-MV', 'el-GR', 'en-AU', 'en-BM', 'en-BW', 'en-CA', 'en-GB', 'en-GG', 'en-GH', 'en-GY', 'en-HK', 'en-MO', 'en-IE', 'en-IN', 'en-LS', 'en-KE', 'en-KI', 'en-MT', 'en-MU', 'en-NG', 'en-NZ', 'en-PK', 'en-PH', 'en-RW', 'en-SG', 'en-SL', 'en-UG', 'en-US', 'en-TZ', 'en-ZA', 'en-ZM', 'en-ZW', 'es-AR', 'es-BO', 'es-CL', 'es-CO', 'es-CR', 'es-CU', 'es-DO', 'es-HN', 'es-PE', 'es-EC', 'es-ES', 'es-MX', 'es-PA', 'es-PY', 'es-SV', 'es-UY', 'es-VE', 'et-EE', 'fa-IR', 'fi-FI', 'fj-FJ', 'fo-FO', 'fr-BE', 'fr-BF', 'fr-FR', 'fr-GF', 'fr-GP', 'fr-MQ', 'fr-PF', 'fr-RE', 'ga-IE', 'he-IL', 'hu-HU', 'id-ID', 'it-IT', 'it-SM', 'ja-JP', 'ka-GE', 'kk-KZ', 'kl-GL', 'ko-KR', 'lt-LT', 'ms-MY', 'mn-MN', 'my-MM' , 'mz-MZ', nb-NO', 'ne-NP', 'nl-BE', 'nl-NL','nl-AW' 'nn-NO', 'pl-PL', 'pt-BR', 'pt-PT', 'pt-AO', 'ro-RO', 'ru-RU', 'si-LK' 'sl-SI', 'sk-SK', 'sq-AL', 'sr-RS', 'sv-SE', 'tg-TJ', 'th-TH', 'tk-TM', 'tr-TR', 'uk-UA', 'uz-UZ', 'vi-VN', 'zh-CN', 'zh-HK', 'zh-MO', 'zh-TW', 'dz-BT']</code> OR defaults to 'any'. If 'any' or a falsey value is used, function will check if any of the locales match).<br><br><code>options</code> is an optional object that can be supplied with the following keys: <code>strictMode</code>, if this is set to <code>true</code>, the mobile phone number must be supplied with the country code and therefore must start with <code>+</code>. Locale list is <code>validator.isMobilePhoneLocales</code>.</td>
</tr>
<tr>
<td><strong>isMongoId(str)</strong></td>
<td>check if the string is a valid hex-encoded representation of a <a href="http://docs.mongodb.org/manual/reference/object-id/" rel="nofollow">MongoDB ObjectId</a>.</td>
</tr>
<tr>
<td><strong>isMultibyte(str)</strong></td>
<td>check if the string contains one or more multibyte chars.</td>
</tr>
<tr>
<td><strong>isNumeric(str [, options])</strong></td>
<td>check if the string contains only numbers.<br><br><code>options</code> is an object which defaults to <code>{no_symbols: false}</code> it also has locale as an option. If <code>no_symbols</code> is true, the validator will reject numeric strings that feature a symbol (e.g. <code>+</code>, <code>-</code>, or <code>.</code>).<br><br><code>locale</code> determine the decimal separator and is one of <code>['ar', 'ar-AE', 'ar-BH', 'ar-DZ', 'ar-EG', 'ar-IQ', 'ar-JO', 'ar-KW', 'ar-LB', 'ar-LY', 'ar-MA', 'ar-QA', 'ar-QM', 'ar-SA', 'ar-SD', 'ar-SY', 'ar-TN', 'ar-YE', 'bg-BG', 'cs-CZ', 'da-DK', 'de-DE', 'en-AU', 'en-GB', 'en-HK', 'en-IN', 'en-NZ', 'en-US', 'en-ZA', 'en-ZM', 'es-ES', 'fr-FR', 'fr-CA', 'hu-HU', 'it-IT', 'nb-NO', 'nl-NL', 'nn-NO', 'pl-PL', 'pt-BR', 'pt-PT', 'ru-RU', 'sl-SI', 'sr-RS', 'sr-RS@latin', 'sv-SE', 'tr-TR', 'uk-UA']</code>.</td>
</tr>
<tr>
<td><strong>isOctal(str)</strong></td>
<td>check if the string is a valid octal number.</td>
</tr>
<tr>
<td><strong>isPassportNumber(str, countryCode)</strong></td>
<td>check if the string is a valid passport number.<br><br>(countryCode is one of <code>[ 'AM', 'AR', 'AT', 'AU', 'BE', 'BG', 'BY', 'BR', 'CA', 'CH', 'CN', 'CY', 'CZ', 'DE', 'DK', 'DZ', 'EE', 'ES', 'FI', 'FR', 'GB', 'GR', 'HR', 'HU', 'IE' 'IN', 'IR', 'ID', 'IS', 'IT', 'JP', 'KR', 'LT', 'LU', 'LV', 'LY', 'MT', 'MY', 'MZ', 'NL', 'PL', 'PT', 'RO', 'RU', 'SE', 'SL', 'SK', 'TR', 'UA', 'US' ]</code>.</td>
</tr>
<tr>
<td><strong>isPort(str)</strong></td>
<td>check if the string is a valid port number.</td>
</tr>
<tr>
<td><strong>isPostalCode(str, locale)</strong></td>
<td>check if the string is a postal code,<br><br>(locale is one of <code>[ 'AD', 'AT', 'AU', 'AZ', 'BA', 'BE', 'BG', 'BR', 'BY', 'CA', 'CH', 'CN', 'CZ', 'DE', 'DK', 'DO', 'DZ', 'EE', 'ES', 'FI', 'FR', 'GB', 'GR', 'HR', 'HT', 'HU', 'ID', 'IE' 'IL', 'IN', 'IR', 'IS', 'IT', 'JP', 'KE', 'KR', 'LI', 'LK', 'LT', 'LU', 'LV', 'MT', 'MX', 'MY', 'NL', 'NO', 'NP', 'NZ', 'PL', 'PR', 'PT', 'RO', 'RU', 'SA', 'SE', 'SG', 'SI', 'SK', 'TH', 'TN', 'TW', 'UA', 'US', 'ZA', 'ZM' ]</code> OR 'any'. If 'any' is used, function will check if any of the locals match. Locale list is <code>validator.isPostalCodeLocales</code>.).</td>
</tr>
<tr>
<td><strong>isRFC3339(str)</strong></td>
<td>check if the string is a valid <a href="https://tools.ietf.org/html/rfc3339" rel="nofollow">RFC 3339</a> date.</td>
</tr>
<tr>
<td><strong>isRgbColor(str [, includePercentValues])</strong></td>
<td>check if the string is a rgb or rgba color.<br><br><code>includePercentValues</code> defaults to <code>true</code>. If you don't want to allow to set <code>rgb</code> or <code>rgba</code> values with percents, like <code>rgb(5%,5%,5%)</code>, or <code>rgba(90%,90%,90%,.3)</code>, then set it to false.</td>
</tr>
<tr>
<td><strong>isSemVer(str)</strong></td>
<td>check if the string is a Semantic Versioning Specification (SemVer).</td>
</tr>
<tr>
<td><strong>isSurrogatePair(str)</strong></td>
<td>check if the string contains any surrogate pairs chars.</td>
</tr>
<tr>
<td><strong>isUppercase(str)</strong></td>
<td>check if the string is uppercase.</td>
</tr>
<tr>
<td><strong>isSlug</strong></td>
<td>Check if the string is of type slug. <code>Options</code> allow a single hyphen between string. e.g. [<code>cn-cn</code>, <code>cn-c-c</code>]</td>
</tr>
<tr>
<td><strong>isStrongPassword(str [, options])</strong></td>
<td>Check if a password is strong or not. Allows for custom requirements or scoring rules. If <code>returnScore</code> is true, then the function returns an integer score for the password rather than a boolean.<br>Default options: <br><code>{ minLength: 8, minLowercase: 1, minUppercase: 1, minNumbers: 1, minSymbols: 1, returnScore: false, pointsPerUnique: 1, pointsPerRepeat: 0.5, pointsForContainingLower: 10, pointsForContainingUpper: 10, pointsForContainingNumber: 10, pointsForContainingSymbol: 10 }</code></td>
</tr>
<tr>
<td><strong>isTaxID(str, locale)</strong></td>
<td>Check if the given value is a valid Tax Identification Number. Default locale is <code>en-US</code>.<br><br>More info about exact TIN support can be found in <code>src/lib/isTaxID.js</code><br><br>Supported locales: <code>[ 'bg-BG', 'cs-CZ', 'de-AT', 'de-DE', 'dk-DK', 'el-CY', 'el-GR', 'en-CA', 'en-GB', 'en-IE', 'en-US', 'es-ES', 'et-EE', 'fi-FI', 'fr-BE', 'fr-CA', 'fr-FR', 'fr-LU', 'hr-HR', 'hu-HU', 'it-IT', 'lb-LU', 'lt-LT', 'lv-LV' 'mt-MT', 'nl-BE', 'nl-NL', 'pl-PL', 'pt-BR', 'pt-PT', 'ro-RO', 'sk-SK', 'sl-SI', 'sv-SE' ]</code></td>
</tr>
<tr>
<td><strong>isURL(str [, options])</strong></td>
<td>check if the string is an URL.<br><br><code>options</code> is an object which defaults to <code>{ protocols: ['http','https','ftp'], require_tld: true, require_protocol: false, require_host: true, require_port: false, require_valid_protocol: true, allow_underscores: false, host_whitelist: false, host_blacklist: false, allow_trailing_dot: false, allow_protocol_relative_urls: false, allow_fragments: true, allow_query_components: true, disallow_auth: false, validate_length: true }</code>.<br><br>require_protocol - if set as true isURL will return false if protocol is not present in the URL.<br>require_valid_protocol - isURL will check if the URL's protocol is present in the protocols option.<br>protocols - valid protocols can be modified with this option.<br>require_host - if set as false isURL will not check if host is present in the URL.<br>require_port - if set as true isURL will check if port is present in the URL.<br>allow_protocol_relative_urls - if set as true protocol relative URLs will be allowed.<br>allow_fragments - if set as false isURL will return false if fragments are present.<br>allow_query_components - if set as false isURL will return false if query components are present.<br>validate_length - if set as false isURL will skip string length validation (2083 characters is IE max URL length).</td>
</tr>
<tr>
<td><strong>isUUID(str [, version])</strong></td>
<td>check if the string is a UUID (version 1, 2, 3, 4 or 5).</td>
</tr>
<tr>
<td><strong>isVariableWidth(str)</strong></td>
<td>check if the string contains a mixture of full and half-width chars.</td>
</tr>
<tr>
<td><strong>isVAT(str, countryCode)</strong></td>
<td>checks that the string is a <a href="https://en.wikipedia.org/wiki/VAT_identification_number" rel="nofollow">valid VAT number</a> if validation is available for the given country code matching <a href="https://en.wikipedia.org/wiki/ISO_3166-1_alpha-2" rel="nofollow">ISO 3166-1 alpha-2</a>. <br><br>Available country codes: <code>[ 'GB', 'IT','NL' ]</code>.</td>
</tr>
<tr>
<td><strong>isWhitelisted(str, chars)</strong></td>
<td>checks characters if they appear in the whitelist.</td>
</tr>
<tr>
<td><strong>matches(str, pattern [, modifiers])</strong></td>
<td>check if string matches the pattern.<br><br>Either <code>matches('foo', /foo/i)</code> or <code>matches('foo', 'foo', 'i')</code>.</td>
</tr>
</tbody>
</table>
<h2 dir="auto"><a id="user-content-sanitizers" class="anchor" aria-hidden="true" href="#sanitizers"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>Sanitizers</h2>
<p dir="auto">Here is a list of the sanitizers currently available.</p>
<table>
<thead>
<tr>
<th>Sanitizer</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td><strong>blacklist(input, chars)</strong></td>
<td>remove characters that appear in the blacklist. The characters are used in a RegExp and so you will need to escape some chars, e.g. <code>blacklist(input, '\\[\\]')</code>.</td>
</tr>
<tr>
<td><strong>escape(input)</strong></td>
<td>replace <code>&lt;</code>, <code>&gt;</code>, <code>&amp;</code>, <code>'</code>, <code>"</code> and <code>/</code> with HTML entities.</td>
</tr>
<tr>
<td><strong>ltrim(input [, chars])</strong></td>
<td>trim characters from the left-side of the input.</td>
</tr>
<tr>
<td><strong>normalizeEmail(email [, options])</strong></td>
<td>canonicalizes an email address. (This doesn't validate that the input is an email, if you want to validate the email use isEmail beforehand)<br><br><code>options</code> is an object with the following keys and default values:<br><ul dir="auto"><li><em>all_lowercase: true</em> - Transforms the local part (before the @ symbol) of all email addresses to lowercase. Please note that this may violate RFC 5321, which gives providers the possibility to treat the local part of email addresses in a case sensitive way (although in practice most - yet not all - providers don't). The domain part of the email address is always lowercased, as it's case insensitive per RFC 1035.</li><li><em>gmail_lowercase: true</em> - GMail addresses are known to be case-insensitive, so this switch allows lowercasing them even when <em>all_lowercase</em> is set to false. Please note that when <em>all_lowercase</em> is true, GMail addresses are lowercased regardless of the value of this setting.</li><li><em>gmail_remove_dots: true</em>: Removes dots from the local part of the email address, as GMail ignores them (e.g. "john.doe" and "johndoe" are considered equal).</li><li><em>gmail_remove_subaddress: true</em>: Normalizes addresses by removing "sub-addresses", which is the part following a "+" sign (e.g. "<a href="mailto:foo+bar@gmail.com">foo+bar@gmail.com</a>" becomes "<a href="mailto:foo@gmail.com">foo@gmail.com</a>").</li><li><em>gmail_convert_googlemaildotcom: true</em>: Converts addresses with domain @googlemail.com to @gmail.com, as they're equivalent.</li><li><em>outlookdotcom_lowercase: true</em> - Outlook.com addresses (including Windows Live and Hotmail) are known to be case-insensitive, so this switch allows lowercasing them even when <em>all_lowercase</em> is set to false. Please note that when <em>all_lowercase</em> is true, Outlook.com addresses are lowercased regardless of the value of this setting.</li><li><em>outlookdotcom_remove_subaddress: true</em>: Normalizes addresses by removing "sub-addresses", which is the part following a "+" sign (e.g. "<a href="mailto:foo+bar@outlook.com">foo+bar@outlook.com</a>" becomes "<a href="mailto:foo@outlook.com">foo@outlook.com</a>").</li><li><em>yahoo_lowercase: true</em> - Yahoo Mail addresses are known to be case-insensitive, so this switch allows lowercasing them even when <em>all_lowercase</em> is set to false. Please note that when <em>all_lowercase</em> is true, Yahoo Mail addresses are lowercased regardless of the value of this setting.</li><li><em>yahoo_remove_subaddress: true</em>: Normalizes addresses by removing "sub-addresses", which is the part following a "-" sign (e.g. "<a href="mailto:foo-bar@yahoo.com">foo-bar@yahoo.com</a>" becomes "<a href="mailto:foo@yahoo.com">foo@yahoo.com</a>").</li><li><em>icloud_lowercase: true</em> - iCloud addresses (including MobileMe) are known to be case-insensitive, so this switch allows lowercasing them even when <em>all_lowercase</em> is set to false. Please note that when <em>all_lowercase</em> is true, iCloud addresses are lowercased regardless of the value of this setting.</li><li><em>icloud_remove_subaddress: true</em>: Normalizes addresses by removing "sub-addresses", which is the part following a "+" sign (e.g. "<a href="mailto:foo+bar@icloud.com">foo+bar@icloud.com</a>" becomes "<a href="mailto:foo@icloud.com">foo@icloud.com</a>").</li></ul></td>
</tr>
<tr>
<td><strong>rtrim(input [, chars])</strong></td>
<td>trim characters from the right-side of the input.</td>
</tr>
<tr>
<td><strong>stripLow(input [, keep_new_lines])</strong></td>
<td>remove characters with a numerical value &lt; 32 and 127, mostly control characters. If <code>keep_new_lines</code> is <code>true</code>, newline characters are preserved (<code>\n</code> and <code>\r</code>, hex <code>0xA</code> and <code>0xD</code>). Unicode-safe in JavaScript.</td>
</tr>
<tr>
<td><strong>toBoolean(input [, strict])</strong></td>
<td>convert the input string to a boolean. Everything except for <code>'0'</code>, <code>'false'</code> and <code>''</code> returns <code>true</code>. In strict mode only <code>'1'</code> and <code>'true'</code> return <code>true</code>.</td>
</tr>
<tr>
<td><strong>toDate(input)</strong></td>
<td>convert the input string to a date, or <code>null</code> if the input is not a date.</td>
</tr>
<tr>
<td><strong>toFloat(input)</strong></td>
<td>convert the input string to a float, or <code>NaN</code> if the input is not a float.</td>
</tr>
<tr>
<td><strong>toInt(input [, radix])</strong></td>
<td>convert the input string to an integer, or <code>NaN</code> if the input is not an integer.</td>
</tr>
<tr>
<td><strong>trim(input [, chars])</strong></td>
<td>trim characters (whitespace by default) from both sides of the input.</td>
</tr>
<tr>
<td><strong>unescape(input)</strong></td>
<td>replaces HTML encoded entities with <code>&lt;</code>, <code>&gt;</code>, <code>&amp;</code>, <code>'</code>, <code>"</code> and <code>/</code>.</td>
</tr>
<tr>
<td><strong>whitelist(input, chars)</strong></td>
<td>remove characters that do not appear in the whitelist. The characters are used in a RegExp and so you will need to escape some chars, e.g. <code>whitelist(input, '\\[\\]')</code>.</td>
</tr>
</tbody>
</table>
<h3 dir="auto"><a id="user-content-xss-sanitization" class="anchor" aria-hidden="true" href="#xss-sanitization"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>XSS Sanitization</h3>
<p dir="auto">XSS sanitization was removed from the library in <a href="https://github.com/validatorjs/validator.js/commit/2d5d6999541add350fb396ef02dc42ca3215049e">2d5d6999</a>.</p>
<p dir="auto">For an alternative, have a look at Yahoo's <a href="https://github.com/yahoo/xss-filters">xss-filters library</a> or at <a href="https://github.com/cure53/DOMPurify">DOMPurify</a>.</p>
<h2 dir="auto"><a id="user-content-contributing" class="anchor" aria-hidden="true" href="#contributing"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>Contributing</h2>
<p dir="auto">In general, we follow the "fork-and-pull" Git workflow.</p>
<ol dir="auto">
<li>Fork the repo on GitHub</li>
<li>Clone the project to your own machine</li>
<li>Work on your fork
<ol dir="auto">
<li>Make your changes and additions
<ul dir="auto">
<li>Most of your changes should be focused on <code>src/</code> and <code>test/</code> folders and/or <code>README.md</code>.</li>
<li>Files such as <code>validator.js</code>, <code>validator.min.js</code> and files in <code>lib/</code> folder are autogenerated when running tests (<code>npm test</code>) and need not to be changed <strong>manually</strong>.</li>
</ul>
</li>
<li>Change or add tests if needed</li>
<li>Run tests and make sure they pass</li>
<li>Add changes to README.md if needed</li>
</ol>
</li>
<li>Commit changes to your own branch</li>
<li><strong>Make sure</strong> you merge the latest from "upstream" and resolve conflicts if there is any</li>
<li>Repeat step 3(3) above</li>
<li>Push your work back up to your fork</li>
<li>Submit a Pull request so that we can review your changes</li>
</ol>
<h2 dir="auto"><a id="user-content-tests" class="anchor" aria-hidden="true" href="#tests"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>Tests</h2>
<p dir="auto">Tests are using mocha, to run the tests use:</p>
<div class="highlight highlight-source-shell notranslate position-relative overflow-auto" data-snippet-clipboard-copy-content="$ npm test"><pre>$ npm <span class="pl-c1">test</span></pre></div>
<h2 dir="auto"><a id="user-content-maintainers" class="anchor" aria-hidden="true" href="#maintainers"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>Maintainers</h2>
<ul dir="auto">
<li><a href="https://github.com/chriso">chriso</a> - <strong>Chris O'Hara</strong> (author)</li>
<li><a href="https://github.com/profnandaa">profnandaa</a> - <strong>Anthony Nandaa</strong></li>
<li><a href="https://github.com/ezkemboi">ezkemboi</a> - <strong>Ezrqn Kemboi</strong></li>
<li><a href="https://github.com/tux-tn">tux-tn</a> - <strong>Sarhan Aissi</strong></li>
</ul>
<h2 dir="auto"><a id="user-content-reading" class="anchor" aria-hidden="true" href="#reading"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>Reading</h2>
<p dir="auto">Remember, validating can be troublesome sometimes. See <a href="https://github.com/jameslk/awesome-falsehoods">A list of articles about programming assumptions commonly made that aren't true</a>.</p>
<h2 dir="auto"><a id="user-content-license-mit" class="anchor" aria-hidden="true" href="#license-mit"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>License (MIT)</h2>
<div class="snippet-clipboard-content notranslate position-relative overflow-auto" data-snippet-clipboard-copy-content="Copyright (c) 2018 Chris O'Hara &lt;cohara87@gmail.com&gt;

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
&quot;Software&quot;), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED &quot;AS IS&quot;, WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE."><pre class="notranslate"><code>Copyright (c) 2018 Chris O'Hara &lt;cohara87@gmail.com&gt;

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
</code></pre></div>
</article>
          </div>
      </div>

  </readme-toc>


</div>
  <div data-view-component="true" class="Layout-sidebar">      

      <div class="BorderGrid BorderGrid--spacious" data-pjax>
        <div class="BorderGrid-row hide-sm hide-md">
          <div class="BorderGrid-cell">
            <h2 class="mb-3 h4">About</h2>

    <p class="f4 my-3">
      String validation
    </p>

  <h3 class="sr-only">Topics</h3>
  <div class="my-3">
      <div class="f6">
      <a data-ga-click="Topic, repository page" data-octo-click="topic_click" data-octo-dimensions="topic:javascript" href="/topics/javascript" title="Topic: javascript" data-view-component="true" class="topic-tag topic-tag-link">
  javascript
</a>
      <a data-ga-click="Topic, repository page" data-octo-click="topic_click" data-octo-dimensions="topic:sanitization" href="/topics/sanitization" title="Topic: sanitization" data-view-component="true" class="topic-tag topic-tag-link">
  sanitization
</a>
      <a data-ga-click="Topic, repository page" data-octo-click="topic_click" data-octo-dimensions="topic:node" href="/topics/node" title="Topic: node" data-view-component="true" class="topic-tag topic-tag-link">
  node
</a>
      <a data-ga-click="Topic, repository page" data-octo-click="topic_click" data-octo-dimensions="topic:validation" href="/topics/validation" title="Topic: validation" data-view-component="true" class="topic-tag topic-tag-link">
  validation
</a>
      <a data-ga-click="Topic, repository page" data-octo-click="topic_click" data-octo-dimensions="topic:input" href="/topics/input" title="Topic: input" data-view-component="true" class="topic-tag topic-tag-link">
  input
</a>
      <a data-ga-click="Topic, repository page" data-octo-click="topic_click" data-octo-dimensions="topic:validator" href="/topics/validator" title="Topic: validator" data-view-component="true" class="topic-tag topic-tag-link">
  validator
</a>
      <a data-ga-click="Topic, repository page" data-octo-click="topic_click" data-octo-dimensions="topic:validations" href="/topics/validations" title="Topic: validations" data-view-component="true" class="topic-tag topic-tag-link">
  validations
</a>
      <a data-ga-click="Topic, repository page" data-octo-click="topic_click" data-octo-dimensions="topic:validate" href="/topics/validate" title="Topic: validate" data-view-component="true" class="topic-tag topic-tag-link">
  validate
</a>
      <a data-ga-click="Topic, repository page" data-octo-click="topic_click" data-octo-dimensions="topic:hacktoberfest" href="/topics/hacktoberfest" title="Topic: hacktoberfest" data-view-component="true" class="topic-tag topic-tag-link">
  hacktoberfest
</a>
      <a data-ga-click="Topic, repository page" data-octo-click="topic_click" data-octo-dimensions="topic:sanitize" href="/topics/sanitize" title="Topic: sanitize" data-view-component="true" class="topic-tag topic-tag-link">
  sanitize
</a>
  </div>

  </div>

  <h3 class="sr-only">Resources</h3>
  <div class="mt-2">
    <a class="Link--muted" data-analytics-event="{&quot;category&quot;:&quot;Repository Overview&quot;,&quot;action&quot;:&quot;click&quot;,&quot;label&quot;:&quot;location:sidebar;file:readme&quot;}" href="#readme">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-book mr-2">
    <path fill-rule="evenodd" d="M0 1.75A.75.75 0 01.75 1h4.253c1.227 0 2.317.59 3 1.501A3.744 3.744 0 0111.006 1h4.245a.75.75 0 01.75.75v10.5a.75.75 0 01-.75.75h-4.507a2.25 2.25 0 00-1.591.659l-.622.621a.75.75 0 01-1.06 0l-.622-.621A2.25 2.25 0 005.258 13H.75a.75.75 0 01-.75-.75V1.75zm8.755 3a2.25 2.25 0 012.25-2.25H14.5v9h-3.757c-.71 0-1.4.201-1.992.572l.004-7.322zm-1.504 7.324l.004-5.073-.002-2.253A2.25 2.25 0 005.003 2.5H1.5v9h3.757a3.75 3.75 0 011.994.574z"></path>
</svg>
      Readme
</a>  </div>

<h3 class="sr-only">License</h3>
  <div class="mt-2">
    <a href="/validatorjs/validator.js/blob/master/LICENSE"
      class="Link--muted"
      
      data-analytics-event="{&quot;category&quot;:&quot;Repository Overview&quot;,&quot;action&quot;:&quot;click&quot;,&quot;label&quot;:&quot;location:sidebar;file:license&quot;}"
    >
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-law mr-2">
    <path fill-rule="evenodd" d="M8.75.75a.75.75 0 00-1.5 0V2h-.984c-.305 0-.604.08-.869.23l-1.288.737A.25.25 0 013.984 3H1.75a.75.75 0 000 1.5h.428L.066 9.192a.75.75 0 00.154.838l.53-.53-.53.53v.001l.002.002.002.002.006.006.016.015.045.04a3.514 3.514 0 00.686.45A4.492 4.492 0 003 11c.88 0 1.556-.22 2.023-.454a3.515 3.515 0 00.686-.45l.045-.04.016-.015.006-.006.002-.002.001-.002L5.25 9.5l.53.53a.75.75 0 00.154-.838L3.822 4.5h.162c.305 0 .604-.08.869-.23l1.289-.737a.25.25 0 01.124-.033h.984V13h-2.5a.75.75 0 000 1.5h6.5a.75.75 0 000-1.5h-2.5V3.5h.984a.25.25 0 01.124.033l1.29.736c.264.152.563.231.868.231h.162l-2.112 4.692a.75.75 0 00.154.838l.53-.53-.53.53v.001l.002.002.002.002.006.006.016.015.045.04a3.517 3.517 0 00.686.45A4.492 4.492 0 0013 11c.88 0 1.556-.22 2.023-.454a3.512 3.512 0 00.686-.45l.045-.04.01-.01.006-.005.006-.006.002-.002.001-.002-.529-.531.53.53a.75.75 0 00.154-.838L13.823 4.5h.427a.75.75 0 000-1.5h-2.234a.25.25 0 01-.124-.033l-1.29-.736A1.75 1.75 0 009.735 2H8.75V.75zM1.695 9.227c.285.135.718.273 1.305.273s1.02-.138 1.305-.273L3 6.327l-1.305 2.9zm10 0c.285.135.718.273 1.305.273s1.02-.138 1.305-.273L13 6.327l-1.305 2.9z"></path>
</svg>
     MIT license
    </a>
  </div>



<include-fragment  aria-label="Loading..." src="/validatorjs/validator.js/hovercards/citation/sidebar_partial?tree_name=master">
</include-fragment>

<h3 class="sr-only">Stars</h3>
<div class="mt-2">
  <a href="/validatorjs/validator.js/stargazers" data-view-component="true" class="Link--muted">
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-star mr-2">
    <path fill-rule="evenodd" d="M8 .25a.75.75 0 01.673.418l1.882 3.815 4.21.612a.75.75 0 01.416 1.279l-3.046 2.97.719 4.192a.75.75 0 01-1.088.791L8 12.347l-3.766 1.98a.75.75 0 01-1.088-.79l.72-4.194L.818 6.374a.75.75 0 01.416-1.28l4.21-.611L7.327.668A.75.75 0 018 .25zm0 2.445L6.615 5.5a.75.75 0 01-.564.41l-3.097.45 2.24 2.184a.75.75 0 01.216.664l-.528 3.084 2.769-1.456a.75.75 0 01.698 0l2.77 1.456-.53-3.084a.75.75 0 01.216-.664l2.24-2.183-3.096-.45a.75.75 0 01-.564-.41L8 2.694v.001z"></path>
</svg>
    <strong>19.8k</strong>
    stars
</a></div>

<h3 class="sr-only">Watchers</h3>
<div class="mt-2">
  <a href="/validatorjs/validator.js/watchers" data-view-component="true" class="Link--muted">
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-eye mr-2">
    <path fill-rule="evenodd" d="M1.679 7.932c.412-.621 1.242-1.75 2.366-2.717C5.175 4.242 6.527 3.5 8 3.5c1.473 0 2.824.742 3.955 1.715 1.124.967 1.954 2.096 2.366 2.717a.119.119 0 010 .136c-.412.621-1.242 1.75-2.366 2.717C10.825 11.758 9.473 12.5 8 12.5c-1.473 0-2.824-.742-3.955-1.715C2.92 9.818 2.09 8.69 1.679 8.068a.119.119 0 010-.136zM8 2c-1.981 0-3.67.992-4.933 2.078C1.797 5.169.88 6.423.43 7.1a1.619 1.619 0 000 1.798c.45.678 1.367 1.932 2.637 3.024C4.329 13.008 6.019 14 8 14c1.981 0 3.67-.992 4.933-2.078 1.27-1.091 2.187-2.345 2.637-3.023a1.619 1.619 0 000-1.798c-.45-.678-1.367-1.932-2.637-3.023C11.671 2.992 9.981 2 8 2zm0 8a2 2 0 100-4 2 2 0 000 4z"></path>
</svg>
    <strong>229</strong>
    watching
</a></div>

<h3 class="sr-only">Forks</h3>
<div class="mt-2">
  <a href="/validatorjs/validator.js/network/members" data-view-component="true" class="Link--muted">
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo-forked mr-2">
    <path fill-rule="evenodd" d="M5 3.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm0 2.122a2.25 2.25 0 10-1.5 0v.878A2.25 2.25 0 005.75 8.5h1.5v2.128a2.251 2.251 0 101.5 0V8.5h1.5a2.25 2.25 0 002.25-2.25v-.878a2.25 2.25 0 10-1.5 0v.878a.75.75 0 01-.75.75h-4.5A.75.75 0 015 6.25v-.878zm3.75 7.378a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm3-8.75a.75.75 0 100-1.5.75.75 0 000 1.5z"></path>
</svg>
    <strong>2k</strong>
    forks
</a></div>

          </div>
        </div>

        
        
            <div class="BorderGrid-row">
              <div class="BorderGrid-cell">
                <h2 class="h4 mb-3" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame">
  <a href="/validatorjs/validator.js/releases" data-view-component="true" class="Link--primary no-underline">
    Releases
      <span title="9" data-view-component="true" class="Counter">9</span>
</a></h2>

  <a class="Link--primary d-flex no-underline" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/releases/tag/13.7.0">
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-tag flex-shrink-0 mt-1 color-fg-success">
    <path fill-rule="evenodd" d="M2.5 7.775V2.75a.25.25 0 01.25-.25h5.025a.25.25 0 01.177.073l6.25 6.25a.25.25 0 010 .354l-5.025 5.025a.25.25 0 01-.354 0l-6.25-6.25a.25.25 0 01-.073-.177zm-1.5 0V2.75C1 1.784 1.784 1 2.75 1h5.025c.464 0 .91.184 1.238.513l6.25 6.25a1.75 1.75 0 010 2.474l-5.026 5.026a1.75 1.75 0 01-2.474 0l-6.25-6.25A1.75 1.75 0 011 7.775zM6 5a1 1 0 100 2 1 1 0 000-2z"></path>
</svg>
    <div class="ml-2 min-width-0">
      <div class="d-flex">
        <span class="css-truncate css-truncate-target text-bold mr-2" style="max-width: none;">13.7.0</span>
        <span title="Label: Latest" data-view-component="true" class="Label Label--success flex-shrink-0">
          Latest
</span>      </div>
      <div class="text-small color-fg-muted"><relative-time datetime="2021-11-01T21:06:53Z" class="no-wrap">Nov 1, 2021</relative-time></div>
    </div>
</a>    <div data-view-component="true" class="mt-3">
      <a text="small" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" href="/validatorjs/validator.js/releases" data-view-component="true">
        + 8 releases
</a></div>
              </div>
            </div>

        
            <div class="BorderGrid-row">
              <div class="BorderGrid-cell">
                
<h2 class="h4 mb-3">Sponsor this project</h2>
<include-fragment src="/validatorjs/validator.js/sponsors_list?block_button=false&amp;current_repository=validator.js" aria-busy="true" aria-label="Loading sponsorable links">
        <ul class="list-style-none">
        </ul>
</include-fragment>  <ul class="list-style-none">
        <li class="mb-2 d-flex">
          <span class="mr-2 d-flex flex-items-center flex-justify-center" style="min-width:32px;height:32px;">
            <img width="32" height="32" class="octicon rounded-2 d-block" alt="open_collective" src="https://github.githubassets.com/images/modules/site/icons/funding_platforms/open_collective.svg" />
          </span>
          <span class="flex-self-center flex-auto min-width-0 css-truncate css-truncate-target width-fit">
            <a target="_blank" data-ga-click="Dashboard, click, Nav menu - item:org-profile context:organization" data-hydro-click="{&quot;event_type&quot;:&quot;sponsors.repo_funding_links_link_click&quot;,&quot;payload&quot;:{&quot;platform&quot;:{&quot;platform_type&quot;:&quot;OPEN_COLLECTIVE&quot;,&quot;platform_url&quot;:&quot;https://opencollective.com/validatorjs&quot;},&quot;platforms&quot;:[{&quot;platform_type&quot;:&quot;OPEN_COLLECTIVE&quot;,&quot;platform_url&quot;:&quot;https://opencollective.com/validatorjs&quot;}],&quot;repo_id&quot;:965782,&quot;owner_id&quot;:52114810,&quot;user_id&quot;:null,&quot;originating_url&quot;:&quot;https://github.com/validatorjs/validator.js&quot;}}" data-hydro-click-hmac="3cfcef17b69ffd2c53a9cf2dd58a850a5c1d8d725d40655846e4d8f4dd45c989" href="https://opencollective.com/validatorjs"><span>opencollective.com/<strong>validatorjs</strong></span></a>
          </span>
        </li>
  </ul>

              </div>
            </div>

        
            <div class="BorderGrid-row">
              <div class="BorderGrid-cell">
                <h2 class="h4 mb-3">
  <a href="/orgs/validatorjs/packages?repo_name=validator.js" data-view-component="true" class="Link--primary no-underline">
    Packages <span title="0" hidden="hidden" data-view-component="true" class="Counter">0</span>
</a></h2>


      <div class="text-small color-fg-muted">
        No packages published <br>
      </div>



              </div>
            </div>

        
            <div class="BorderGrid-row" hidden>
              <div class="BorderGrid-cell">
                <include-fragment src="/validatorjs/validator.js/used_by_list" accept="text/fragment+html">
</include-fragment>
              </div>
            </div>

        
            <div class="BorderGrid-row">
              <div class="BorderGrid-cell">
                <h2 class="h4 mb-3">
  <a href="/validatorjs/validator.js/graphs/contributors" data-view-component="true" class="Link--primary no-underline">
    Contributors <span title="394" data-view-component="true" class="Counter">394</span>
</a></h2>


    
  <ul class="list-style-none d-flex flex-wrap mb-n2">
    <li class="mb-2 mr-2"
        data-test-selector="grid-mode-element">
      <a href="https://github.com/chriso"
          class=""
            data-hovercard-type="user" data-hovercard-url="/users/chriso/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self"
          
        >
        <img src="https://avatars.githubusercontent.com/u/364903?s=64&amp;v=4" alt="@chriso" size="32" height="32" width="32" data-view-component="true" class="avatar circle" />
      </a>
    </li>
    <li class="mb-2 mr-2"
        data-test-selector="grid-mode-element">
      <a href="https://github.com/mren"
          class=""
            data-hovercard-type="user" data-hovercard-url="/users/mren/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self"
          
        >
        <img src="https://avatars.githubusercontent.com/u/576360?s=64&amp;v=4" alt="@mren" size="32" height="32" width="32" data-view-component="true" class="avatar circle" />
      </a>
    </li>
    <li class="mb-2 mr-2"
        data-test-selector="grid-mode-element">
      <a href="https://github.com/profnandaa"
          class=""
            data-hovercard-type="user" data-hovercard-url="/users/profnandaa/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self"
          
        >
        <img src="https://avatars.githubusercontent.com/u/261265?s=64&amp;v=4" alt="@profnandaa" size="32" height="32" width="32" data-view-component="true" class="avatar circle" />
      </a>
    </li>
    <li class="mb-2 mr-2"
        data-test-selector="grid-mode-element">
      <a href="https://github.com/forabi"
          class=""
            data-hovercard-type="user" data-hovercard-url="/users/forabi/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self"
          
        >
        <img src="https://avatars.githubusercontent.com/u/1012761?s=64&amp;v=4" alt="@forabi" size="32" height="32" width="32" data-view-component="true" class="avatar circle" />
      </a>
    </li>
    <li class="mb-2 mr-2"
        data-test-selector="grid-mode-element">
      <a href="https://github.com/tux-tn"
          class=""
            data-hovercard-type="user" data-hovercard-url="/users/tux-tn/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self"
          
        >
        <img src="https://avatars.githubusercontent.com/u/1423022?s=64&amp;v=4" alt="@tux-tn" size="32" height="32" width="32" data-view-component="true" class="avatar circle" />
      </a>
    </li>
    <li class="mb-2 mr-2"
        data-test-selector="grid-mode-element">
      <a href="https://github.com/ezkemboi"
          class=""
            data-hovercard-type="user" data-hovercard-url="/users/ezkemboi/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self"
          
        >
        <img src="https://avatars.githubusercontent.com/u/48981919?s=64&amp;v=4" alt="@ezkemboi" size="32" height="32" width="32" data-view-component="true" class="avatar circle" />
      </a>
    </li>
    <li class="mb-2 mr-2"
        data-test-selector="grid-mode-element">
      <a href="https://github.com/linkinmedo"
          class=""
            data-hovercard-type="user" data-hovercard-url="/users/linkinmedo/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self"
          
        >
        <img src="https://avatars.githubusercontent.com/u/1764141?s=64&amp;v=4" alt="@linkinmedo" size="32" height="32" width="32" data-view-component="true" class="avatar circle" />
      </a>
    </li>
    <li class="mb-2 mr-2"
        data-test-selector="grid-mode-element">
      <a href="https://github.com/rubiin"
          class=""
            data-hovercard-type="user" data-hovercard-url="/users/rubiin/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self"
          
        >
        <img src="https://avatars.githubusercontent.com/u/8222059?s=64&amp;v=4" alt="@rubiin" size="32" height="32" width="32" data-view-component="true" class="avatar circle" />
      </a>
    </li>
    <li class="mb-2 mr-2"
        data-test-selector="grid-mode-element">
      <a href="https://github.com/ItalyPaleAle"
          class=""
            data-hovercard-type="user" data-hovercard-url="/users/ItalyPaleAle/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self"
          
        >
        <img src="https://avatars.githubusercontent.com/u/43508?s=64&amp;v=4" alt="@ItalyPaleAle" size="32" height="32" width="32" data-view-component="true" class="avatar circle" />
      </a>
    </li>
    <li class="mb-2 mr-2"
        data-test-selector="grid-mode-element">
      <a href="https://github.com/tbasse"
          class=""
            data-hovercard-type="user" data-hovercard-url="/users/tbasse/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self"
          
        >
        <img src="https://avatars.githubusercontent.com/u/291433?s=64&amp;v=4" alt="@tbasse" size="32" height="32" width="32" data-view-component="true" class="avatar circle" />
      </a>
    </li>
    <li class="mb-2 mr-2"
        data-test-selector="grid-mode-element">
      <a href="https://github.com/neilime"
          class=""
            data-hovercard-type="user" data-hovercard-url="/users/neilime/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self"
          
        >
        <img src="https://avatars.githubusercontent.com/u/314088?s=64&amp;v=4" alt="@neilime" size="32" height="32" width="32" data-view-component="true" class="avatar circle" />
      </a>
    </li>
</ul>




  <div data-view-component="true" class="mt-3">
    <a text="small" href="/validatorjs/validator.js/graphs/contributors" data-view-component="true">
      + 383 contributors
</a></div>
              </div>
            </div>

        
        
            <div class="BorderGrid-row">
              <div class="BorderGrid-cell">
                <h2 class="h4 mb-3">Languages</h2>
<div class="mb-2">
  <span data-view-component="true" class="Progress">
    <span style="background-color:#f1e05a !important;;width: 100.0%;" itemprop="keywords" aria-label="JavaScript 100.0" data-view-component="true" class="Progress-item color-bg-success-emphasis"></span>
</span></div>
<ul class="list-style-none">
    <li class="d-inline">
        <a class="d-inline-flex flex-items-center flex-nowrap Link--secondary no-underline text-small mr-3" href="/validatorjs/validator.js/search?l=javascript"  data-ga-click="Repository, language stats search click, location:repo overview">
          <svg style="color:#f1e05a;" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-dot-fill mr-2">
    <path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8z"></path>
</svg>
          <span class="color-fg-default text-bold mr-1">JavaScript</span>
          <span>100.0%</span>
        </a>
    </li>
</ul>

              </div>
            </div>
      </div>
</div>
  
</div></div>

  </div>


  </div>



    </main>
  </div>

  </div>

          <footer class="footer width-full container-xl p-responsive">
  <h2 class='sr-only'>Footer</h2>

  <div class="position-relative d-flex flex-items-center pb-2 f6 color-fg-muted border-top color-border-muted flex-column-reverse flex-lg-row flex-wrap flex-lg-nowrap mt-6 pt-6">
    <div class="list-style-none d-flex flex-wrap col-0 col-lg-2 flex-justify-start flex-lg-justify-between mb-2 mb-lg-0">
      <div class="mt-2 mt-lg-0 d-flex flex-items-center">
        <a aria-label="Homepage" title="GitHub" class="footer-octicon mr-2" href="https://github.com">
          <svg aria-hidden="true" height="24" viewBox="0 0 16 16" version="1.1" width="24" data-view-component="true" class="octicon octicon-mark-github">
    <path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"></path>
</svg>
</a>        <span>
        &copy; 2022 GitHub, Inc.
        </span>
      </div>
    </div>

    <nav aria-label='footer' class="col-12 col-lg-8">
      <h3 class='sr-only' id='sr-footer-heading'>Footer navigation</h3>
      <ul class="list-style-none d-flex flex-wrap col-12 flex-justify-center flex-lg-justify-between mb-2 mb-lg-0" aria-labelledby='sr-footer-heading'>
          <li class="mr-3 mr-lg-0"><a href="https://docs.github.com/en/github/site-policy/github-terms-of-service" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to terms&quot;,&quot;label&quot;:&quot;text:terms&quot;}">Terms</a></li>
          <li class="mr-3 mr-lg-0"><a href="https://docs.github.com/en/github/site-policy/github-privacy-statement" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to privacy&quot;,&quot;label&quot;:&quot;text:privacy&quot;}">Privacy</a></li>
          <li class="mr-3 mr-lg-0"><a data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to security&quot;,&quot;label&quot;:&quot;text:security&quot;}" href="https://github.com/security">Security</a></li>
          <li class="mr-3 mr-lg-0"><a href="https://www.githubstatus.com/" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to status&quot;,&quot;label&quot;:&quot;text:status&quot;}">Status</a></li>
          <li class="mr-3 mr-lg-0"><a data-ga-click="Footer, go to help, text:Docs" href="https://docs.github.com">Docs</a></li>
          <li class="mr-3 mr-lg-0"><a href="https://support.github.com?tags=dotcom-footer" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to contact&quot;,&quot;label&quot;:&quot;text:contact&quot;}">Contact GitHub</a></li>
          <li class="mr-3 mr-lg-0"><a href="https://github.com/pricing" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to Pricing&quot;,&quot;label&quot;:&quot;text:Pricing&quot;}">Pricing</a></li>
        <li class="mr-3 mr-lg-0"><a href="https://docs.github.com" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to api&quot;,&quot;label&quot;:&quot;text:api&quot;}">API</a></li>
        <li class="mr-3 mr-lg-0"><a href="https://services.github.com" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to training&quot;,&quot;label&quot;:&quot;text:training&quot;}">Training</a></li>
          <li class="mr-3 mr-lg-0"><a href="https://github.blog" data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to blog&quot;,&quot;label&quot;:&quot;text:blog&quot;}">Blog</a></li>
          <li><a data-ga-click="Footer, go to about, text:about" href="https://github.com/about">About</a></li>
      </ul>
    </nav>
  </div>

  <div class="d-flex flex-justify-center pb-6">
    <span class="f6 color-fg-muted"></span>
  </div>
</footer>




  <div id="ajax-error-message" class="ajax-error-message flash flash-error" hidden>
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert">
    <path fill-rule="evenodd" d="M8.22 1.754a.25.25 0 00-.44 0L1.698 13.132a.25.25 0 00.22.368h12.164a.25.25 0 00.22-.368L8.22 1.754zm-1.763-.707c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0114.082 15H1.918a1.75 1.75 0 01-1.543-2.575L6.457 1.047zM9 11a1 1 0 11-2 0 1 1 0 012 0zm-.25-5.25a.75.75 0 00-1.5 0v2.5a.75.75 0 001.5 0v-2.5z"></path>
</svg>
    <button type="button" class="flash-close js-ajax-error-dismiss" aria-label="Dismiss error">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path fill-rule="evenodd" d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.75.75 0 111.06 1.06L9.06 8l3.22 3.22a.75.75 0 11-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 01-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 010-1.06z"></path>
</svg>
    </button>
    You can’t perform that action at this time.
  </div>

  <div class="js-stale-session-flash flash flash-warn flash-banner" hidden
    >
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert">
    <path fill-rule="evenodd" d="M8.22 1.754a.25.25 0 00-.44 0L1.698 13.132a.25.25 0 00.22.368h12.164a.25.25 0 00.22-.368L8.22 1.754zm-1.763-.707c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0114.082 15H1.918a1.75 1.75 0 01-1.543-2.575L6.457 1.047zM9 11a1 1 0 11-2 0 1 1 0 012 0zm-.25-5.25a.75.75 0 00-1.5 0v2.5a.75.75 0 001.5 0v-2.5z"></path>
</svg>
    <span class="js-stale-session-flash-signed-in" hidden>You signed in with another tab or window. <a href="">Reload</a> to refresh your session.</span>
    <span class="js-stale-session-flash-signed-out" hidden>You signed out in another tab or window. <a href="">Reload</a> to refresh your session.</span>
  </div>
    <template id="site-details-dialog">
  <details class="details-reset details-overlay details-overlay-dark lh-default color-fg-default hx_rsm" open>
    <summary role="button" aria-label="Close dialog"></summary>
    <details-dialog class="Box Box--overlay d-flex flex-column anim-fade-in fast hx_rsm-dialog hx_rsm-modal">
      <button class="Box-btn-octicon m-0 btn-octicon position-absolute right-0 top-0" type="button" aria-label="Close dialog" data-close-dialog>
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path fill-rule="evenodd" d="M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.75.75 0 111.06 1.06L9.06 8l3.22 3.22a.75.75 0 11-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 01-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 010-1.06z"></path>
</svg>
      </button>
      <div class="octocat-spinner my-6 js-details-dialog-spinner"></div>
    </details-dialog>
  </details>
</template>

    <div class="Popover js-hovercard-content position-absolute" style="display: none; outline: none;" tabindex="0">
  <div class="Popover-message Popover-message--bottom-left Popover-message--large Box color-shadow-large" style="width:360px;">
  </div>
</div>

    <template id="snippet-clipboard-copy-button">
  <div class="zeroclipboard-container position-absolute right-0 top-0">
    <clipboard-copy aria-label="Copy" class="ClipboardButton btn js-clipboard-copy m-2 p-0 tooltipped-no-delay" data-copy-feedback="Copied!" data-tooltip-direction="w">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-copy js-clipboard-copy-icon m-2">
    <path fill-rule="evenodd" d="M0 6.75C0 5.784.784 5 1.75 5h1.5a.75.75 0 010 1.5h-1.5a.25.25 0 00-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 00.25-.25v-1.5a.75.75 0 011.5 0v1.5A1.75 1.75 0 019.25 16h-7.5A1.75 1.75 0 010 14.25v-7.5z"></path><path fill-rule="evenodd" d="M5 1.75C5 .784 5.784 0 6.75 0h7.5C15.216 0 16 .784 16 1.75v7.5A1.75 1.75 0 0114.25 11h-7.5A1.75 1.75 0 015 9.25v-7.5zm1.75-.25a.25.25 0 00-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 00.25-.25v-7.5a.25.25 0 00-.25-.25h-7.5z"></path>
</svg>
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check js-clipboard-check-icon color-fg-success d-none m-2">
    <path fill-rule="evenodd" d="M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z"></path>
</svg>
    </clipboard-copy>
  </div>
</template>




  </body>
</html>

